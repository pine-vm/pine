using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Pine
{
    public static Pine_PineValue bigIntFromBlobValue(Pine_PineValue param_1_0)
    {
        if (param_1_0 == Pine_PineValue.EmptyList)
        {
            return CommonReusedValues.List_c884fc84;
        }

        if (!(Pine_KernelFunctionSpecialized.length_as_int(param_1_0) == 0))
        {
            Pine_PineValue local_000 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [0]);

            if (local_000 == CommonReusedValues.Blob_Int_4)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Global_Anonymous.zzz_anon_f9abafe1_9bce9a70(
                                        Pine_KernelFunctionSpecialized.skip(1, param_1_0))
                                ])
                        ]);
            }

            if (local_000 == CommonReusedValues.Blob_Int_2)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunction.negate(
                                        Global_Anonymous.zzz_anon_f9abafe1_9bce9a70(
                                            Pine_KernelFunctionSpecialized.skip(1, param_1_0)))
                                ])
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunctionSpecialized.concat(
                                                    CommonReusedValues.Blob_0972a741,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        String.fromInt(local_000),
                                                        [1, 0]))
                                            ])
                                    ])
                            ])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue bigIntFromValue(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Pine.bigIntFromBlobValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        return CommonReusedValues.List_9a337336;
    }


    public static Pine_PineValue blobBytesFromChar(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.int_add(
                0,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(true),
                    param_1_0));

        Pine_PineValue local_001 =
            Pine_IntegerEncoding.EncodeSignedInteger(
                Pine_KernelFunctionSpecialized.length_as_int(local_000));

        return
            Pine_PineValue.List(
                [
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        Basics.idiv(local_000, CommonReusedValues.Blob_Int_16777216)),
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        Basics.idiv(local_000, CommonReusedValues.Blob_Int_65536)),
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        local_001 == CommonReusedValues.Blob_Int_2
                        ?
                        CommonReusedValues.Blob_Int_0
                        :
                        (local_001 == CommonReusedValues.Blob_Int_1
                        ?
                        Pine_PineValue.EmptyList
                        :
                        (local_001 == CommonReusedValues.Blob_Int_0
                        ?
                        Pine_PineValue.EmptyList
                        :
                        Pine_KernelFunction.reverse(
                            Pine_KernelFunctionSpecialized.skip(
                                1,
                                Pine_KernelFunction.reverse(local_000)))))),
                    Basics.modBy(CommonReusedValues.Blob_Int_256, local_000)
                ]);
    }


    public static Pine_PineValue blobValueFromBigInt(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0)
            ?
            param_1_0
            :
            Pine_KernelFunction.negate(param_1_0);

        Pine_PineValue local_001 =
            Pine_PineValue.List(
                [
                    local_000,
                    Pine_IntegerEncoding.EncodeSignedInteger(256)
                ]);

        Pine_PineValue local_002 =
            BigInt.lt(local_000, CommonReusedValues.Blob_Int_256) == Pine_PineKernelValues.TrueValue
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    BigInt.toString(local_000)),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    BigInt.toString(local_000)),
                [0])
            ?
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                                            BigInt.toString(local_000)),
                                        [1, 0])
                                ])
                        ])
                ])
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                [0])
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dc80c2ca_c4ab872f(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                        [1, 0, 0])),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dc80c2ca_c4ab872f(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                        [1, 0, 0])),
                [0])
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    BigInt.toString(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                            [1, 0, 1]))),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    BigInt.toString(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                            [1, 0, 1]))),
                [0])
            ?
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.concat(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    Global_Anonymous.zzz_anon_dc80c2ca_c4ab872f(
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                                            [1, 0, 0])),
                                    [1, 0]),
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                                                BigInt.toString(
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                                                        [1, 0, 1]))),
                                            [1, 0])
                                    ]))
                        ])
                ])
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")));

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]);

        if (CommonReusedValues.Blob_Str_Nothing == local_003)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_IntegerEncoding.EncodeSignedInteger(
                            Basics.eq(local_000, param_1_0) == Pine_PineKernelValues.TrueValue
                            ?
                            4
                            :
                            2)
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Just == local_003)
        {
            return
                Pine_KernelFunctionSpecialized.concat(
                    Pine_PineValue.List(
                        [
                            Pine_IntegerEncoding.EncodeSignedInteger(
                                Basics.eq(local_000, param_1_0) == Pine_PineKernelValues.TrueValue
                                ?
                                4
                                :
                                2)
                        ]),
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1, 0]));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue computeValueFromString(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_BlobValue,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunction.concat(
                                Global_Anonymous.zzz_anon_8792c675_ffb0335e(
                                    Pine_PineValue.EmptyList,
                                    String.toListRecursive(
                                        CommonReusedValues.Blob_Int_0,
                                        Pine_PineValue.EmptyList,
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            param_1_0,
                                            [1, 0]))))
                        ])
                ]);
    }


    public static Pine_PineValue encodeExpressionAsValue(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_LiteralExpression == local_000)
        {
            return
                Global_Anonymous.zzz_anon_6aa05e39_dda26649(
                    CommonReusedValues.List_0a078809,
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_ListValue,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                param_1_0,
                                                [1, 0])
                                        ])
                                ])
                        ]));
        }

        if (CommonReusedValues.Blob_Str_ListExpression == local_000)
        {
            return
                Global_Anonymous.zzz_anon_563fe0ad_14c12277(
                    Pine_PineValue.EmptyList,
                    Pine_KernelFunction.reverse(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            param_1_0,
                            [1, 0])));
        }

        if (CommonReusedValues.Blob_Str_ParseAndEvalExpression == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Global_Anonymous.zzz_anon_6aa05e39_dda26649(
                    CommonReusedValues.List_fa615f0b,
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_ListValue,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_001,
                                                    [0])),
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_001,
                                                    [1]))
                                        ])
                                ])
                        ]));
        }

        if (CommonReusedValues.Blob_Str_KernelApplicationExpression == local_000)
        {
            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Global_Anonymous.zzz_anon_6aa05e39_dda26649(
                    CommonReusedValues.List_4bcbcd70,
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_ListValue,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine.computeValueFromString(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [0])),
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [1]))
                                        ])
                                ])
                        ]));
        }

        if (CommonReusedValues.Blob_Str_ConditionalExpression == local_000)
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Global_Anonymous.zzz_anon_6aa05e39_dda26649(
                    CommonReusedValues.List_b8120726,
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_ListValue,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [0])),
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [1])),
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [2]))
                                        ])
                                ])
                        ]));
        }

        if (CommonReusedValues.Blob_Str_EnvironmentExpression == local_000)
        {
            return CommonReusedValues.List_753b2812;
        }

        if (CommonReusedValues.Blob_Str_StringTagExpression == local_000)
        {
            Pine_PineValue local_004 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Global_Anonymous.zzz_anon_6aa05e39_dda26649(
                    CommonReusedValues.List_8a17d2aa,
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_ListValue,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine.valueFromString(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [0])),
                                            Pine.encodeExpressionAsValue(
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [1]))
                                        ])
                                ])
                        ]));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue intFromUnsignedBlobValue(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0 == Pine_PineValue.EmptyList)
            {
                return local_param_1_1;
            }

            if (!(Pine_KernelFunctionSpecialized.length_as_int(local_param_1_0) == 0))
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.skip(1, local_param_1_0);

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            Pine_KernelFunctionSpecialized.int_mul(256, local_param_1_1),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_param_1_0,
                                [0]));

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue intFromValue(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_9a337336;
        }

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]);

            Pine_PineValue local_002 =
                Pine_KernelFunctionSpecialized.skip(1, local_001);

            if (!(Pine_KernelFunctionSpecialized.length_as_int(local_002) == 0))
            {
                Pine_PineValue local_003 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [0]);

                if (local_003 == CommonReusedValues.Blob_Int_4)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine.intFromUnsignedBlobValue(
                                            Pine_KernelFunctionSpecialized.skip(1, local_002),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1]))
                                    ])
                            ]);
                }

                if (local_003 == CommonReusedValues.Blob_Int_2)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunction.negate(
                                            Pine.intFromUnsignedBlobValue(
                                                Pine_KernelFunctionSpecialized.skip(1, local_002),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_001,
                                                    [1])))
                                    ])
                            ]);
                }

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunctionSpecialized.concat(
                                                        CommonReusedValues.Blob_0972a741,
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            String.fromInt(local_003),
                                                            [1, 0]))
                                                ])
                                        ])
                                ])
                        ]);
            }

            return CommonReusedValues.List_947ee852;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue kernelFunction_negate(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (local_002 == CommonReusedValues.Blob_Int_4)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionSpecialized.concat(
                                        CommonReusedValues.List_Single_Blob_Int_2,
                                        Pine_KernelFunctionSpecialized.skip(1, local_001))
                                ])
                        ]);
            }

            if (local_002 == CommonReusedValues.Blob_Int_2)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionSpecialized.concat(
                                        CommonReusedValues.List_Single_Blob_Int_4,
                                        Pine_KernelFunctionSpecialized.skip(1, local_001))
                                ])
                        ]);
            }

            return CommonReusedValues.List_1f3f2fca;
        }

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_1f3f2fca;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue parseExpressionFromValue(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if ((CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_002 =
                Pine.stringFromValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]));

            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [0]);

            if (CommonReusedValues.Blob_Str_Err == local_003)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunctionSpecialized.concat(
                                                        CommonReusedValues.Blob_ab1cfe3e,
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            local_002,
                                                            [1, 0, 1, 0]))
                                                ])
                                        ])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Ok == local_003)
            {
                Pine_PineValue local_004 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1, 0]);

                if (local_004 == CommonReusedValues.List_84a73c03)
                {
                    Pine_PineValue local_005 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [1, 0]);

                    if (!(Pine_KernelFunctionSpecialized.length_as_int(local_005) == 0))
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_LiteralExpression,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_005,
                                                                [0])
                                                        ])
                                                ])
                                        ])
                                ]);
                    }

                    if (local_005 == Pine_PineValue.EmptyList)
                    {
                        return CommonReusedValues.List_9dd8b54a;
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                if (local_004 == CommonReusedValues.List_b18026e6)
                {
                    Pine_PineValue local_006 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [1, 0]);

                    if (!(Pine_KernelFunctionSpecialized.length_as_int(local_006) == 0))
                    {
                        return
                            Global_Anonymous.zzz_anon_a3e95a54_77dfbc74(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_006,
                                    [0]));
                    }

                    if (local_006 == Pine_PineValue.EmptyList)
                    {
                        return CommonReusedValues.List_1c5ae8b8;
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                if (local_004 == CommonReusedValues.List_ae363231)
                {
                    Pine_PineValue local_007 =
                        Global_Anonymous.zzz_anon_e9c3132d_77dfbc74(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [1, 0]));

                    Pine_PineValue local_008 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_007,
                            [0]);

                    if (CommonReusedValues.Blob_Str_Ok == local_008)
                    {
                        Pine_PineValue local_009 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_007,
                                [1, 0]);

                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_ParseAndEvalExpression,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_009,
                                                                [0]),
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_009,
                                                                [1])
                                                        ])
                                                ])
                                        ])
                                ]);
                    }

                    if (CommonReusedValues.Blob_Str_Err == local_008)
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_007,
                                                [1, 0])
                                        ])
                                ]);
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                if (local_004 == CommonReusedValues.List_ed1ec9fc)
                {
                    Pine_PineValue local_010 =
                        Global_Anonymous.zzz_anon_f0fcb884_77dfbc74(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [1, 0]));

                    Pine_PineValue local_011 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_010,
                            [0]);

                    if (CommonReusedValues.Blob_Str_Ok == local_011)
                    {
                        Pine_PineValue local_012 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_010,
                                [1, 0]);

                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_KernelApplicationExpression,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_012,
                                                                [0]),
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_012,
                                                                [1])
                                                        ])
                                                ])
                                        ])
                                ]);
                    }

                    if (CommonReusedValues.Blob_Str_Err == local_011)
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_010,
                                                [1, 0])
                                        ])
                                ]);
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                if (local_004 == CommonReusedValues.List_fe57e752)
                {
                    Pine_PineValue local_013 =
                        Global_Anonymous.zzz_anon_84d2f7ea_77dfbc74(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [1, 0]));

                    Pine_PineValue local_014 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_013,
                            [0]);

                    if (CommonReusedValues.Blob_Str_Ok == local_014)
                    {
                        Pine_PineValue local_015 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_013,
                                [1, 0]);

                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_ConditionalExpression,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_015,
                                                                [0]),
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_015,
                                                                [1]),
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_015,
                                                                [2])
                                                        ])
                                                ])
                                        ])
                                ]);
                    }

                    if (CommonReusedValues.Blob_Str_Err == local_014)
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_013,
                                                [1, 0])
                                        ])
                                ]);
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                if (local_004 == CommonReusedValues.List_4b121161)
                {
                    return CommonReusedValues.List_b5069c25;
                }

                if (local_004 == CommonReusedValues.List_48e13149)
                {
                    return
                        Global_Anonymous.zzz_anon_b93ba29b_77dfbc74(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [1, 0]));
                }

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunctionSpecialized.concat(
                                                        CommonReusedValues.Blob_6e0d87cb,
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            local_004,
                                                            [1, 0]))
                                                ])
                                        ])
                                ])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        Pine_PineValue local_016 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_ListValue == local_016)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunction.concat(
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_db13c237,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                String.fromInt(
                                                                    Pine_KernelFunction.length(local_000)),
                                                                [1, 0]),
                                                            CommonReusedValues.Blob_4fb5f197
                                                        ]))
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_BlobValue == local_016)
        {
            return CommonReusedValues.List_deb78957;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue stringFromValue(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.List_0a078809)
        {
            return CommonReusedValues.List_7aba86e6;
        }

        if (param_1_0 == CommonReusedValues.List_aa8cd902)
        {
            return CommonReusedValues.List_487b9fe1;
        }

        if (param_1_0 == CommonReusedValues.List_fa615f0b)
        {
            return CommonReusedValues.List_28bd95f6;
        }

        if (param_1_0 == CommonReusedValues.List_4bcbcd70)
        {
            return CommonReusedValues.List_97dbe947;
        }

        if (param_1_0 == CommonReusedValues.List_b8120726)
        {
            return CommonReusedValues.List_bf69db3f;
        }

        if (param_1_0 == CommonReusedValues.List_f4325494)
        {
            return CommonReusedValues.List_8fb47f0c;
        }

        if (param_1_0 == CommonReusedValues.List_38faf44f)
        {
            return CommonReusedValues.List_53f100a3;
        }

        if (param_1_0 == CommonReusedValues.List_8a17d2aa)
        {
            return CommonReusedValues.List_fd351edd;
        }

        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            return
                Global_Anonymous.zzz_anon_fcb519b2_fdeddb64(
                    Pine_PineValue.EmptyList,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_01a75b86;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue valueFromBigInt(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_BlobValue,
                    Pine_PineValue.List(
                        [
                            Pine.blobValueFromBigInt(param_1_0)
                        ])
                ]);
    }


    public static Pine_PineValue valueFromBool(Pine_PineValue param_1_0)
    {
        if (param_1_0 == Pine_PineKernelValues.TrueValue)
        {
            return CommonReusedValues.List_fb348cf5;
        }

        return CommonReusedValues.List_c47bf601;
    }


    public static Pine_PineValue valueFromInt(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.Blob_Int_1)
        {
            return CommonReusedValues.List_08f1f9f0;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_2)
        {
            return CommonReusedValues.List_f0bf2d16;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_3)
        {
            return CommonReusedValues.List_23f668f0;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_4)
        {
            return CommonReusedValues.List_99c2ba68;
        }

        return Global_Anonymous.zzz_anon_ed3d09ec_c9abc82e(param_1_0);
    }


    public static Pine_PineValue valueFromString(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.List_f727f528)
        {
            return CommonReusedValues.List_a4a16092;
        }

        if (param_1_0 == CommonReusedValues.List_485f41ca)
        {
            return CommonReusedValues.List_8939bdec;
        }

        if (param_1_0 == CommonReusedValues.List_8ce25fef)
        {
            return CommonReusedValues.List_d4356e44;
        }

        if (param_1_0 == CommonReusedValues.List_bfbd2f47)
        {
            return CommonReusedValues.List_a7996803;
        }

        if (param_1_0 == CommonReusedValues.List_ed1ec9fc)
        {
            return CommonReusedValues.List_4bcbcd70;
        }

        if (param_1_0 == CommonReusedValues.List_84a73c03)
        {
            return CommonReusedValues.List_0a078809;
        }

        if (param_1_0 == CommonReusedValues.List_b18026e6)
        {
            return CommonReusedValues.List_aa8cd902;
        }

        if (param_1_0 == CommonReusedValues.List_ae363231)
        {
            return CommonReusedValues.List_fa615f0b;
        }

        if (param_1_0 == CommonReusedValues.List_fe57e752)
        {
            return CommonReusedValues.List_b8120726;
        }

        if (param_1_0 == CommonReusedValues.List_4b121161)
        {
            return CommonReusedValues.List_f4325494;
        }

        if (param_1_0 == CommonReusedValues.List_996f6e98)
        {
            return CommonReusedValues.List_38faf44f;
        }

        if (param_1_0 == CommonReusedValues.List_48e13149)
        {
            return CommonReusedValues.List_8a17d2aa;
        }

        return Pine.computeValueFromString(param_1_0);
    }
}
