using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Dict
{
    public static Pine_PineValue insert(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_000 =
            Global_Anonymous.zzz_anon_ea679199_b65beb0f(param_1_0, param_1_1, param_1_2);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0])))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_7222f8d4,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [2]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])
                            ])
                    ]);
        }

        return local_000;
    }


    public static Pine_PineValue keys(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return Pine_PineValue.EmptyList;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Pine_KernelFunction.concat(
                    Pine_PineValue.List(
                        [
                            Dict.keys(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3])),
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [1])
                                ]),
                            Dict.keys(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4]))
                        ]));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue remove(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, param_1_1);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0])))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_7222f8d4,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [2]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])
                            ])
                    ]);
        }

        return local_000;
    }


    public static Pine_PineValue toList(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return Pine_PineValue.EmptyList;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Pine_KernelFunction.concat(
                    Pine_PineValue.List(
                        [
                            Dict.toList(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3])),
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [2])
                                        ])
                                ]),
                            Dict.toList(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4]))
                        ]));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }
}
