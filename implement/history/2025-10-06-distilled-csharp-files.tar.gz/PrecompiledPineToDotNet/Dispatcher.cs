using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Dispatcher
{
    public static System.Collections.Generic.IReadOnlyDictionary<Pine_PineValue, System.Func<Pine_PineValue, Pine_PineValue>> dispatcherDictionary =
        BuildDispatcherDictionary();

    public static System.Collections.Generic.IReadOnlyDictionary<Pine_PineValue, System.Func<Pine_PineValue, Pine_PineValue>> BuildDispatcherDictionary()
    {
        var dict =
            new System.Collections.Generic.Dictionary<Pine_PineValue, System.Func<Pine_PineValue, Pine_PineValue>>();

        dict[CommonReusedValues.List_59345918] =
            Dispatch_59345918;

        dict[CommonReusedValues.List_e10c3e57] =
            Dispatch_e10c3e57;

        dict[CommonReusedValues.List_a418ab23] =
            Dispatch_a418ab23;

        dict[CommonReusedValues.List_0ce630f9] =
            Dispatch_0ce630f9;

        dict[CommonReusedValues.List_5055ff08] =
            Dispatch_5055ff08;

        dict[CommonReusedValues.List_523cfc6b] =
            Dispatch_523cfc6b;

        dict[CommonReusedValues.List_cfeded0e] =
            Dispatch_cfeded0e;

        dict[CommonReusedValues.List_f8cc3fb0] =
            Dispatch_f8cc3fb0;

        dict[CommonReusedValues.List_627f403e] =
            Dispatch_627f403e;

        dict[CommonReusedValues.List_497af99d] =
            Dispatch_497af99d;

        dict[CommonReusedValues.List_03d2d269] =
            Dispatch_03d2d269;

        dict[CommonReusedValues.List_ef7a3e89] =
            Dispatch_ef7a3e89;

        dict[CommonReusedValues.List_0f6e756a] =
            Dispatch_0f6e756a;

        dict[CommonReusedValues.List_f9abafe1] =
            Dispatch_f9abafe1;

        dict[CommonReusedValues.List_cf00dbf7] =
            Dispatch_cf00dbf7;

        dict[CommonReusedValues.List_0fe052e5] =
            Dispatch_0fe052e5;

        dict[CommonReusedValues.List_cbaaa061] =
            Dispatch_cbaaa061;

        dict[CommonReusedValues.List_dbf42a10] =
            Dispatch_dbf42a10;

        dict[CommonReusedValues.List_84d2f7ea] =
            Dispatch_84d2f7ea;

        dict[CommonReusedValues.List_e8f8319b] =
            Dispatch_e8f8319b;

        dict[CommonReusedValues.List_84cfa0a1] =
            Dispatch_84cfa0a1;

        dict[CommonReusedValues.List_4c530ac2] =
            Dispatch_4c530ac2;

        dict[CommonReusedValues.List_499d8a39] =
            Dispatch_499d8a39;

        dict[CommonReusedValues.List_1aac970b] =
            Dispatch_1aac970b;

        dict[CommonReusedValues.List_ac3e6060] =
            Dispatch_ac3e6060;

        dict[CommonReusedValues.List_883f2222] =
            Dispatch_883f2222;

        dict[CommonReusedValues.List_a4d551c6] =
            Dispatch_a4d551c6;

        dict[CommonReusedValues.List_05e3fa41] =
            Dispatch_05e3fa41;

        dict[CommonReusedValues.List_5d5a0297] =
            Dispatch_5d5a0297;

        dict[CommonReusedValues.List_be9c0d0e] =
            Dispatch_be9c0d0e;

        dict[CommonReusedValues.List_0bcbebeb] =
            Dispatch_0bcbebeb;

        dict[CommonReusedValues.List_654f47c2] =
            Dispatch_654f47c2;

        dict[CommonReusedValues.List_610ee3fc] =
            Dispatch_610ee3fc;

        dict[CommonReusedValues.List_1261ac32] =
            Dispatch_1261ac32;

        dict[CommonReusedValues.List_21be4dae] =
            Dispatch_21be4dae;

        dict[CommonReusedValues.List_c9f48cad] =
            Dispatch_c9f48cad;

        dict[CommonReusedValues.List_b51d0c71] =
            Dispatch_b51d0c71;

        dict[CommonReusedValues.List_ed3d09ec] =
            Dispatch_ed3d09ec;

        dict[CommonReusedValues.List_0965dc45] =
            Dispatch_0965dc45;

        dict[CommonReusedValues.List_e9c5a80a] =
            Dispatch_e9c5a80a;

        dict[CommonReusedValues.List_86fe94db] =
            Dispatch_86fe94db;

        dict[CommonReusedValues.List_da0ae47a] =
            Dispatch_da0ae47a;

        dict[CommonReusedValues.List_4cf95911] =
            Dispatch_4cf95911;

        dict[CommonReusedValues.List_d651d7e2] =
            Dispatch_d651d7e2;

        dict[CommonReusedValues.List_9a1e26cb] =
            Dispatch_9a1e26cb;

        dict[CommonReusedValues.List_c051d150] =
            Dispatch_c051d150;

        dict[CommonReusedValues.List_5707358a] =
            Dispatch_5707358a;

        dict[CommonReusedValues.List_bc4eb4fa] =
            Dispatch_bc4eb4fa;

        dict[CommonReusedValues.List_3fad4dcd] =
            Dispatch_3fad4dcd;

        dict[CommonReusedValues.List_bef7232d] =
            Dispatch_bef7232d;

        dict[CommonReusedValues.List_a53f6616] =
            Dispatch_a53f6616;

        dict[CommonReusedValues.List_bde8ecf0] =
            Dispatch_bde8ecf0;

        dict[CommonReusedValues.List_2ae48e21] =
            Dispatch_2ae48e21;

        dict[CommonReusedValues.List_7dd973c9] =
            Dispatch_7dd973c9;

        dict[CommonReusedValues.List_3c873ec4] =
            Dispatch_3c873ec4;

        dict[CommonReusedValues.List_c78b4c00] =
            Dispatch_c78b4c00;

        dict[CommonReusedValues.List_e0c3df04] =
            Dispatch_e0c3df04;

        dict[CommonReusedValues.List_94605300] =
            Dispatch_94605300;

        dict[CommonReusedValues.List_cbbe6e2b] =
            Dispatch_cbbe6e2b;

        dict[CommonReusedValues.List_dd880f82] =
            Dispatch_dd880f82;

        dict[CommonReusedValues.List_449d95bc] =
            Dispatch_449d95bc;

        dict[CommonReusedValues.List_f674d6c1] =
            Dispatch_f674d6c1;

        dict[CommonReusedValues.List_66f876e8] =
            Dispatch_66f876e8;

        dict[CommonReusedValues.List_f164dec2] =
            Dispatch_f164dec2;

        dict[CommonReusedValues.List_af114e29] =
            Dispatch_af114e29;

        dict[CommonReusedValues.List_8792c675] =
            Dispatch_8792c675;

        dict[CommonReusedValues.List_de1b5d74] =
            Dispatch_de1b5d74;

        dict[CommonReusedValues.List_7a86a9ad] =
            Dispatch_7a86a9ad;

        dict[CommonReusedValues.List_3f5c9f68] =
            Dispatch_3f5c9f68;

        dict[CommonReusedValues.List_59a0aec1] =
            Dispatch_59a0aec1;

        dict[CommonReusedValues.List_7bc9fa14] =
            Dispatch_7bc9fa14;

        dict[CommonReusedValues.List_39fa68f8] =
            Dispatch_39fa68f8;

        dict[CommonReusedValues.List_46782f74] =
            Dispatch_46782f74;

        dict[CommonReusedValues.List_e6d15ff4] =
            Dispatch_e6d15ff4;

        dict[CommonReusedValues.List_4437f6a9] =
            Dispatch_4437f6a9;

        dict[CommonReusedValues.List_b93ba29b] =
            Dispatch_b93ba29b;

        dict[CommonReusedValues.List_a94d57df] =
            Dispatch_a94d57df;

        dict[CommonReusedValues.List_16c75470] =
            Dispatch_16c75470;

        dict[CommonReusedValues.List_f890355b] =
            Dispatch_f890355b;

        dict[CommonReusedValues.List_fcb519b2] =
            Dispatch_fcb519b2;

        dict[CommonReusedValues.List_85977333] =
            Dispatch_85977333;

        dict[CommonReusedValues.List_0da2f7ed] =
            Dispatch_0da2f7ed;

        dict[CommonReusedValues.List_4822613b] =
            Dispatch_4822613b;

        dict[CommonReusedValues.List_ea679199] =
            Dispatch_ea679199;

        dict[CommonReusedValues.List_a3e95a54] =
            Dispatch_a3e95a54;

        dict[CommonReusedValues.List_a53d91b2] =
            Dispatch_a53d91b2;

        dict[CommonReusedValues.List_7b787121] =
            Dispatch_7b787121;

        dict[CommonReusedValues.List_d07b6afd] =
            Dispatch_d07b6afd;

        dict[CommonReusedValues.List_fe575105] =
            Dispatch_fe575105;

        dict[CommonReusedValues.List_a24aa480] =
            Dispatch_a24aa480;

        dict[CommonReusedValues.List_b0876be7] =
            Dispatch_b0876be7;

        dict[CommonReusedValues.List_7ab1ed41] =
            Dispatch_7ab1ed41;

        dict[CommonReusedValues.List_fa4fc55c] =
            Dispatch_fa4fc55c;

        dict[CommonReusedValues.List_c0038bd7] =
            Dispatch_c0038bd7;

        dict[CommonReusedValues.List_d97a2014] =
            Dispatch_d97a2014;

        dict[CommonReusedValues.List_2c70f359] =
            Dispatch_2c70f359;

        dict[CommonReusedValues.List_373579cd] =
            Dispatch_373579cd;

        dict[CommonReusedValues.List_d1a5cd08] =
            Dispatch_d1a5cd08;

        dict[CommonReusedValues.List_632693ae] =
            Dispatch_632693ae;

        dict[CommonReusedValues.List_9a7c1e1b] =
            Dispatch_9a7c1e1b;

        dict[CommonReusedValues.List_53226cad] =
            Dispatch_53226cad;

        dict[CommonReusedValues.List_43537b53] =
            Dispatch_43537b53;

        dict[CommonReusedValues.List_e9c3132d] =
            Dispatch_e9c3132d;

        dict[CommonReusedValues.List_838a4b21] =
            Dispatch_838a4b21;

        dict[CommonReusedValues.List_9f1a9bb1] =
            Dispatch_9f1a9bb1;

        dict[CommonReusedValues.List_462b85bd] =
            Dispatch_462b85bd;

        dict[CommonReusedValues.List_36238402] =
            Dispatch_36238402;

        dict[CommonReusedValues.List_0574805a] =
            Dispatch_0574805a;

        dict[CommonReusedValues.List_6aa05e39] =
            Dispatch_6aa05e39;

        dict[CommonReusedValues.List_16bfc3e7] =
            Dispatch_16bfc3e7;

        dict[CommonReusedValues.List_bfc30c6e] =
            Dispatch_bfc30c6e;

        dict[CommonReusedValues.List_dc80c2ca] =
            Dispatch_dc80c2ca;

        dict[CommonReusedValues.List_a8fb97b7] =
            Dispatch_a8fb97b7;

        dict[CommonReusedValues.List_097a0bb9] =
            Dispatch_097a0bb9;

        dict[CommonReusedValues.List_985c9717] =
            Dispatch_985c9717;

        dict[CommonReusedValues.List_6aadd8cd] =
            Dispatch_6aadd8cd;

        dict[CommonReusedValues.List_2486a52f] =
            Dispatch_2486a52f;

        dict[CommonReusedValues.List_27a778a0] =
            Dispatch_27a778a0;

        dict[CommonReusedValues.List_f993b96d] =
            Dispatch_f993b96d;

        dict[CommonReusedValues.List_d581fb54] =
            Dispatch_d581fb54;

        dict[CommonReusedValues.List_3a676c26] =
            Dispatch_3a676c26;

        dict[CommonReusedValues.List_4b20c2f9] =
            Dispatch_4b20c2f9;

        dict[CommonReusedValues.List_f0fcb884] =
            Dispatch_f0fcb884;

        dict[CommonReusedValues.List_4291181e] =
            Dispatch_4291181e;

        dict[CommonReusedValues.List_c642c660] =
            Dispatch_c642c660;

        dict[CommonReusedValues.List_ebe3e9de] =
            Dispatch_ebe3e9de;

        dict[CommonReusedValues.List_8f05f0b7] =
            Dispatch_8f05f0b7;

        dict[CommonReusedValues.List_d9b5deb8] =
            Dispatch_d9b5deb8;

        dict[CommonReusedValues.List_a5c995b4] =
            Dispatch_a5c995b4;

        dict[CommonReusedValues.List_88e1499a] =
            Dispatch_88e1499a;

        dict[CommonReusedValues.List_26524eca] =
            Dispatch_26524eca;

        dict[CommonReusedValues.List_1c3c9562] =
            Dispatch_1c3c9562;

        dict[CommonReusedValues.List_30535a07] =
            Dispatch_30535a07;

        dict[CommonReusedValues.List_918cbc6b] =
            Dispatch_918cbc6b;

        dict[CommonReusedValues.List_d6ebdb03] =
            Dispatch_d6ebdb03;

        dict[CommonReusedValues.List_12af8dcc] =
            Dispatch_12af8dcc;

        dict[CommonReusedValues.List_563fe0ad] =
            Dispatch_563fe0ad;

        dict[CommonReusedValues.List_f1cd4f95] =
            Dispatch_f1cd4f95;

        dict[CommonReusedValues.List_abb59323] =
            Dispatch_abb59323;

        dict[CommonReusedValues.List_51a2e76d] =
            Dispatch_51a2e76d;

        dict[CommonReusedValues.List_e9b2c03b] =
            Dispatch_e9b2c03b;

        return dict;
    }


    public static Pine_PineValue? Dispatch_59345918(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_59345918_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e10c3e57(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.kernelFunction_negate(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a418ab23(Pine_PineValue environment)
    {
        if ((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a418ab23_4792582f(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0ce630f9(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Bitwise.xor(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_5055ff08(Pine_PineValue environment)
    {
        if (((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_6aa05e39) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_3a676c26)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0fe052e5)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_8792c675)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ebe3e9de)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_102986a4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_5055ff08)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_563fe0ad))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.encodeExpressionAsValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_523cfc6b(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0f6e756a) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_12af8dcc)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_632693ae)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.fromInt(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_cfeded0e(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return String.padLeft(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f8cc3fb0(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f8cc3fb0)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_627f403e(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_d97a2014) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_627f403e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_627f403e_dca18c16(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_497af99d(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_497af99d)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_497af99d_6d5fdbe8(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_03d2d269(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_bfd246c7) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_03d2d269))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_03d2d269_8e4089c4(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_ef7a3e89(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ef7a3e89)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Dict.toList(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0f6e756a(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_12af8dcc) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_632693ae)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_0f6e756a_a4f70149(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f9abafe1(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_85977333) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_5a3689a2))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_f9abafe1_9bce9a70(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_cf00dbf7(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_cf00dbf7)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0fe052e5(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_8792c675) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ebe3e9de)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_102986a4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_29bf1180))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.computeValueFromString(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_cbaaa061(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_a8fb97b7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_cbaaa061_7d092ddb(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_dbf42a10(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_53226cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_1aac970b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_0da2f7ed))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_dbf42a10_90befd56(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_84d2f7ea(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_84d2f7ea_77dfbc74(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e8f8319b(Pine_PineValue environment)
    {
        if (((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_30535a07)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_5a3689a2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_4c530ac2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_883f2222)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_499d8a39)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_85977333))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_e8f8319b_de2c21b3(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_84cfa0a1(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_84cfa0a1)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_84cfa0a1_4c3796cb(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4c530ac2(Pine_PineValue environment)
    {
        if (((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_be962ed7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.valueFromBigInt(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_499d8a39(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_74036b6f) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_5a3689a2))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.bigIntFromBlobValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_1aac970b(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0da2f7ed)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_1aac970b_200123d4(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_ac3e6060(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_7dd973c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_c051d150)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_e6d15ff4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_59345918)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_fe575105)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f164dec2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_ac3e6060)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_ac3e6060_386942a1(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_883f2222(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_499d8a39) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_5a3689a2))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.bigIntFromValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a4d551c6(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_bde8ecf0) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1, 1, 0]) == CommonReusedValues.List_4291181e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a4d551c6_9577ce8c(arg_1_0, arg_1_1);
        }

        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_86fe94db) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1, 1, 0]) == CommonReusedValues.List_b51d0c71))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a4d551c6_9e8e4732(arg_1_0, arg_1_1);
        }

        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_bde8ecf0) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1, 1, 0]) == CommonReusedValues.List_0ce630f9))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a4d551c6_1b1ad183(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_05e3fa41(Pine_PineValue environment)
    {
        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_c9f48cad))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Json.Decode.parseJsonStringToValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_5d5a0297(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3f5c9f68) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_9a1e26cb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f8cc3fb0))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.modBy(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_be9c0d0e(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_74036b6f) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_a8fb97b7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.intFromValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0bcbebeb(Pine_PineValue environment)
    {
        if ((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_be962ed7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.blobValueFromBigInt(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_654f47c2(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_654f47c2_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_610ee3fc(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_462b85bd) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_610ee3fc))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_610ee3fc_622604de(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_1261ac32(Pine_PineValue environment)
    {
        if (((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_84cfa0a1))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_1261ac32_458f62e0(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_21be4dae(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_21be4dae_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_c9f48cad(Pine_PineValue environment)
    {
        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 24]) == CommonReusedValues.List_5014ad60))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_c9f48cad_c41a8a1a(arg_1_0, arg_1_1, arg_1_2);
        }

        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_94a311c8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_c9f48cad_2f3c7b11(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_b51d0c71(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Bitwise.and(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_ed3d09ec(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_bfc30c6e) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_21be4dae))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_ed3d09ec_c9abc82e(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0965dc45(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_0965dc45) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0, 1, 0]) == CommonReusedValues.List_b51d0c71)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1, 1, 0]) == CommonReusedValues.List_4291181e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2, 1, 0]) == CommonReusedValues.List_d1a5cd08))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            return Global_Anonymous.zzz_anon_0965dc45_5db01df0(arg_1_0, arg_1_1, arg_1_2, arg_1_3);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e9c5a80a(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c642c660) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_03d2d269)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_e9c5a80a_a6ea216c(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_86fe94db(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_86fe94db) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0, 1, 0]) == CommonReusedValues.List_b51d0c71))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_86fe94db_dcf85806(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_da0ae47a(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_ee42155c))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.stringFromValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4cf95911(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_4cf95911))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_4cf95911_826201ed(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d651d7e2(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_497af99d)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_d651d7e2_6d5fdbe8(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_9a1e26cb(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f8cc3fb0)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.idiv(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_c051d150(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_c051d150_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_5707358a(Pine_PineValue environment)
    {
        if (((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_3fad4dcd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_a8fb97b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_c642c660))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_5707358a_d505fcbe(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_bc4eb4fa(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c78b4c00) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_6aadd8cd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_097a0bb9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.compareList(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_3fad4dcd(Pine_PineValue environment)
    {
        if ((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_a8fb97b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_3fad4dcd))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_3fad4dcd_ba70c3a8(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_bef7232d(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_bef7232d)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return String.toListRecursive(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a53f6616(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a4d551c6) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bde8ecf0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2, 1, 0]) == CommonReusedValues.List_4291181e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_a53f6616_fef8748c(arg_1_0);
        }

        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a4d551c6) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_86fe94db)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2, 1, 0]) == CommonReusedValues.List_b51d0c71))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_a53f6616_0ba75d05(arg_1_0);
        }

        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a4d551c6) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bde8ecf0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2, 1, 0]) == CommonReusedValues.List_0ce630f9))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_a53f6616_9436b59a(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_bde8ecf0(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bde8ecf0) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0, 1, 0]) == CommonReusedValues.List_0ce630f9))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_bde8ecf0_3959ade7(arg_1_0, arg_1_1, arg_1_2);
        }

        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bde8ecf0) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0, 1, 0]) == CommonReusedValues.List_4291181e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_bde8ecf0_d5148ce6(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_2ae48e21(Pine_PineValue environment)
    {
        if ((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c0038bd7) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_5d5a0297)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_3f5c9f68)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_9a1e26cb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_f8cc3fb0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_7ab1ed41))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_2ae48e21_d3dea4b1(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_7dd973c9(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c051d150)
        {
            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            var arg_1_4 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 4]);

            var arg_1_5 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 5]);

            var arg_1_6 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 6]);

            return Global_Anonymous.zzz_anon_7dd973c9_1b8db7d8(arg_1_1, arg_1_2, arg_1_3, arg_1_4, arg_1_5, arg_1_6);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_3c873ec4(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_3c873ec4_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_c78b4c00(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_c78b4c00_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e0c3df04(Pine_PineValue environment)
    {
        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_94a311c8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_e0c3df04_2f3c7b11(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_94605300(Pine_PineValue environment)
    {
        if (((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_2ae48e21) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_c0038bd7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_5d5a0297)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_3f5c9f68)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_9a1e26cb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_f8cc3fb0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_7ab1ed41))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.mul(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_cbbe6e2b(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.parseExpressionFromValue(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_dd880f82(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3c873ec4) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_abb59323)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ef7a3e89)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f674d6c1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_dd880f82))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_dd880f82_13e5e91e(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_449d95bc(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_d97a2014) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_449d95bc))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_449d95bc_da6f86d5(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f674d6c1(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3c873ec4) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_abb59323)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ef7a3e89)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f674d6c1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_dd880f82))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.eq(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_66f876e8(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_2c70f359) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_a60c0379))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return BigInt.lt(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f164dec2(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f164dec2)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_f164dec2_b6de04bb(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_af114e29(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_4822613b) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_cf00dbf7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_af114e29_9571f2bd(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_8792c675(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ebe3e9de) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_102986a4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_8792c675))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_8792c675_ffb0335e(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_de1b5d74(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_4cf95911))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_de1b5d74_826201ed(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_7a86a9ad(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_74036b6f)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return BigInt.toString(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_3f5c9f68(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_9a1e26cb) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_f8cc3fb0))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.remainderBy(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_59a0aec1(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_a8fb97b7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_59a0aec1_7d092ddb(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_7bc9fa14(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a94d57df) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_8f05f0b7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_7bc9fa14_86a90fcf(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_39fa68f8(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_39fa68f8)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_39fa68f8_2402eeb0(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_46782f74(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f1cd4f95)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_46782f74_0d2b56f6(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e6d15ff4(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            var arg_1_4 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 4]);

            return Global_Anonymous.zzz_anon_e6d15ff4_dda26649(arg_1_0, arg_1_1, arg_1_2, arg_1_3, arg_1_4);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4437f6a9(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ac3e6060)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_7dd973c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_c051d150)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_e6d15ff4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_59345918)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_fe575105)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_f164dec2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Dict.remove(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_b93ba29b(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_b93ba29b_77dfbc74(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a94d57df(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a94d57df) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_8f05f0b7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a94d57df_86a90fcf(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_16c75470(Pine_PineValue environment)
    {
        if (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_43537b53)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_0965dc45)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_a8fb97b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_e9b2c03b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_9f1a9bb1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_d651d7e2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_497af99d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_a53f6616)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_bde8ecf0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_a53f6616)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_bde8ecf0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 21]) == CommonReusedValues.List_a53f6616)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 22]) == CommonReusedValues.List_a4d551c6)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 23]) == CommonReusedValues.List_86fe94db)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 24]) == CommonReusedValues.List_5707358a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 25]) == CommonReusedValues.List_3fad4dcd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 26]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 27]) == CommonReusedValues.List_c642c660)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 28]) == CommonReusedValues.List_e8f8319b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 29]) == CommonReusedValues.List_30535a07)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 30]) == CommonReusedValues.List_5a3689a2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 31]) == CommonReusedValues.List_4c530ac2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 32]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 33]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 34]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 35]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 36]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 37]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 38]) == CommonReusedValues.List_883f2222)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 39]) == CommonReusedValues.List_499d8a39)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 40]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 41]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 42]) == CommonReusedValues.List_373579cd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 43]) == CommonReusedValues.List_7b787121)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 44]) == CommonReusedValues.List_27a778a0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 45]) == CommonReusedValues.List_7bc9fa14)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 46]) == CommonReusedValues.List_a94d57df)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 47]) == CommonReusedValues.List_8f05f0b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 48]) == CommonReusedValues.List_654f47c2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 49]) == CommonReusedValues.List_cbaaa061)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 50]) == CommonReusedValues.List_59a0aec1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 51]) == CommonReusedValues.List_4b20c2f9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 52]) == CommonReusedValues.List_51a2e76d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 53]) == CommonReusedValues.List_ed3d09ec)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 54]) == CommonReusedValues.List_bfc30c6e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 55]) == CommonReusedValues.List_21be4dae)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 56]) == CommonReusedValues.List_e10c3e57)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 57]) == CommonReusedValues.List_e9c5a80a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 58]) == CommonReusedValues.List_03d2d269)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4, 1, 0]) == CommonReusedValues.List_b51d0c71)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5, 1, 0]) == CommonReusedValues.List_4291181e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6, 1, 0]) == CommonReusedValues.List_d1a5cd08)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17, 1, 0]) == CommonReusedValues.List_0ce630f9))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_16c75470_619d9835(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f890355b(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_097a0bb9) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_c78b4c00)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_6aadd8cd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.lt(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_fcb519b2(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_fcb519b2_fdeddb64(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_85977333(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_5a3689a2) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_85977333))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_85977333_337866fd(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0da2f7ed(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0da2f7ed)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_0da2f7ed_200123d4(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4822613b(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_26524eca) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_cf00dbf7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_4822613b_206e486b(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_ea679199(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_a60c0379)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_e6d15ff4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_ea679199))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_ea679199_b65beb0f(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a3e95a54(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_a3e95a54_77dfbc74(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a53d91b2(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_a53d91b2_dda26649(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_7b787121(Pine_PineValue environment)
    {
        if (((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_4c530ac2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_883f2222)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_499d8a39)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_5a3689a2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_7b787121))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_7b787121_316577ef(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d07b6afd(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_d07b6afd)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_d07b6afd_ce09a77f(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_fe575105(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_e6d15ff4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_59345918)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fe575105))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_fe575105_eb1f9043(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a24aa480(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a24aa480)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Json.Decode.skipWhitespace(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_b0876be7(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_b0876be7)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            return Global_Anonymous.zzz_anon_b0876be7_3c458f0b(arg_1_0, arg_1_1, arg_1_2, arg_1_3);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_7ab1ed41(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Basics.abs(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_fa4fc55c(Pine_PineValue environment)
    {
        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_20a0bc5e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_fa4fc55c_7edd4fd7(arg_1_0, arg_1_1, arg_1_2);
        }

        if (((((((((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_de1b5d74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_46782f74)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f1cd4f95)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_4cf95911)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_1261ac32)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_a53d91b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_2486a52f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_1c3c9562)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 15]) == CommonReusedValues.List_a24aa480)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 16]) == CommonReusedValues.List_a418ab23)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 17]) == CommonReusedValues.List_e0c3df04)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 18]) == CommonReusedValues.List_fa4fc55c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 19]) == CommonReusedValues.List_c9f48cad)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 20]) == CommonReusedValues.List_94a311c8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_fa4fc55c_2f3c7b11(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_c0038bd7(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_5d5a0297) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_3f5c9f68)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_9a1e26cb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f8cc3fb0)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_c0038bd7))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_c0038bd7_adba204d(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d97a2014(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_d97a2014_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_2c70f359(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a60c0379)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return BigInt.compare(arg_1_0, arg_1_1);
        }

        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ee42155c)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return BigInt.mul(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_373579cd(Pine_PineValue environment)
    {
        if (((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_7b787121)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_4c530ac2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_883f2222)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_499d8a39)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_5a3689a2))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_373579cd_b210e8cb(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d1a5cd08(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Bitwise.shiftRightBy(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_632693ae(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_29bf1180) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_39fa68f8)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_632693ae))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_632693ae_2f148225(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_9a7c1e1b(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_2d243751)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_7dd973c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_c051d150)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_e6d15ff4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_59345918)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_fe575105)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f164dec2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_ac3e6060)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_9a7c1e1b_386942a1(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_53226cad(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_1aac970b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0da2f7ed))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.toInt(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_43537b53(Pine_PineValue environment)
    {
        if (((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0965dc45)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_a8fb97b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3, 1, 0]) == CommonReusedValues.List_b51d0c71)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4, 1, 0]) == CommonReusedValues.List_4291181e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5, 1, 0]) == CommonReusedValues.List_d1a5cd08))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_43537b53_ffce8e79(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e9c3132d(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_e9c3132d_77dfbc74(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_838a4b21(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return BigInt.negate(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_9f1a9bb1(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_9f1a9bb1) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0, 1, 0]) == CommonReusedValues.List_b51d0c71)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1, 1, 0]) == CommonReusedValues.List_4291181e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2, 1, 0]) == CommonReusedValues.List_d1a5cd08))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            return Global_Anonymous.zzz_anon_9f1a9bb1_3c85cbf2(arg_1_0, arg_1_1, arg_1_2, arg_1_3);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_462b85bd(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return List.cons(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_36238402(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_627f403e) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trimRight(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_0574805a(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0574805a)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_0574805a_a91f9a5b(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_6aa05e39(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_6aa05e39_dda26649(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_16bfc3e7(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ee42155c) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f993b96d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_918cbc6b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_838a4b21))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return BigInt.divmod(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_bfc30c6e(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_21be4dae)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_bfc30c6e_17f089c2(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_dc80c2ca(Pine_PineValue environment)
    {
        if ((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_6ae0bfaa)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_dc80c2ca))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_dc80c2ca_c4ab872f(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a8fb97b7(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_a8fb97b7)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Pine.intFromUnsignedBlobValue(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_097a0bb9(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c78b4c00) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_6aadd8cd)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_097a0bb9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.compare(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_985c9717(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ea679199)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a60c0379)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_e6d15ff4))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Dict.insert(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_6aadd8cd(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_6aadd8cd)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Basics.compareStrings(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_2486a52f(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_2486a52f_dda26649(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_27a778a0(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_27a778a0_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f993b96d(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_918cbc6b) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_838a4b21))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_f993b96d_69cecf0f(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d581fb54(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0574805a)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return String.contains(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_3a676c26(Pine_PineValue environment)
    {
        if (((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0fe052e5) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_8792c675)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ebe3e9de)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_102986a4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_29bf1180))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.valueFromString(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4b20c2f9(Pine_PineValue environment)
    {
        if ((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_51a2e76d) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ed3d09ec)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfc30c6e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_21be4dae))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_4b20c2f9_41ec3ad3(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f0fcb884(Pine_PineValue environment)
    {
        if (((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_f0fcb884_77dfbc74(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_4291181e(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Bitwise.or(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_c642c660(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.valueFromBool(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_ebe3e9de(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_102986a4) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.blobBytesFromChar(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_8f05f0b7(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_8f05f0b7)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_8f05f0b7_280b0958(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d9b5deb8(Pine_PineValue environment)
    {
        if ((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_da0ae47a)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fcb519b2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ee42155c)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_cbbe6e2b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_a3e95a54)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_e9c3132d)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f0fcb884)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_84d2f7ea)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_b93ba29b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_d9b5deb8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_d9b5deb8_8d69932f(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_a5c995b4(Pine_PineValue environment)
    {
        if ((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_449d95bc) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trimLeft(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_88e1499a(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_449d95bc) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_627f403e))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trim(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_26524eca(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_cf00dbf7)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_26524eca_71eb7c46(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_1c3c9562(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_1c3c9562_dda26649(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_30535a07(Pine_PineValue environment)
    {
        if (((((((((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_5a3689a2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_4c530ac2)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_0bcbebeb)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_bfd246c7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_6d99632b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_45e383b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_6c3210c9)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_be962ed7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_883f2222)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_499d8a39)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 11]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 12]) == CommonReusedValues.List_f9abafe1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 13]) == CommonReusedValues.List_85977333)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 14]) == CommonReusedValues.List_30535a07))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_30535a07_e24370a9(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_918cbc6b(Pine_PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.add(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_d6ebdb03(Pine_PineValue environment)
    {
        if (((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_af114e29)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_4822613b)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_26524eca)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_cf00dbf7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_84cfa0a1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_d6ebdb03))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_d6ebdb03_28e23645(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_12af8dcc(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_632693ae) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_12af8dcc_650df00b(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_563fe0ad(Pine_PineValue environment)
    {
        if (((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_6aa05e39) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_3a676c26)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0fe052e5)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_8792c675)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_ebe3e9de)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_102986a4)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_5055ff08)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_563fe0ad))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_563fe0ad_14c12277(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_f1cd4f95(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f1cd4f95)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_abb59323(Pine_PineValue environment)
    {
        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_abb59323)
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Dict.keys(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_51a2e76d(Pine_PineValue environment)
    {
        if (((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ed3d09ec) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_bfc30c6e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_21be4dae))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Pine.valueFromInt(arg_1_0);
        }

        return null;
    }


    public static Pine_PineValue? Dispatch_e9b2c03b(Pine_PineValue environment)
    {
        if (((((((((Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_9f1a9bb1)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_be9c0d0e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_74036b6f)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_a8fb97b7)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3, 1, 0]) == CommonReusedValues.List_b51d0c71)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4, 1, 0]) == CommonReusedValues.List_4291181e)) && (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5, 1, 0]) == CommonReusedValues.List_d1a5cd08))
        {
            var arg_1_0 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_e9b2c03b_22efcada(arg_1_0);
        }

        return null;
    }
}
