using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class BigInt
{
    public static Pine_PineValue compare(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Basics.compare(param_1_0, param_1_1);
    }


    public static Pine_PineValue divmod(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_1 == CommonReusedValues.Blob_Int_0)
        {
            return CommonReusedValues.List_13731c89;
        }

        Pine_PineValue local_000 =
            Basics.idiv(param_1_0, param_1_1);

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    local_000,
                                    Global_Anonymous.zzz_anon_f993b96d_69cecf0f(
                                        param_1_0,
                                        Basics.mul(local_000, param_1_1))
                                ])
                        ])
                ]);
    }


    public static Pine_PineValue lt(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return
            Pine_KernelFunctionSpecialized.equal(
                BigInt.compare(param_1_0, param_1_1),
                CommonReusedValues.List_af0e3cad);
    }


    public static Pine_PineValue mul(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Basics.mul(param_1_0, param_1_1);
    }


    public static Pine_PineValue negate(Pine_PineValue param_1_0)
    {
        return Pine_KernelFunction.negate(param_1_0);
    }


    public static Pine_PineValue toString(Pine_PineValue param_1_0)
    {
        return String.fromInt(param_1_0);
    }
}
