using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Bitwise
{
    public static Pine_PineValue and(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                        CommonReusedValues.Blob_a8b57991))),
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                        CommonReusedValues.Blob_a8b57991))));

        if (Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    -2_147_483_648,
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.ValueFromBool(true),
                        Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                0,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(true),
                    Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
    }


    public static Pine_PineValue or(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.bit_or(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                        CommonReusedValues.Blob_a8b57991))),
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                        CommonReusedValues.Blob_a8b57991))));

        if (Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    -2_147_483_648,
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.ValueFromBool(true),
                        Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                0,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(true),
                    Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
    }


    public static Pine_PineValue shiftRightBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(-2_147_483_648, param_1_1, 2_147_483_647) == Pine_PineKernelValues.TrueValue)
        {
            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1))
            {
                return
                    Pine_KernelFunctionSpecialized.int_add(
                        0,
                        Pine_KernelFunctionSpecialized.concat(
                            Pine_KernelFunction.ValueFromBool(true),
                            Pine_KernelFunction.bit_shift_right(
                                Pine_PineValue.List(
                                    [
                                        param_1_0,
                                        Pine_KernelFunctionSpecialized.skip(
                                            1,
                                            Pine_KernelFunctionSpecialized.int_add(0, param_1_1))
                                    ]))));
            }

            return
                Pine_KernelFunctionSpecialized.int_add(
                    0,
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.ValueFromBool(false),
                        Pine_KernelFunction.bit_shift_right(
                            Pine_PineValue.List(
                                [
                                    param_1_0,
                                    Pine_KernelFunctionSpecialized.skip(
                                        1,
                                        Pine_KernelFunctionSpecialized.int_add(-1, param_1_1))
                                ]))));
        }

        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.bit_and(param_1_1, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c
            ?
            Pine_KernelFunctionSpecialized.int_add(
                -2_147_483_648,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(true),
                    Pine_KernelFunctionSpecialized.bit_and(param_1_1, CommonReusedValues.Blob_1d285b09)))
            :
            Pine_KernelFunctionSpecialized.int_add(
                -1,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(false),
                    Pine_KernelFunctionSpecialized.bit_and(param_1_1, CommonReusedValues.Blob_1d285b09)));

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, local_000))
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    0,
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.ValueFromBool(true),
                        Pine_KernelFunction.bit_shift_right(
                            Pine_PineValue.List(
                                [
                                    param_1_0,
                                    Pine_KernelFunctionSpecialized.skip(
                                        1,
                                        Pine_KernelFunctionSpecialized.int_add(0, local_000))
                                ]))));
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                0,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(false),
                    Pine_KernelFunction.bit_shift_right(
                        Pine_PineValue.List(
                            [
                                param_1_0,
                                Pine_KernelFunctionSpecialized.skip(
                                    1,
                                    Pine_KernelFunctionSpecialized.int_add(-1, local_000))
                            ]))));
    }


    public static Pine_PineValue xor(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.bit_xor(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                        CommonReusedValues.Blob_a8b57991))),
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1)
                ?
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)
                :
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
                ?
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                        CommonReusedValues.Blob_e429d1a2))
                :
                Pine_KernelFunction.bit_not(
                    Pine_KernelFunctionSpecialized.bit_and(
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                        CommonReusedValues.Blob_a8b57991))));

        if (Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    -2_147_483_648,
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.ValueFromBool(true),
                        Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                0,
                Pine_KernelFunctionSpecialized.concat(
                    Pine_KernelFunction.ValueFromBool(true),
                    Pine_KernelFunctionSpecialized.bit_and(local_000, CommonReusedValues.Blob_1d285b09)));
    }
}
