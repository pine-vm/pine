using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ExpressionEncoding = global::Pine.Core.CommonEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.CommonEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.CommonEncodings.StringEncoding;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;

namespace PrecompiledPineToDotNet;

public static class Basics
{
    public static Pine_PineValue abs(Pine_PineValue param_1_0)
    {
        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0))
        {
            return param_1_0;
        }

        return Pine_KernelFunctionSpecialized.int_mul(-1, param_1_0);
    }


    public static Pine_PineValue add(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Pine_KernelFunctionSpecialized.int_add(param_1_0, param_1_1);
    }


    public static Pine_PineValue compare(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_0 == param_1_1)
        {
            return CommonReusedValues.List_ac855cb8;
        }

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_1,
                [0]);

        if ((CommonReusedValues.Blob_Str_String == local_001) && (CommonReusedValues.Blob_Str_String == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return
                Basics.compareStrings(
                    CommonReusedValues.Blob_Int_0,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]),
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_1,
                        [1, 0]));
        }

        Pine_PineValue local_002 =
            Pine_KernelFunction.ValueFromBool(
                CommonReusedValues.Blob_Str_Elm_Float == local_001);

        if ((local_002 == Pine_PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            Pine_PineValue local_004 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            if (Pine_KernelFunctionSpecialized.int_mul(
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0]),
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_004,
                    [1])) == Pine_KernelFunctionSpecialized.int_mul(
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_004,
                    [0]),
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [1])))
            {
                return CommonReusedValues.List_ac855cb8;
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(
                Pine_KernelFunctionSpecialized.int_mul(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_003,
                        [0]),
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [1])),
                Pine_KernelFunctionSpecialized.int_mul(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [0]),
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_003,
                        [1]))))
            {
                return CommonReusedValues.List_af0e3cad;
            }

            return CommonReusedValues.List_50724673;
        }

        if (CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            Pine_PineValue local_005 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_005,
                [0]) == Pine_KernelFunctionSpecialized.int_mul(
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_005,
                    [1]),
                param_1_1))
            {
                return CommonReusedValues.List_ac855cb8;
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_005,
                    [0]),
                Pine_KernelFunctionSpecialized.int_mul(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [1]),
                    param_1_1)))
            {
                return CommonReusedValues.List_af0e3cad;
            }

            return CommonReusedValues.List_50724673;
        }

        if (local_002 == Pine_PineKernelValues.TrueValue)
        {
            Pine_PineValue local_006 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            if (Pine_KernelFunctionSpecialized.int_mul(
                param_1_0,
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [1])) == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_006,
                [0]))
            {
                return CommonReusedValues.List_ac855cb8;
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(
                Pine_KernelFunctionSpecialized.int_mul(
                    param_1_0,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_006,
                        [1])),
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0])))
            {
                return CommonReusedValues.List_af0e3cad;
            }

            return CommonReusedValues.List_50724673;
        }

        if (Global_Anonymous.zzz_anon_c78b4c00_dda26649(param_1_0) == Pine_PineKernelValues.TrueValue)
        {
            return Basics.compareList(param_1_0, param_1_1);
        }

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(param_1_0, param_1_1))
        {
            return CommonReusedValues.List_af0e3cad;
        }

        return CommonReusedValues.List_50724673;
    }


    public static Pine_PineValue compareList(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableSliceBuilder local_param_1_0 =
            Pine_ImmutableSliceBuilder.Create(param_1_0);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (local_param_1_0.IsEmptyList())
            {
                if (local_param_1_1.IsEmptyList())
                {
                    return CommonReusedValues.List_ac855cb8;
                }

                return CommonReusedValues.List_af0e3cad;
            }

            if (!(local_param_1_0.GetLength() == 0))
            {
                if (local_param_1_1.IsEmptyList())
                {
                    return CommonReusedValues.List_50724673;
                }

                if (!(local_param_1_1.GetLength() == 0))
                {
                    Pine_PineValue local_004 =
                        Basics.compare(
                            local_param_1_0.GetHead(),
                            local_param_1_1.GetHead());

                    if (local_004 == CommonReusedValues.List_ac855cb8)
                    {
                        {
                            local_param_1_0 =
                                local_param_1_0.Skip(1);

                            local_param_1_1 =
                                local_param_1_1.Skip(1);
                        }

                        continue;
                    }

                    return local_004;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue compareStrings(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_0, argument: local_param_1_1);

            Pine_PineValue local_001 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_0, argument: local_param_1_2);

            Pine_PineValue local_002 =
                Pine_IntegerEncoding.EncodeSignedInteger(
                    Pine_KernelFunctionSpecialized.length_as_int(local_001));

            Pine_PineValue local_004 =
                Pine_KernelFunction.ValueFromBool(
                    local_002 == CommonReusedValues.Blob_Int_0);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                if (local_004 == Pine_PineKernelValues.TrueValue)
                {
                    return CommonReusedValues.List_ac855cb8;
                }

                return CommonReusedValues.List_af0e3cad;
            }

            if (local_004 == Pine_PineKernelValues.TrueValue)
            {
                return CommonReusedValues.List_50724673;
            }

            if (local_000 == local_001)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_0);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(
                Pine_KernelFunctionSpecialized.concat(
                    Pine_IntegerEncoding.EncodeSignedInteger(0),
                    local_000),
                Pine_KernelFunctionSpecialized.concat(
                    Pine_IntegerEncoding.EncodeSignedInteger(0),
                    local_001)))
            {
                return CommonReusedValues.List_af0e3cad;
            }

            return CommonReusedValues.List_50724673;
        }
    }


    public static Pine_PineValue eq(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_0 == param_1_1)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_Elm_Float == local_001)
        {
            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]) == param_1_1)
            {
                return
                    Pine_KernelFunctionSpecialized.equal(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_002,
                            [1]),
                        Pine_IntegerEncoding.EncodeSignedInteger(1));
            }

            return Pine_PineKernelValues.FalseValue;
        }

        if (CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_1,
            [0]))
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            if (param_1_0 == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [0]))
            {
                return
                    Pine_KernelFunctionSpecialized.equal(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [1]),
                        Pine_IntegerEncoding.EncodeSignedInteger(1));
            }

            return Pine_PineKernelValues.FalseValue;
        }

        if (Global_Anonymous.zzz_anon_3c873ec4_dda26649(param_1_0) == Pine_PineKernelValues.TrueValue)
        {
            return Pine_PineKernelValues.FalseValue;
        }

        if (Pine_KernelFunctionSpecialized.length_as_int(param_1_0) == Pine_KernelFunctionSpecialized.length_as_int(param_1_1))
        {
            if (CommonReusedValues.Blob_Str_String == local_001)
            {
                return Pine_PineKernelValues.FalseValue;
            }

            if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_001)
            {
                return
                    Pine_KernelFunctionSpecialized.equal(
                        Dict.toList(param_1_0),
                        Dict.toList(param_1_1));
            }

            if (CommonReusedValues.Blob_Str_Set_elm_builtin == local_001)
            {
                return
                    Pine_KernelFunctionSpecialized.equal(
                        Dict.keys(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                param_1_0,
                                [1, 0])),
                        Dict.keys(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                param_1_1,
                                [1, 0])));
            }

            return Global_Anonymous.zzz_anon_dd880f82_13e5e91e(param_1_0, param_1_1);
        }

        return Pine_PineKernelValues.FalseValue;
    }


    public static Pine_PineValue idiv(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_1 == CommonReusedValues.Blob_Int_0)
        {
            return CommonReusedValues.Blob_Int_0;
        }

        Pine_PineValue local_001 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0));

        Pine_PineValue local_003 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1));

        Pine_PineValue local_004 =
            local_001 == Pine_PineKernelValues.TrueValue
            ?
            param_1_0
            :
            Pine_KernelFunctionSpecialized.int_mul(-1, param_1_0);

        Pine_PineValue local_005 =
            local_003 == Pine_PineKernelValues.TrueValue
            ?
            param_1_1
            :
            Pine_KernelFunctionSpecialized.int_mul(-1, param_1_1);

        Pine_PineValue local_008 =
            Global_Anonymous.zzz_anon_6dc95117_ab4922f9(local_004, local_005, CommonReusedValues.Blob_Int_0);

        if ((local_001 == Pine_PineKernelValues.TrueValue
        ?
        false
        :
        true) == (local_003 == Pine_PineKernelValues.TrueValue
        ?
        false
        :
        true))
        {
            return local_008;
        }

        return Pine_KernelFunctionSpecialized.int_mul(-1, local_008);
    }


    public static Pine_PineValue lt(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return
            Pine_KernelFunctionSpecialized.equal(
                Basics.compare(param_1_0, param_1_1),
                CommonReusedValues.List_af0e3cad);
    }


    public static Pine_PineValue modBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_0 == CommonReusedValues.Blob_Int_1)
        {
            return CommonReusedValues.Blob_Int_0;
        }

        Pine_PineValue local_003 =
            Basics.remainderBy(param_1_0, param_1_1);

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, local_003))
        {
            return local_003;
        }

        return Pine_KernelFunctionSpecialized.int_add(local_003, param_1_0);
    }


    public static Pine_PineValue mul(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunction.ValueFromBool(
                CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [0]));

        if ((local_000 == Pine_PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            return
                Global_Anonymous.zzz_anon_74bc1f66_d57fd836(
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.int_mul(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [0]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [0])),
                            Pine_KernelFunctionSpecialized.int_mul(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [1]))
                        ]));
        }

        if (CommonReusedValues.Blob_Str_Elm_Float == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Global_Anonymous.zzz_anon_74bc1f66_d57fd836(
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.int_mul(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_003,
                                    [0]),
                                param_1_1),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_003,
                                [1])
                        ]));
        }

        if (local_000 == Pine_PineKernelValues.TrueValue)
        {
            Pine_PineValue local_004 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            return
                Global_Anonymous.zzz_anon_74bc1f66_d57fd836(
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.int_mul(
                                param_1_0,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_004,
                                    [0])),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_004,
                                [1])
                        ]));
        }

        return Pine_KernelFunctionSpecialized.int_mul(param_1_0, param_1_1);
    }


    public static Pine_PineValue remainderBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_0 == CommonReusedValues.Blob_Int_1)
        {
            return CommonReusedValues.Blob_Int_0;
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                param_1_1,
                Pine_KernelFunctionSpecialized.int_mul(
                    param_1_0,
                    Basics.idiv(param_1_1, param_1_0),
                    -1));
    }
}
