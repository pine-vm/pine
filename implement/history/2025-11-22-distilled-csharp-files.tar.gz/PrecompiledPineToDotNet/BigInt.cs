using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ExpressionEncoding = global::Pine.Core.CommonEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.CommonEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.CommonEncodings.StringEncoding;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;

namespace PrecompiledPineToDotNet;

public static class BigInt
{
    public static Pine_PineValue divmod(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_1 == CommonReusedValues.Blob_Int_0)
        {
            return CommonReusedValues.List_13731c89;
        }

        Pine_PineValue local_000 =
            Basics.idiv(param_1_0, param_1_1);

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    local_000,
                                    Global_Anonymous.zzz_anon_f993b96d_69cecf0f(
                                        param_1_0,
                                        Basics.mul(local_000, param_1_1))
                                ])
                        ])
                ]);
    }


    public static Pine_PineValue lt(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return
            Pine_KernelFunctionSpecialized.equal(
                Global_Anonymous.zzz_anon_2c70f359_cc8506dc(param_1_0, param_1_1),
                CommonReusedValues.List_af0e3cad);
    }


    public static Pine_PineValue negate(Pine_PineValue param_1_0)
    {
        return Pine_KernelFunction.negate(param_1_0);
    }
}
