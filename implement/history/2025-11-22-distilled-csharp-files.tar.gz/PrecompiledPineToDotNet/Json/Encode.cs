using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ExpressionEncoding = global::Pine.Core.CommonEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.CommonEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.CommonEncodings.StringEncoding;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;

namespace PrecompiledPineToDotNet.Json;

public static class Encode
{
    public static Pine_PineValue advanceUtf32OffsetForSimpleChars(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_1, argument: local_param_1_0);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_1;
            }

            if (local_000 == CommonReusedValues.Blob_Char_doublequote)
            {
                return local_param_1_1;
            }

            if (local_000 == CommonReusedValues.Blob_Char_backslash)
            {
                return local_param_1_1;
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(
                32,
                Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_000),
                1_114_111) == Pine_PineKernelValues.TrueValue)
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            return local_param_1_1;
        }
    }


    public static Pine_PineValue encode(Pine_PineValue param_1_1)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunction.concat(
                                Json.Encode.encodeUtf32ChunksWithoutIndent(param_1_1))
                        ])
                ]);
    }


    public static Pine_PineValue encodeArrayItemsUtf32ChunksWithoutIndent(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableConcatBuilder local_param_1_1 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_1]);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_IntegerEncoding.EncodeSignedInteger(
                    Pine_KernelFunctionSpecialized.length_as_int(local_param_1_2));

            if (local_000 == local_param_1_0)
            {
                return local_param_1_1.Evaluate();
            }

            Pine_PineValue local_001 =
                Pine_KernelFunctionSpecialized.int_add(1, local_param_1_0);

            {
                Pine_PineValue local_param_1_0_temp =
                    local_001;

                local_param_1_1 =
                    local_param_1_1.AppendItems(
                        [
                            Json.Encode.encodeUtf32ChunksWithoutIndent(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    Pine_KernelFunctionFused.SkipAndTake(takeCount: 1, skipCountValue: local_param_1_0, argument: local_param_1_2),
                                    [0])),
                            local_000 == local_001
                            ?
                            Pine_PineValue.EmptyList
                            :
                            CommonReusedValues.List_Single_Blob_Char_comma
                        ]);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue encodeFieldsUtf32ChunksWithoutIndent(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableConcatBuilder local_param_1_1 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_1]);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_IntegerEncoding.EncodeSignedInteger(
                    Pine_KernelFunctionSpecialized.length_as_int(local_param_1_2));

            if (local_000 == local_param_1_0)
            {
                return local_param_1_1.Evaluate();
            }

            Pine_PineValue local_001 =
                Pine_KernelFunctionSpecialized.int_add(1, local_param_1_0);

            {
                Pine_PineValue local_param_1_0_temp =
                    local_001;

                local_param_1_1 =
                    local_param_1_1.AppendItems(
                        [
                            Json.Encode.encodeFieldUtf32ChunksWithoutIndent(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    Pine_KernelFunctionFused.SkipAndTake(takeCount: 1, skipCountValue: local_param_1_0, argument: local_param_1_2),
                                    [0])),
                            local_000 == local_001
                            ?
                            Pine_PineValue.EmptyList
                            :
                            CommonReusedValues.List_Single_Blob_Char_comma
                        ]);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue encodeFieldUtf32ChunksWithoutIndent(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Char_doublequote,
                    Pine_KernelFunction.concat(
                        Json.Encode.encodeStringUtf32ChunksFromBytes(
                            CommonReusedValues.Blob_Int_0,
                            Pine_PineValue.EmptyList,
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                param_1_0,
                                [0, 1, 0]))),
                    CommonReusedValues.Blob_22684870,
                    Pine_KernelFunction.concat(
                        Json.Encode.encodeUtf32ChunksWithoutIndent(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                param_1_0,
                                [1])))
                ]);
    }


    public static Pine_PineValue encodeStringUtf32ChunksFromBytes(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableConcatBuilder local_param_1_1 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_1]);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Json.Encode.advanceUtf32OffsetForSimpleChars(local_param_1_2, local_param_1_0);

            Pine_PineValue local_001 =
                Pine_KernelFunctionSpecialized.int_add(
                    local_000,
                    Pine_KernelFunctionSpecialized.int_mul(-1, local_param_1_0));

            Pine_PineValue local_003 =
                Pine_KernelFunction.ValueFromBool(
                    local_001 == CommonReusedValues.Blob_Int_0);

            Pine_PineValue local_004 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_000, argument: local_param_1_2);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
            {
                if (local_003 == Pine_PineKernelValues.TrueValue)
                {
                    return local_param_1_1.Evaluate();
                }

                return
                    Pine_KernelFunctionFused.ListAppendItem(
                        prefix:
                        local_param_1_1.Evaluate(),
                        itemToAppend:
                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2));
            }

            Pine_PineValue local_007 =
                Pine_KernelFunctionSpecialized.int_add(4, local_000);

            if (local_004 == CommonReusedValues.Blob_f063beda)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_11431555
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_tab)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_6859d43a
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_newline)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_8cc957f8
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_formfeed)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_21f12336
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_carriagereturn)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_4495e748
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_doublequote)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_0593a027
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            if (local_004 == CommonReusedValues.Blob_Char_backslash)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_007;

                    local_param_1_1 =
                        local_param_1_1.AppendItems(
                            [
                                !(local_003 == Pine_PineKernelValues.TrueValue)
                                ?
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                    ])
                                :
                                Pine_PineValue.EmptyList,
                                CommonReusedValues.List_67fa5ac0
                            ]);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            Pine_PineValue local_012 =
                Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_004);

            {
                Pine_PineValue local_param_1_0_temp =
                    local_007;

                local_param_1_1 =
                    local_param_1_1.AppendItems(
                        [
                            !(local_003 == Pine_PineKernelValues.TrueValue)
                            ?
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionFused.SkipAndTake(takeCountValue: local_001, skipCountValue: local_param_1_0, argument: local_param_1_2)
                                ])
                            :
                            Pine_PineValue.EmptyList,
                            Pine_KernelFunctionSpecialized.int_is_sorted_asc(0, local_012, 65_535) == Pine_PineKernelValues.TrueValue
                            ?
                            Pine_KernelFunctionSpecialized.concat(
                                CommonReusedValues.List_599c92a7,
                                Json.Encode.hex4(local_012))
                            :
                            Pine_KernelFunction.concat(
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.List_599c92a7,
                                        Json.Encode.hex4(
                                            Pine_KernelFunctionSpecialized.int_add(
                                                55_296,
                                                Pine_KernelFunctionSpecialized.bit_shift_right(
                                                    10,
                                                    Pine_KernelFunctionSpecialized.int_add(-65_536, local_012)))),
                                        CommonReusedValues.List_599c92a7,
                                        Json.Encode.hex4(
                                            Pine_KernelFunctionSpecialized.int_add(
                                                56_320,
                                                Pine_KernelFunctionSpecialized.bit_and(
                                                    Pine_IntegerEncoding.EncodeSignedInteger(1_023),
                                                    Pine_KernelFunctionSpecialized.int_add(-65_536, local_012))))
                                    ]))
                        ]);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue encodeUtf32ChunksWithoutIndent(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_NullValue == local_000)
        {
            return CommonReusedValues.List_Single_Blob_Str_null;
        }

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        if ((Pine_PineKernelValues.TrueValue == local_001) && (CommonReusedValues.Blob_Str_BoolValue == local_000))
        {
            return CommonReusedValues.List_Single_Blob_Str_true;
        }

        if ((Pine_PineKernelValues.FalseValue == local_001) && (CommonReusedValues.Blob_Str_BoolValue == local_000))
        {
            return CommonReusedValues.List_Single_Blob_Str_false;
        }

        if (CommonReusedValues.Blob_Str_IntValue == local_000)
        {
            return
                Global_Anonymous.zzz_anon_2badf312_841a88e3(
                    CommonReusedValues.Blob_Int_0,
                    Pine_PineValue.EmptyList,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        String.fromInt(local_001),
                        [1, 0]));
        }

        if (CommonReusedValues.Blob_Str_StringValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Char_doublequote,
                        Pine_KernelFunction.concat(
                            Json.Encode.encodeStringUtf32ChunksFromBytes(
                                CommonReusedValues.Blob_Int_0,
                                Pine_PineValue.EmptyList,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1, 0]))),
                        CommonReusedValues.Blob_Char_doublequote
                    ]);
        }

        if (CommonReusedValues.Blob_Str_ArrayValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Char_bracketopen,
                        Pine_KernelFunction.concat(
                            Json.Encode.encodeArrayItemsUtf32ChunksWithoutIndent(CommonReusedValues.Blob_Int_0, Pine_PineValue.EmptyList, local_001)),
                        CommonReusedValues.Blob_Char_bracketclose
                    ]);
        }

        if (CommonReusedValues.Blob_Str_ObjectValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Char_braceopen,
                        Pine_KernelFunction.concat(
                            Json.Encode.encodeFieldsUtf32ChunksWithoutIndent(CommonReusedValues.Blob_Int_0, Pine_PineValue.EmptyList, local_001)),
                        CommonReusedValues.Blob_Char_braceclose
                    ]);
        }

        if (CommonReusedValues.Blob_Str_FloatValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [1, 0])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue hex4(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.skip(1, param_1_0);

        return
            Pine_PineValue.List(
                [
                    Json.Encode.hexDigitCharFromNibble(
                        Pine_KernelFunctionSpecialized.bit_and(
                            CommonReusedValues.Blob_2d8b523c,
                            Pine_KernelFunctionSpecialized.bit_shift_right(12, local_000))),
                    Json.Encode.hexDigitCharFromNibble(
                        Pine_KernelFunctionSpecialized.bit_and(
                            CommonReusedValues.Blob_2d8b523c,
                            Pine_KernelFunctionSpecialized.bit_shift_right(8, local_000))),
                    Json.Encode.hexDigitCharFromNibble(
                        Pine_KernelFunctionSpecialized.bit_and(
                            CommonReusedValues.Blob_2d8b523c,
                            Pine_KernelFunctionSpecialized.bit_shift_right(4, local_000))),
                    Json.Encode.hexDigitCharFromNibble(
                        Pine_KernelFunctionSpecialized.bit_and(CommonReusedValues.Blob_2d8b523c, local_000))
                ]);
    }


    public static Pine_PineValue hexDigitCharFromNibble(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.Blob_449e9b79)
        {
            return CommonReusedValues.Blob_Char_digit_0;
        }

        if (param_1_0 == CommonReusedValues.Blob_50453b36)
        {
            return CommonReusedValues.Blob_Char_digit_1;
        }

        if (param_1_0 == Pine_PineKernelValues.FalseValue)
        {
            return CommonReusedValues.Blob_Char_digit_2;
        }

        if (param_1_0 == CommonReusedValues.Blob_bd557c82)
        {
            return CommonReusedValues.Blob_Char_digit_3;
        }

        if (param_1_0 == Pine_PineKernelValues.TrueValue)
        {
            return CommonReusedValues.Blob_Char_digit_4;
        }

        if (param_1_0 == CommonReusedValues.Blob_7732e8fd)
        {
            return CommonReusedValues.Blob_Char_digit_5;
        }

        if (param_1_0 == CommonReusedValues.Blob_4c5dc722)
        {
            return CommonReusedValues.Blob_Char_digit_6;
        }

        if (param_1_0 == CommonReusedValues.Blob_735edfdb)
        {
            return CommonReusedValues.Blob_Char_digit_7;
        }

        if (param_1_0 == CommonReusedValues.Blob_8db117dc)
        {
            return CommonReusedValues.Blob_Char_digit_8;
        }

        if (param_1_0 == CommonReusedValues.Blob_fb88d96b)
        {
            return CommonReusedValues.Blob_Char_digit_9;
        }

        if (param_1_0 == CommonReusedValues.Blob_4c0d52d1)
        {
            return CommonReusedValues.Blob_Char_letter_A;
        }

        if (param_1_0 == CommonReusedValues.Blob_40896845)
        {
            return CommonReusedValues.Blob_Char_letter_B;
        }

        if (param_1_0 == CommonReusedValues.Blob_02334608)
        {
            return CommonReusedValues.Blob_Char_letter_C;
        }

        if (param_1_0 == CommonReusedValues.Blob_015f2803)
        {
            return CommonReusedValues.Blob_Char_letter_D;
        }

        if (param_1_0 == CommonReusedValues.Blob_63e02745)
        {
            return CommonReusedValues.Blob_Char_letter_E;
        }

        if (param_1_0 == CommonReusedValues.Blob_2d8b523c)
        {
            return CommonReusedValues.Blob_Char_letter_F;
        }

        return CommonReusedValues.Blob_Char_question;
    }
}
