using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ExpressionEncoding = global::Pine.Core.CommonEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.CommonEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.CommonEncodings.StringEncoding;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;

namespace PrecompiledPineToDotNet;

public static class List
{
    public static Pine_PineValue cons(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Pine_KernelFunctionFused.ListPrependItem(itemToPrepend: param_1_0, suffix: param_1_1);
    }
}
