using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class String
{
    public static Pine_PineValue contains(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        if (local_000 == Pine_PineValue.EmptyList)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        return
            Global_Anonymous.zzz_anon_0574805a_a91f9a5b(
                CommonReusedValues.Blob_Int_0,
                local_000,
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1, 0]));
    }


    public static Pine_PineValue fromInt(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunction.concat(
                                Global_Anonymous.zzz_anon_0f6e756a_a4f70149(param_1_0))
                        ])
                ]);
    }


    public static Pine_PineValue padLeft(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_2,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_KernelFunctionSpecialized.int_add(
                param_1_0,
                Pine_KernelFunctionSpecialized.int_mul(
                    -1,
                    Pine_KernelFunctionFused.BlobPrependByte(
                        byteToPrepend: 4,
                        suffix:
                        Pine_KernelFunctionSpecialized.bit_shift_right(
                            2,
                            Pine_KernelFunctionSpecialized.skip(
                                1,
                                Pine_IntegerEncoding.EncodeSignedInteger(
                                    Pine_KernelFunctionSpecialized.length_as_int(local_000)))))));

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_001, 0))
        {
            return param_1_2;
        }

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.concat(
                                Pine_KernelFunction.concat(
                                    Global_Anonymous.zzz_anon_610ee3fc_622604de(Pine_PineValue.EmptyList, local_001, param_1_1)),
                                local_000)
                        ])
                ]);
    }


    public static Pine_PineValue toInt(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.take(4, param_1_0);

        if (local_000 == CommonReusedValues.Blob_Char_hyphen)
        {
            Pine_PineValue local_001 =
                Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_4);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (CommonReusedValues.Blob_Str_Just == local_002)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Just,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionSpecialized.int_mul(
                                        -1,
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_001,
                                            [1, 0]))
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Nothing == local_002)
            {
                return CommonReusedValues.List_13731c89;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        if (local_000 == CommonReusedValues.Blob_Char_plus)
        {
            return Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_4);
        }

        return Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_0);
    }


    public static Pine_PineValue trim(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionFused.TakeAndSkip(
                                skipCountValue:
                                Global_Anonymous.zzz_anon_449d95bc_da6f86d5(CommonReusedValues.Blob_Int_0, local_000),
                                takeCountValue:
                                Global_Anonymous.zzz_anon_627f403e_dca18c16(
                                    Pine_KernelFunction.length(local_000),
                                    local_000),
                                argument: local_000)
                        ])
                ]);
    }


    public static Pine_PineValue trimLeft(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.skip(
                                Global_Anonymous.zzz_anon_449d95bc_da6f86d5(CommonReusedValues.Blob_Int_0, local_000),
                                local_000)
                        ])
                ]);
    }


    public static Pine_PineValue trimRight(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionSpecialized.take(
                                Global_Anonymous.zzz_anon_627f403e_dca18c16(
                                    Pine_KernelFunction.length(local_000),
                                    local_000),
                                local_000)
                        ])
                ]);
    }
}
