using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Bitwise
{
    public static Pine_PineValue and(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0));

        Pine_PineValue local_003 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1));

        Pine_PineValue local_004 =
            local_001 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_005 =
            local_003 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_007 =
            Pine_KernelFunctionSpecialized.bit_and(local_004, local_005);

        Pine_PineValue local_009 =
            Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_1d285b09);

        Pine_PineValue local_011 =
            Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_009);

        if (Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_011);
        }

        return Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_009);
    }


    public static Pine_PineValue complement(Pine_PineValue param_1_0)
    {
        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(-2_147_483_648, param_1_0, 2_147_483_647) == Pine_PineKernelValues.TrueValue)
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    -1,
                    Pine_KernelFunctionSpecialized.int_mul(-1, param_1_0));
        }

        Pine_PineValue local_001 =
            Pine_KernelFunctionSpecialized.bit_and(param_1_0, CommonReusedValues.Blob_1d285b09);

        if (Pine_KernelFunctionSpecialized.bit_and(param_1_0, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return
                Pine_KernelFunctionSpecialized.int_add(
                    2_147_483_647,
                    Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 2, suffix: local_001));
        }

        return
            Pine_KernelFunctionSpecialized.int_add(
                -1,
                Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_001));
    }


    public static Pine_PineValue or(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0));

        Pine_PineValue local_003 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1));

        Pine_PineValue local_004 =
            local_001 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_005 =
            local_003 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_007 =
            Pine_KernelFunctionSpecialized.bit_or(local_004, local_005);

        Pine_PineValue local_009 =
            Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_1d285b09);

        Pine_PineValue local_011 =
            Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_009);

        if (Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_011);
        }

        return Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_009);
    }


    public static Pine_PineValue shiftLeftBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunctionSpecialized.int_is_sorted_asc(-2_147_483_648, param_1_1, -1);

        Pine_PineValue local_002 =
            local_001 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_or(
                Pine_KernelFunctionSpecialized.int_add(2_147_483_648L, param_1_1),
                CommonReusedValues.Blob_8535093c)
            :
            Pine_KernelFunctionSpecialized.bit_or(
                Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                CommonReusedValues.Blob_e429d1a2);

        Pine_PineValue local_003 =
            Pine_PineValue.List(
                [param_1_0, local_002]);

        Pine_PineValue local_004 =
            Pine_KernelFunction.bit_shift_left(local_003);

        Pine_PineValue local_006 =
            Pine_KernelFunctionSpecialized.bit_and(local_004, CommonReusedValues.Blob_1d285b09);

        Pine_PineValue local_008 =
            Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_006);

        if (Pine_KernelFunctionSpecialized.bit_and(local_004, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_008);
        }

        return Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_006);
    }


    public static Pine_PineValue shiftRightBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(-2_147_483_648, param_1_1, 2_147_483_647) == Pine_PineKernelValues.TrueValue)
        {
            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1))
            {
                return
                    Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(
                        signIsPositive: true,
                        unsignedValue:
                        Pine_KernelFunction.bit_shift_right(
                            Pine_PineValue.List(
                                [
                                    param_1_0,
                                    Pine_KernelFunctionSpecialized.skip(
                                        1,
                                        Pine_KernelFunctionSpecialized.int_add(0, param_1_1))
                                ])));
            }

            return
                Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(
                    signIsPositive: false,
                    unsignedValue:
                    Pine_KernelFunction.bit_shift_right(
                        Pine_PineValue.List(
                            [
                                param_1_0,
                                Pine_KernelFunctionSpecialized.skip(
                                    1,
                                    Pine_KernelFunctionSpecialized.int_add(-1, param_1_1))
                            ])));
        }

        Pine_PineValue local_002 =
            Pine_KernelFunctionSpecialized.bit_and(param_1_1, CommonReusedValues.Blob_1d285b09);

        Pine_PineValue local_003 =
            Pine_KernelFunctionSpecialized.bit_and(param_1_1, CommonReusedValues.Blob_8535093c);

        Pine_PineValue local_005 =
            Pine_KernelFunction.ValueFromBool(
                local_003 == CommonReusedValues.Blob_8535093c);

        Pine_PineValue local_006 =
            local_005 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.int_add(
                -2_147_483_648,
                Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_002))
            :
            Pine_KernelFunctionSpecialized.int_add(
                -1,
                Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 2, suffix: local_002));

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, local_006))
        {
            return
                Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(
                    signIsPositive: true,
                    unsignedValue:
                    Pine_KernelFunction.bit_shift_right(
                        Pine_PineValue.List(
                            [
                                param_1_0,
                                Pine_KernelFunctionSpecialized.skip(
                                    1,
                                    Pine_KernelFunctionSpecialized.int_add(0, local_006))
                            ])));
        }

        return
            Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(
                signIsPositive: false,
                unsignedValue:
                Pine_KernelFunction.bit_shift_right(
                    Pine_PineValue.List(
                        [
                            param_1_0,
                            Pine_KernelFunctionSpecialized.skip(
                                1,
                                Pine_KernelFunctionSpecialized.int_add(-1, local_006))
                        ])));
    }


    public static Pine_PineValue shiftRightZfBy(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunctionSpecialized.take(1, param_1_1);

        if (local_001 == Pine_PineKernelValues.TrueValue)
        {
            return
                Pine_KernelFunctionSpecialized.concat(
                    local_001,
                    Global_Anonymous.zzz_anon_8c8348da_dda26649(
                        Pine_KernelFunctionFused.TakeLast(
                            takeCount: 4,
                            value:
                            Pine_KernelFunction.bit_shift_right(
                                Pine_PineValue.List(
                                    [
                                        param_1_0,
                                        Pine_KernelFunctionSpecialized.skip(1, param_1_1)
                                    ])))));
        }

        return
            Pine_KernelFunctionFused.BlobPrependByte(
                byteToPrepend: 4,
                suffix:
                Global_Anonymous.zzz_anon_8c8348da_dda26649(
                    Pine_KernelFunction.bit_shift_right(
                        Pine_PineValue.List(
                            [
                                param_1_0,
                                Pine_KernelFunction.bit_not(
                                    Pine_KernelFunction.reverse(
                                        Pine_KernelFunctionSpecialized.take(
                                            4,
                                            Pine_KernelFunctionSpecialized.concat(
                                                Pine_KernelFunction.reverse(
                                                    Pine_KernelFunctionSpecialized.skip(
                                                        1,
                                                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1))),
                                                CommonReusedValues.Blob_e429d1a2))))
                            ]))));
    }


    public static Pine_PineValue xor(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0));

        Pine_PineValue local_003 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_1));

        Pine_PineValue local_004 =
            local_001 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_0),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_0)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_0)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_0),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_005 =
            local_003 == Pine_PineKernelValues.TrueValue
            ?
            Pine_KernelFunctionSpecialized.bit_and(
                Pine_KernelFunctionSpecialized.skip(1, param_1_1),
                CommonReusedValues.Blob_a8b57991)
            :
            (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(-2_147_483_648, param_1_1)
            ?
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_or(
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_KernelFunctionSpecialized.int_add(1, param_1_1)),
                    CommonReusedValues.Blob_e429d1a2))
            :
            Pine_KernelFunction.bit_not(
                Pine_KernelFunctionSpecialized.bit_and(
                    Pine_KernelFunctionSpecialized.int_add(1, param_1_1),
                    CommonReusedValues.Blob_a8b57991)));

        Pine_PineValue local_007 =
            Pine_KernelFunctionSpecialized.bit_xor(local_004, local_005);

        Pine_PineValue local_009 =
            Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_1d285b09);

        Pine_PineValue local_011 =
            Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_009);

        if (Pine_KernelFunctionSpecialized.bit_and(local_007, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c)
        {
            return Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_011);
        }

        return Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_009);
    }
}
