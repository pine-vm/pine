using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Global_Anonymous
{
    public static Pine_PineValue zzz_anon_03d2d269_8e4089c4(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (local_param_1_1.IsEmptyList())
            {
                return Pine_PineKernelValues.TrueValue;
            }

            if (!(local_param_1_1.GetLength() == 0))
            {
                if (Basics.eq(
                    local_param_1_1.GetHead(),
                    local_param_1_0) == Pine_PineKernelValues.TrueValue)
                {
                    {
                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                return Pine_PineKernelValues.FalseValue;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_0574805a_a91f9a5b(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(
                    takeCountValue:
                    Pine_IntegerEncoding.EncodeSignedInteger(
                        Pine_KernelFunctionSpecialized.length_as_int(local_param_1_1)),
                    skipCountValue: local_param_1_0,
                    argument: local_param_1_2);

            if (local_000 == local_param_1_1)
            {
                return Pine_PineKernelValues.TrueValue;
            }

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return Pine_PineKernelValues.FalseValue;
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    Pine_KernelFunctionSpecialized.int_add(4, local_param_1_0);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_060fcfd7_51a2f736(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Global_Anonymous.zzz_anon_d9d31de4_0e649b4d(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_0965dc45_5db01df0(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2,
        Pine_PineValue param_1_3)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        Pine_PineValue local_param_1_3 =
            param_1_3;

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_001 =
                    Pine_KernelFunction.negate(local_param_1_3);

                Pine_PineValue local_004 =
                    Pine_KernelFunctionSpecialized.int_add(8, local_001);

                Pine_PineValue local_005 =
                    Pine_KernelFunctionSpecialized.int_is_sorted_asc(
                        -2_147_483_648,
                        local_param_1_1.GetHead(),
                        -1);

                Pine_PineValue local_006 =
                    local_005 == Pine_PineKernelValues.TrueValue
                    ?
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.int_add(
                            2_147_483_648L,
                            local_param_1_1.GetHead()),
                        CommonReusedValues.Blob_8535093c)
                    :
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            local_param_1_1.GetHead()),
                        CommonReusedValues.Blob_e429d1a2);

                Pine_PineValue local_007 =
                    Pine_PineValue.List(
                        [local_004, local_006]);

                Pine_PineValue local_008 =
                    Pine_KernelFunction.bit_shift_left(local_007);

                Pine_PineValue local_010 =
                    Pine_KernelFunctionSpecialized.bit_and(local_008, CommonReusedValues.Blob_1d285b09);

                Pine_PineValue local_012 =
                    Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_010);

                {
                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.bit_and(local_008, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c
                        ?
                        Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_012)
                        :
                        Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_010);

                    local_param_1_0 =
                        local_param_1_0.PrependItems(
                            [
                                Pine_PineValue.List(
                                    [
                                        Bitwise.and(
                                            CommonReusedValues.Blob_Int_255,
                                            Bitwise.or(
                                                Bitwise.shiftRightBy(
                                                    local_param_1_3,
                                                    local_param_1_1.GetHead()),
                                                local_param_1_2))
                                    ])
                            ]);

                    local_param_1_1 =
                        local_param_1_1.Skip(1);

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_param_1_1.IsEmptyList())
            {
                return local_param_1_0.EvaluateReverse();
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_0da2f7ed_200123d4(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_2, argument: local_param_1_1);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Just,
                            Pine_PineValue.List(
                                [local_param_1_0])
                        ]);
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_0)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0);

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_1)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            1,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_2)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            2,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_3)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            3,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_4)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            4,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_5)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            5,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_6)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            6,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_7)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            7,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_8)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            8,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_9)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            9,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            return CommonReusedValues.List_13731c89;
        }
    }


    public static Pine_PineValue zzz_anon_0f6e756a_a4f70149(Pine_PineValue param_1_0)
    {
        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0))
        {
            return Global_Anonymous.zzz_anon_12af8dcc_650df00b(param_1_0);
        }

        return
            Pine_KernelFunctionFused.ListPrependItem(
                itemToPrepend: CommonReusedValues.Blob_Char_hyphen,
                suffix:
                Global_Anonymous.zzz_anon_12af8dcc_650df00b(
                    Pine_KernelFunction.negate(param_1_0)));
    }


    public static Pine_PineValue zzz_anon_1261ac32_458f62e0(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_003 =
            Global_Anonymous.zzz_anon_d6ebdb03_28e23645(param_1_0, param_1_1, Pine_PineValue.EmptyList);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [0]);

        Pine_PineValue local_005 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_004,
                [0]);

        if (CommonReusedValues.Blob_Str_Ok == local_005)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_String,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_KernelFunction.concat(
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_004,
                                                                [1, 0]))
                                                    ])
                                            ])
                                    ])
                            ]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [1])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Err == local_005)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Err,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_004,
                                            [1, 0])
                                    ])
                            ]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [1])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_12af8dcc_650df00b(Pine_PineValue param_1_0)
    {
        return Global_Anonymous.zzz_anon_632693ae_2f148225(param_1_0, Pine_PineValue.EmptyList);
    }


    public static Pine_PineValue zzz_anon_18891e82_b561536d(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (param_1_0 == CommonReusedValues.List_f727f528)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_e9c5a80a_a6ea216c(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_ef37bd26)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Pine.kernelFunction_negate(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_50ca8475)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_4b20c2f9_af69ee38(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_8ce25fef)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_59a0aec1_7d092ddb(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_07de6d06)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_cbaaa061_7d092ddb(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_9c40ca00)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_654f47c2_dda26649(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_75cd45f1)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_060fcfd7_51a2f736(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_485f41ca)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_27a778a0_dda26649(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_c0d6dd86)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_373579cd_7834f607(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_8e25d773)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_e8f8319b_490cdf76(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_e3741710)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_5707358a_d505fcbe(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_51c6092e)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_a53f6616_0ba75d05(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_1780e7f4)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_a53f6616_fef8748c(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_c62312bf)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_a53f6616_9436b59a(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_c6864643)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_d651d7e2_c3da1d69(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_6224dad7)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_f3d6dba5_22efcada(param_1_1)
                            ])
                    ]);
        }

        if (param_1_0 == CommonReusedValues.List_480e73bb)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Ok,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_71e97dac_ffce8e79(param_1_1)
                            ])
                    ]);
        }

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Err,
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_DescribePathEnd,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_String,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_KernelFunctionSpecialized.concat(
                                                                CommonReusedValues.Blob_b3a0cf40,
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    param_1_0,
                                                                    [1, 0]))
                                                        ])
                                                ])
                                        ])
                                ])
                        ])
                ]);
    }


    public static Pine_PineValue zzz_anon_1aac970b_200123d4(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: param_1_1, argument: param_1_0);

        if (local_000 == CommonReusedValues.Blob_Char_digit_0)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_0,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_1)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_1,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_2)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_2,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_3)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_3,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_4)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_4,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_5)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_5,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_6)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_6,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_7)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_7,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_8)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_8,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_9)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_9,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        return CommonReusedValues.List_13731c89;
    }


    public static Pine_PineValue zzz_anon_1c3c9562_dda26649(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 16, skipCountValue: param_1_1, argument: param_1_0) == CommonReusedValues.Blob_Str_null)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.List_aa6d2677,
                        Pine_KernelFunctionSpecialized.int_add(16, param_1_1)
                    ]);
        }

        return
            Pine_PineValue.List(
                [CommonReusedValues.List_f4991ec8, param_1_1]);
    }


    public static Pine_PineValue zzz_anon_2486a52f_dda26649(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 16, skipCountValue: param_1_1, argument: param_1_0) == CommonReusedValues.Blob_Str_true)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.List_68d4a402,
                        Pine_KernelFunctionSpecialized.int_add(16, param_1_1)
                    ]);
        }

        return
            Pine_PineValue.List(
                [CommonReusedValues.List_bc38831b, param_1_1]);
    }


    public static Pine_PineValue zzz_anon_26524eca_71eb7c46(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: param_1_0, argument: param_1_1);

        if (local_000 == CommonReusedValues.Blob_Char_digit_0)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_1)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_1,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_2)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_2,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_3)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_3,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_4)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_4,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_5)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_5,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_6)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_6,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_7)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_7,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_8)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_8,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_9)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_9,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_a)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_10,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_A)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_10,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_b)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_11,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_B)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_11,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_c)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_12,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_C)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_12,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_d)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_13,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_D)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_13,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_e)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_14,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_E)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_14,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_f)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_15,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        if (local_000 == CommonReusedValues.Blob_Char_letter_F)
        {
            return
                Global_Anonymous.zzz_anon_cf00dbf7_71eb7c46(
                    CommonReusedValues.Blob_Int_15,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_0),
                    param_1_1);
        }

        return CommonReusedValues.List_7d7a3f6a;
    }


    public static Pine_PineValue zzz_anon_27a778a0_dda26649(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        if ((!(Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]);
        }

        if ((local_000 == Pine_PineValue.EmptyList) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return CommonReusedValues.List_1f3f2fca;
        }

        if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [
                                Pine_KernelFunctionSpecialized.take(1, local_000)
                            ])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_2c70f359_a1cc36c0(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Basics.compare(param_1_0, param_1_1);
    }


    public static Pine_PineValue zzz_anon_2c70f359_fc8e1519(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return Basics.mul(param_1_0, param_1_1);
    }


    public static Pine_PineValue zzz_anon_30535a07_c1817879(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    Pine.bigIntFromValue(
                        local_param_1_1.GetHead());

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_Ok == local_001)
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Global_Anonymous.zzz_anon_2c70f359_fc8e1519(
                                local_param_1_0,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1, 0]));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                if (CommonReusedValues.Blob_Str_Err == local_001)
                {
                    return CommonReusedValues.List_1f3f2fca;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return Pine.valueFromBigInt(local_param_1_0);
        }
    }


    public static Pine_PineValue zzz_anon_368f36cc_8a4785c3(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0));

        if (Pine_KernelFunction.negate(local_000) == Pine_PineKernelValues.TrueValue)
        {
            return
                Pine_KernelFunctionFused.ListPrependItem(
                    itemToPrepend:
                    Pine_IntegerEncoding.EncodeSignedInteger(2),
                    suffix:
                    Global_Anonymous.zzz_anon_f1f1da9a_dda26649(
                        local_000 == Pine_PineKernelValues.TrueValue
                        ?
                        param_1_0
                        :
                        Pine_KernelFunctionSpecialized.int_mul(-1, param_1_0)));
        }

        return
            Pine_KernelFunctionFused.ListPrependItem(
                itemToPrepend:
                Pine_IntegerEncoding.EncodeSignedInteger(4),
                suffix:
                Global_Anonymous.zzz_anon_f1f1da9a_dda26649(param_1_0));
    }


    public static Pine_PineValue zzz_anon_373579cd_7834f607(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Global_Anonymous.zzz_anon_7b787121_f754fd7c(
                    CommonReusedValues.Blob_Int_0,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_39fa68f8_2402eeb0(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        while (true)
        {
            if (local_param_1_0 == CommonReusedValues.Blob_Int_0)
            {
                return CommonReusedValues.Blob_Char_digit_0;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_1)
            {
                return CommonReusedValues.Blob_Char_digit_1;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_2)
            {
                return CommonReusedValues.Blob_Char_digit_2;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_3)
            {
                return CommonReusedValues.Blob_Char_digit_3;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_4)
            {
                return CommonReusedValues.Blob_Char_digit_4;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_5)
            {
                return CommonReusedValues.Blob_Char_digit_5;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_6)
            {
                return CommonReusedValues.Blob_Char_digit_6;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_7)
            {
                return CommonReusedValues.Blob_Char_digit_7;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_8)
            {
                return CommonReusedValues.Blob_Char_digit_8;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_9)
            {
                return CommonReusedValues.Blob_Char_digit_9;
            }

            {
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_3c873ec4_dda26649(Pine_PineValue param_1_0)
    {
        return
            Pine_KernelFunctionSpecialized.equal(
                Pine_KernelFunctionSpecialized.take(0, param_1_0),
                Pine_PineValue.EmptyBlob);
    }


    public static Pine_PineValue zzz_anon_3fad4dcd_ba70c3a8(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableSliceBuilder local_param_1_0 =
            Pine_ImmutableSliceBuilder.Create(param_1_0);

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0.IsEmptyList())
            {
                return CommonReusedValues.List_fb348cf5;
            }

            if (!(local_param_1_0.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    Pine.intFromValue(
                        local_param_1_0.GetHead());

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_Err == local_001)
                {
                    return CommonReusedValues.List_1f3f2fca;
                }

                if (CommonReusedValues.Blob_Str_Ok == local_001)
                {
                    Pine_PineValue local_002 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_000,
                            [1, 0]);

                    if (Basics.lt(local_002, local_param_1_1) == Pine_PineKernelValues.TrueValue)
                    {
                        return CommonReusedValues.List_c47bf601;
                    }

                    {
                        Pine_PineValue local_param_1_1_temp =
                            local_002;

                        local_param_1_0 =
                            local_param_1_0.Skip(1);

                        local_param_1_1 =
                            local_param_1_1_temp;
                    }

                    continue;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_449d95bc_da6f86d5(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_0, argument: local_param_1_1);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_0;
            }

            if (Global_Anonymous.zzz_anon_d97a2014_dda26649(local_000) == Pine_PineKernelValues.TrueValue)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_0);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine_PineValue zzz_anon_46782f74_0d2b56f6(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: param_1_1, argument: param_1_0);

        if (local_000 == CommonReusedValues.Blob_Char_digit_0)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.List_c3304aab,
                        Pine_KernelFunctionSpecialized.int_add(4, param_1_1)
                    ]);
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_1)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_1,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_2)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_2,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_3)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_3,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_4)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_4,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_5)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_5,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_6)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_6,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_7)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_7,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_8)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_8,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_9)
        {
            return
                Global_Anonymous.zzz_anon_f1cd4f95_0d2b56f6(
                    CommonReusedValues.Blob_Int_9,
                    param_1_0,
                    Pine_KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        return
            Pine_PineValue.List(
                [CommonReusedValues.List_ae45bd54, param_1_1]);
    }


    public static Pine_PineValue zzz_anon_4822613b_206e486b(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Global_Anonymous.zzz_anon_26524eca_71eb7c46(
                CommonReusedValues.Blob_Int_0,
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 16, skipCountValue: param_1_1, argument: param_1_0));

        if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [1]) == CommonReusedValues.Blob_Int_16)
        {
            Pine_PineValue local_002 =
                Pine_KernelFunctionSpecialized.int_add(16, param_1_1);

            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(55_296, local_003, 56_319) == Pine_PineKernelValues.TrueValue)
            {
                if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 8, skipCountValue: local_002, argument: param_1_0) == CommonReusedValues.Blob_0c865a6b)
                {
                    Pine_PineValue local_004 =
                        Global_Anonymous.zzz_anon_26524eca_71eb7c46(
                            CommonReusedValues.Blob_Int_0,
                            Pine_KernelFunctionFused.SkipAndTake(
                                takeCount: 16,
                                skipCountValue:
                                Pine_KernelFunctionSpecialized.int_add(24, param_1_1),
                                argument: param_1_0));

                    if (Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [1]) == CommonReusedValues.Blob_Int_16)
                    {
                        Pine_PineValue local_005 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_004,
                                [0]);

                        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(56_320, local_005, 57_343) == Pine_PineKernelValues.TrueValue)
                        {
                            return
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_Ok,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_KernelFunction.reverse(
                                                            Pine_KernelFunctionSpecialized.take(
                                                                4,
                                                                Pine_KernelFunctionSpecialized.concat(
                                                                    Pine_KernelFunction.reverse(
                                                                        Pine_KernelFunctionSpecialized.skip(
                                                                            1,
                                                                            Pine_KernelFunction.int_add(
                                                                                Pine_PineValue.List(
                                                                                    [
                                                                                        Pine_IntegerEncoding.EncodeSignedInteger(65_536),
                                                                                        Pine_KernelFunctionSpecialized.int_mul(
                                                                                            1_024,
                                                                                            Pine_KernelFunctionSpecialized.int_add(-55_296, local_003)),
                                                                                        local_005,
                                                                                        Pine_IntegerEncoding.EncodeSignedInteger(-56_320)
                                                                                    ])))),
                                                                    CommonReusedValues.Blob_e429d1a2)))
                                                    ])
                                            ]),
                                        Pine_KernelFunction.int_add(
                                            Pine_PineValue.List(
                                                [
                                                    param_1_1,
                                                    Pine_IntegerEncoding.EncodeSignedInteger(16),
                                                    Pine_IntegerEncoding.EncodeSignedInteger(8),
                                                    Pine_IntegerEncoding.EncodeSignedInteger(16)
                                                ]))
                                    ]);
                        }

                        return
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_Ok,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunction.reverse(
                                                        Pine_KernelFunctionSpecialized.take(
                                                            4,
                                                            Pine_KernelFunctionSpecialized.concat(
                                                                Pine_KernelFunction.reverse(
                                                                    Pine_KernelFunctionSpecialized.skip(1, local_003)),
                                                                CommonReusedValues.Blob_e429d1a2)))
                                                ])
                                        ]),
                                    local_002
                                ]);
                    }

                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_6986bc55,
                                Pine_KernelFunction.int_add(
                                    Pine_PineValue.List(
                                        [
                                            param_1_1,
                                            Pine_IntegerEncoding.EncodeSignedInteger(16),
                                            Pine_IntegerEncoding.EncodeSignedInteger(8),
                                            Pine_IntegerEncoding.EncodeSignedInteger(24)
                                        ]))
                            ]);
                }

                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_KernelFunction.reverse(
                                                Pine_KernelFunctionSpecialized.take(
                                                    4,
                                                    Pine_KernelFunctionSpecialized.concat(
                                                        Pine_KernelFunction.reverse(
                                                            Pine_KernelFunctionSpecialized.skip(1, local_003)),
                                                        CommonReusedValues.Blob_e429d1a2)))
                                        ])
                                ]),
                            local_002
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunction.reverse(
                                            Pine_KernelFunctionSpecialized.take(
                                                4,
                                                Pine_KernelFunctionSpecialized.concat(
                                                    Pine_KernelFunction.reverse(
                                                        Pine_KernelFunctionSpecialized.skip(1, local_003)),
                                                    CommonReusedValues.Blob_e429d1a2)))
                                    ])
                            ]),
                        local_002
                    ]);
        }

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.List_673355c3,
                    Pine_KernelFunctionSpecialized.int_add(6, param_1_1)
                ]);
    }


    public static Pine_PineValue zzz_anon_4b20c2f9_af69ee38(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        return
            Pine.valueFromInt(
                CommonReusedValues.Blob_Str_ListValue == local_000
                ?
                Pine_KernelFunction.length(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]))
                :
                (CommonReusedValues.Blob_Str_BlobValue == local_000
                ?
                Pine_KernelFunction.length(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]))
                :
                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")));
    }


    public static Pine_PineValue zzz_anon_4cf95911_826201ed(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: param_1_1, argument: param_1_0) == CommonReusedValues.Blob_Char_hyphen)
        {
            Pine_PineValue local_002 =
                Pine_KernelFunctionSpecialized.int_add(4, param_1_1);

            Pine_PineValue local_005 =
                Global_Anonymous.zzz_anon_46782f74_0d2b56f6(param_1_0, local_002);

            Pine_PineValue local_006 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_005,
                    [0]);

            Pine_PineValue local_007 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_007)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_KernelFunctionSpecialized.int_mul(
                                                -1,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_006,
                                                    [1, 0]))
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_005,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_007)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_006,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_005,
                                [1])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return Global_Anonymous.zzz_anon_46782f74_0d2b56f6(param_1_0, param_1_1);
    }


    public static Pine_PineValue zzz_anon_4d84519b_c3da1d69(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                {
                    local_param_1_0 =
                        local_param_1_0.PrependItems(
                            [
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionSpecialized.int_add(
                                            255,
                                            Pine_KernelFunctionSpecialized.int_mul(
                                                -1,
                                                local_param_1_1.GetHead()))
                                    ])
                            ]);

                    local_param_1_1 =
                        local_param_1_1.Skip(1);
                }

                continue;
            }

            return local_param_1_0.EvaluateReverse();
        }
    }


    public static Pine_PineValue zzz_anon_5707358a_d505fcbe(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            Pine_PineValue local_000 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]);

            if (local_000 == Pine_PineValue.EmptyList)
            {
                return
                    Pine.valueFromBool(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            CommonReusedValues.List_d6b61b83,
                            [1, 0]));
            }

            if (!(Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0))
            {
                Pine_PineValue local_001 =
                    Pine.intFromValue(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_000,
                            [0]));

                Pine_PineValue local_002 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [0]);

                if (CommonReusedValues.Blob_Str_Err == local_002)
                {
                    return CommonReusedValues.List_1f3f2fca;
                }

                if (CommonReusedValues.Blob_Str_Ok == local_002)
                {
                    return
                        Global_Anonymous.zzz_anon_3fad4dcd_ba70c3a8(
                            Pine_KernelFunctionSpecialized.skip(1, local_000),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [1, 0]));
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_59345918_dda26649(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [4]);

        Pine_PineValue local_002 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [1]);

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [3]);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [1]);

        if (((((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_004,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_003,
            [0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_005 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [3, 1]);

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_004,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_004,
                                    [2]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [1]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [2]),
                                                Pine_PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                                        Pine_PineValue.List(
                                                            [
                                                                CommonReusedValues.List_dafb9d35,
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [1]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [2]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [3]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [4])
                                                            ])
                                                    ]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [3])
                                            ])
                                    ]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [1]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [2]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [4]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [4])
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_006 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]);

            Pine_PineValue local_007 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Black == local_007)
            {
                Pine_PineValue local_008 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [4])
                                                ])
                                        ]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [2]),
                                                    local_003,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Red == local_007)
            {
                Pine_PineValue local_009 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [4])
                                                ])
                                        ]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [2]),
                                                    local_003,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return param_1_0;
    }


    public static Pine_PineValue zzz_anon_59a0aec1_7d092ddb(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        if ((2 == Pine_KernelFunctionSpecialized.length_as_int(local_000)) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_001 =
                Pine.intFromValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]));

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_002)
            {
                Pine_PineValue local_005 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [1]);

                Pine_PineValue local_006 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [0]);

                if (CommonReusedValues.Blob_Str_ListValue == local_006)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_ListValue,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionSpecialized.skip(
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1, 0]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_005,
                                                [1, 0]))
                                    ])
                            ]);
                }

                if (CommonReusedValues.Blob_Str_BlobValue == local_006)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_BlobValue,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionSpecialized.skip(
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1, 0]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_005,
                                                [1, 0]))
                                    ])
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            if (CommonReusedValues.Blob_Str_Err == local_002)
            {
                return CommonReusedValues.List_1f3f2fca;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_610ee3fc_622604de(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_1, 0))
            {
                return local_param_1_0;
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    List.cons(local_param_1_2, local_param_1_0);

                Pine_PineValue local_param_1_1_temp =
                    Pine_KernelFunctionSpecialized.int_add(-1, local_param_1_1);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_1 =
                    local_param_1_1_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_627f403e_dca18c16(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0 == CommonReusedValues.Blob_Int_0)
            {
                return CommonReusedValues.Blob_Int_0;
            }

            if (Global_Anonymous.zzz_anon_d97a2014_dda26649(
                Pine_KernelFunctionFused.SkipAndTake(
                    takeCount: 4,
                    skipCountValue:
                    Pine_KernelFunctionSpecialized.int_add(-4, local_param_1_0),
                    argument: local_param_1_1)) == Pine_PineKernelValues.TrueValue)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(-4, local_param_1_0);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine_PineValue zzz_anon_632693ae_2f148225(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_0, 0))
            {
                if (local_param_1_1 == Pine_PineValue.EmptyList)
                {
                    return CommonReusedValues.List_Single_Blob_Char_digit_0;
                }

                return local_param_1_1;
            }

            Pine_PineValue local_000 =
                Basics.idiv(local_param_1_0, CommonReusedValues.Blob_Int_10);

            {
                Pine_PineValue local_param_1_0_temp =
                    local_000;

                Pine_PineValue local_param_1_1_temp =
                    Pine_KernelFunctionFused.ListPrependItem(
                        itemToPrepend:
                        Global_Anonymous.zzz_anon_39fa68f8_2402eeb0(
                            Pine_KernelFunctionSpecialized.int_add(
                                local_param_1_0,
                                Pine_KernelFunctionSpecialized.int_mul(-10, local_000))),
                        suffix: local_param_1_1);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_1 =
                    local_param_1_1_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_654f47c2_dda26649(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_ListValue,
                        Pine_PineValue.List(
                            [
                                Pine_KernelFunction.reverse(
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        param_1_0,
                                        [1, 0]))
                            ])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [
                                Pine_KernelFunction.reverse(
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        param_1_0,
                                        [1, 0]))
                            ])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_71085723_0e649b4d(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_1.GetHead();

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_BlobValue == local_001)
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Pine_KernelFunctionSpecialized.concat(
                                local_param_1_0,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1, 0]));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                if (CommonReusedValues.Blob_Str_ListValue == local_001)
                {
                    if (Pine_KernelFunctionSpecialized.length_as_int(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_000,
                            [1, 0])) == 0)
                    {
                        {
                            local_param_1_1 =
                                local_param_1_1.Skip(1);
                        }

                        continue;
                    }

                    return CommonReusedValues.List_1f3f2fca;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [local_param_1_0])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_71e97dac_ffce8e79(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if (((CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (2 == Pine_KernelFunctionSpecialized.length_as_int(local_000))) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_002 =
                Pine.intFromValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]));

            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_003)
            {
                Pine_PineValue local_004 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1, 0]);

                Pine_PineValue local_005 =
                    Basics.idiv(local_004, CommonReusedValues.Blob_Int_8);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Global_Anonymous.zzz_anon_0965dc45_5db01df0(
                                        Pine_PineValue.EmptyList,
                                        Pine_KernelFunctionSpecialized.concat(
                                            Global_Anonymous.zzz_anon_610ee3fc_622604de(Pine_PineValue.EmptyList, local_005, CommonReusedValues.Blob_Int_0),
                                            Pine_KernelFunction.reverse(
                                                Pine_KernelFunctionSpecialized.skip(
                                                    local_005,
                                                    Pine_KernelFunction.reverse(
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            local_001,
                                                            [1, 0]))))),
                                        CommonReusedValues.Blob_Int_0,
                                        Pine_KernelFunctionSpecialized.int_add(
                                            local_004,
                                            Pine_KernelFunctionSpecialized.int_mul(
                                                Pine_IntegerEncoding.EncodeSignedInteger(-1),
                                                local_005,
                                                8)))
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_003)
            {
                return CommonReusedValues.List_1f3f2fca;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_7385b2ee_72163947(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_1.GetHead();

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_ListValue == local_001)
                {
                    {
                        local_param_1_0 =
                            local_param_1_0.AppendItems(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1, 0])
                                ]);

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                if (CommonReusedValues.Blob_Str_BlobValue == local_001)
                {
                    return CommonReusedValues.List_1f3f2fca;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_ListValue,
                        Pine_PineValue.List(
                            [
                                local_param_1_0.Evaluate()
                            ])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_74bc1f66_75b3ecdf(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_002 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        Pine_PineValue local_007 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine_PineValue local_008 =
            Basics.abs(local_002);

        Pine_PineValue local_011 =
            Basics.abs(local_007);

        Pine_PineValue local_014 =
            Global_Anonymous.zzz_anon_c0038bd7_9dbf17cd(local_008, local_011);

        Pine_PineValue local_017 =
            Basics.idiv(local_002, local_014);

        Pine_PineValue local_018 =
            Basics.idiv(local_007, local_014);

        if (local_018 == CommonReusedValues.Blob_Int_1)
        {
            return local_017;
        }

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Elm_Float,
                    Pine_PineValue.List(
                        [local_017, local_018])
                ]);
    }


    public static Pine_PineValue zzz_anon_7a86a9ad_91692913(Pine_PineValue param_1_0)
    {
        return String.fromInt(param_1_0);
    }


    public static Pine_PineValue zzz_anon_7b787121_f754fd7c(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    Pine.bigIntFromValue(
                        local_param_1_1.GetHead());

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_Ok == local_001)
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Pine_KernelFunctionSpecialized.int_add(
                                local_param_1_0,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1, 0]));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                if (CommonReusedValues.Blob_Str_Err == local_001)
                {
                    return CommonReusedValues.List_1f3f2fca;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return Pine.valueFromBigInt(local_param_1_0);
        }
    }


    public static Pine_PineValue zzz_anon_7dd973c9_1b8db7d8(
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2,
        Pine_PineValue param_1_3,
        Pine_PineValue param_1_4,
        Pine_PineValue param_1_5,
        Pine_PineValue param_1_6)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_5,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_5,
            [0])))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                param_1_2,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [2]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [3]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_dafb9d35,
                                                param_1_3,
                                                param_1_4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [4]),
                                                param_1_6
                                            ])
                                    ])
                            ])
                    ]);
        }

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_6,
                [1]);

        Pine_PineValue local_002 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [3]);

        if ((((CommonReusedValues.Blob_Str_Black == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0]))) && (CommonReusedValues.Blob_Str_Black == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_6,
            [0])))
        {
            return Global_Anonymous.zzz_anon_c051d150_dda26649(param_1_1);
        }

        if (((CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0])) && (CommonReusedValues.Blob_Str_Black == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_6,
            [0])))
        {
            return Global_Anonymous.zzz_anon_c051d150_dda26649(param_1_1);
        }

        return param_1_1;
    }


    public static Pine_PineValue zzz_anon_84cfa0a1_4c3796cb(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_1, argument: local_param_1_0);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_1;
            }

            if (local_000 == CommonReusedValues.Blob_Char_doublequote)
            {
                return local_param_1_1;
            }

            if (local_000 == CommonReusedValues.Blob_Char_backslash)
            {
                return local_param_1_1;
            }

            {
                Pine_PineValue local_param_1_1_temp =
                    Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                local_param_1_1 =
                    local_param_1_1_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_85977333_62796127(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            local_param_1_1.GetHead(),
                            Global_Anonymous.zzz_anon_2c70f359_fc8e1519(CommonReusedValues.Blob_Int_256, local_param_1_0));

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1.Skip(1);
                }

                continue;
            }

            if (local_param_1_1.IsEmptyList())
            {
                return local_param_1_0;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_86fe94db_dcf85806(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        Pine_ImmutableSliceBuilder local_param_1_2 =
            Pine_ImmutableSliceBuilder.Create(param_1_2);

        while (true)
        {
            if (local_param_1_1.IsEmptyList())
            {
                return local_param_1_0.Evaluate();
            }

            if (!(local_param_1_1.GetLength() == 0))
            {
                if (local_param_1_2.IsEmptyList())
                {
                    return local_param_1_0.Evaluate();
                }

                if (!(local_param_1_2.GetLength() == 0))
                {
                    {
                        local_param_1_0 =
                            local_param_1_0.PrependItems(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Bitwise.and(
                                                local_param_1_1.GetHead(),
                                                local_param_1_2.GetHead())
                                        ])
                                ]);

                        local_param_1_1 =
                            local_param_1_1.Skip(1);

                        local_param_1_2 =
                            local_param_1_2.Skip(1);
                    }

                    continue;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_8792c675_b6a881f2(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (local_param_1_1.IsEmptyList())
            {
                return local_param_1_0.EvaluateReverse();
            }

            if (!(local_param_1_1.GetLength() == 0))
            {
                {
                    local_param_1_0 =
                        local_param_1_0.PrependItems(
                            [
                                Pine_PineValue.List(
                                    [
                                        Pine.blobBytesFromChar(
                                            local_param_1_1.GetHead())
                                    ])
                            ]);

                    local_param_1_1 =
                        local_param_1_1.Skip(1);
                }

                continue;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_8c8348da_dda26649(Pine_PineValue param_1_0)
    {
        return
            Pine_KernelFunctionSpecialized.skip(
                1,
                Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: param_1_0));
    }


    public static Pine_PineValue zzz_anon_9a7c1e1b_386942a1(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_1,
                [0]);

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (Basics.eq(param_1_0, local_002) == Pine_PineKernelValues.TrueValue)
            {
                Pine_PineValue local_004 =
                    Global_Anonymous.zzz_anon_f164dec2_b6de04bb(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4]));

                Pine_PineValue local_005 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [0]);

                if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_005)
                {
                    Pine_PineValue local_006 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [1]);

                    return
                        Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [0]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [2]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [3]),
                            Global_Anonymous.zzz_anon_fe575105_eb1f9043(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])));
                }

                if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_005)
                {
                    return CommonReusedValues.List_71a3df23;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [0]),
                    local_002,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [2]),
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [3]),
                    Global_Anonymous.zzz_anon_ac3e6060_386942a1(
                        param_1_0,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4])));
        }

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return CommonReusedValues.List_71a3df23;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_9f1a9bb1_3c85cbf2(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2,
        Pine_PineValue param_1_3)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        Pine_PineValue local_param_1_3 =
            param_1_3;

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_002 =
                    Pine_KernelFunctionSpecialized.int_is_sorted_asc(
                        -2_147_483_648,
                        local_param_1_1.GetHead(),
                        -1);

                Pine_PineValue local_003 =
                    local_002 == Pine_PineKernelValues.TrueValue
                    ?
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.int_add(
                            2_147_483_648L,
                            local_param_1_1.GetHead()),
                        CommonReusedValues.Blob_8535093c)
                    :
                    Pine_KernelFunctionSpecialized.bit_or(
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            local_param_1_1.GetHead()),
                        CommonReusedValues.Blob_e429d1a2);

                Pine_PineValue local_004 =
                    Pine_PineValue.List(
                        [local_param_1_3, local_003]);

                Pine_PineValue local_005 =
                    Pine_KernelFunction.bit_shift_left(local_004);

                Pine_PineValue local_007 =
                    Pine_KernelFunctionSpecialized.bit_and(local_005, CommonReusedValues.Blob_1d285b09);

                Pine_PineValue local_009 =
                    Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_007);

                {
                    Pine_PineValue local_param_1_2_temp =
                        Bitwise.shiftRightBy(
                            Pine_KernelFunctionSpecialized.int_add(
                                8,
                                Pine_KernelFunction.negate(local_param_1_3)),
                            local_param_1_1.GetHead());

                    local_param_1_0 =
                        local_param_1_0.PrependItems(
                            [
                                Pine_PineValue.List(
                                    [
                                        Bitwise.and(
                                            CommonReusedValues.Blob_Int_255,
                                            Bitwise.or(
                                                Pine_KernelFunctionSpecialized.bit_and(local_005, CommonReusedValues.Blob_8535093c) == CommonReusedValues.Blob_8535093c
                                                ?
                                                Pine_KernelFunctionSpecialized.int_add(-2_147_483_648, local_009)
                                                :
                                                Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: local_007),
                                                local_param_1_2))
                                    ])
                            ]);

                    local_param_1_1 =
                        local_param_1_1.Skip(1);

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_param_1_1.IsEmptyList())
            {
                return local_param_1_0.Evaluate();
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_a418ab23_4792582f(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_003 =
            Json.Decode.skipWhitespace(param_1_0, param_1_1);

        Pine_PineValue local_004 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_003, argument: param_1_0);

        if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_dd9beacb, local_003]);
        }

        if (local_004 == CommonReusedValues.Blob_Char_letter_n)
        {
            return Global_Anonymous.zzz_anon_1c3c9562_dda26649(param_1_0, local_003);
        }

        if (local_004 == CommonReusedValues.Blob_Char_letter_t)
        {
            return Global_Anonymous.zzz_anon_2486a52f_dda26649(param_1_0, local_003);
        }

        if (local_004 == CommonReusedValues.Blob_Char_letter_f)
        {
            return Global_Anonymous.zzz_anon_a53d91b2_dda26649(param_1_0, local_003);
        }

        if (local_004 == CommonReusedValues.Blob_Char_doublequote)
        {
            Pine_PineValue local_007 =
                Pine_KernelFunctionSpecialized.int_add(4, local_003);

            Pine_PineValue local_010 =
                Global_Anonymous.zzz_anon_1261ac32_458f62e0(param_1_0, local_007);

            Pine_PineValue local_011 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_010,
                    [0]);

            Pine_PineValue local_012 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_011,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_012)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_StringValue,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_011,
                                                                [1, 0])
                                                        ])
                                                ])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_010,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_012)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_011,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_010,
                                [1])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        if (local_004 == CommonReusedValues.Blob_Char_bracketopen)
        {
            Pine_PineValue local_006 =
                Pine_KernelFunctionSpecialized.int_add(4, local_003);

            Pine_PineValue local_014 =
                Global_Anonymous.zzz_anon_e0c3df04_2f3c7b11(param_1_0, local_006);

            Pine_PineValue local_015 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_014,
                    [0]);

            Pine_PineValue local_016 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_015,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_016)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_ArrayValue,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_015,
                                                                [1, 0])
                                                        ])
                                                ])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_014,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_016)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_015,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_014,
                                [1])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        if (local_004 == CommonReusedValues.Blob_Char_braceopen)
        {
            Pine_PineValue local_008 =
                Pine_KernelFunctionSpecialized.int_add(4, local_003);

            Pine_PineValue local_018 =
                Global_Anonymous.zzz_anon_c9f48cad_2f3c7b11(Pine_PineValue.EmptyList, param_1_0, local_008);

            Pine_PineValue local_019 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_018,
                    [0]);

            Pine_PineValue local_020 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_019,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_020)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_ObjectValue,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_019,
                                                                [1, 0])
                                                        ])
                                                ])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_018,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_020)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_019,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_018,
                                [1])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        if (local_004 == CommonReusedValues.Blob_Char_hyphen)
        {
            return Global_Anonymous.zzz_anon_de1b5d74_826201ed(param_1_0, local_003);
        }

        if (Pine_KernelFunctionSpecialized.int_is_sorted_asc(
            48,
            Pine_KernelFunctionFused.BlobPrependByte(byteToPrepend: 4, suffix: local_004),
            57) == Pine_PineKernelValues.TrueValue)
        {
            return Global_Anonymous.zzz_anon_de1b5d74_826201ed(param_1_0, local_003);
        }

        return
            Pine_PineValue.List(
                [
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunction.concat(
                                                        Pine_PineValue.List(
                                                            [CommonReusedValues.Blob_1c62c0ae, local_004, CommonReusedValues.Blob_Char_quote]))
                                                ])
                                        ])
                                ])
                        ]),
                    local_003
                ]);
    }


    public static Pine_PineValue zzz_anon_a4d551c6_1b1ad183(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_1.GetHead();

                if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]))
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Global_Anonymous.zzz_anon_bde8ecf0_3959ade7(
                                Pine_PineValue.EmptyList,
                                Pine_KernelFunction.reverse(local_param_1_0),
                                Pine_KernelFunction.reverse(
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1, 0])));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                return CommonReusedValues.List_1f3f2fca;
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [local_param_1_0])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_a4d551c6_9577ce8c(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_1.GetHead();

                if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]))
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Global_Anonymous.zzz_anon_bde8ecf0_d5148ce6(
                                Pine_PineValue.EmptyList,
                                Pine_KernelFunction.reverse(local_param_1_0),
                                Pine_KernelFunction.reverse(
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1, 0])));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                return CommonReusedValues.List_1f3f2fca;
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [local_param_1_0])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_a4d551c6_9e8e4732(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (!(local_param_1_1.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_1.GetHead();

                if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]))
                {
                    {
                        Pine_PineValue local_param_1_0_temp =
                            Global_Anonymous.zzz_anon_86fe94db_dcf85806(
                                Pine_PineValue.EmptyList,
                                Pine_KernelFunction.reverse(local_param_1_0),
                                Pine_KernelFunction.reverse(
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1, 0])));

                        local_param_1_0 =
                            local_param_1_0_temp;

                        local_param_1_1 =
                            local_param_1_1.Skip(1);
                    }

                    continue;
                }

                return CommonReusedValues.List_1f3f2fca;
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [local_param_1_0])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_a53d91b2_dda26649(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 20, skipCountValue: param_1_1, argument: param_1_0) == CommonReusedValues.Blob_Str_false)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.List_6ffc58a4,
                        Pine_KernelFunctionSpecialized.int_add(20, param_1_1)
                    ]);
        }

        return
            Pine_PineValue.List(
                [CommonReusedValues.List_3f5a34c4, param_1_1]);
    }


    public static Pine_PineValue zzz_anon_a53f6616_0ba75d05(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [0]);

        if ((CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return
                Global_Anonymous.zzz_anon_a4d551c6_9e8e4732(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1, 0]),
                    Pine_KernelFunctionSpecialized.skip(1, local_000));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_a53f6616_9436b59a(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [0]);

        if ((CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return
                Global_Anonymous.zzz_anon_a4d551c6_1b1ad183(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1, 0]),
                    Pine_KernelFunctionSpecialized.skip(1, local_000));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_a53f6616_fef8748c(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [0]);

        if ((CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            return
                Global_Anonymous.zzz_anon_a4d551c6_9577ce8c(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1, 0]),
                    Pine_KernelFunctionSpecialized.skip(1, local_000));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_ac3e6060_386942a1(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_1,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return CommonReusedValues.List_71a3df23;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (Basics.lt(param_1_0, local_002) == Pine_PineKernelValues.TrueValue)
            {
                Pine_PineValue local_003 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [3]);

                Pine_PineValue local_004 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_003,
                        [1]);

                if ((CommonReusedValues.Blob_Str_Black == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_004,
                    [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0])))
                {
                    Pine_PineValue local_005 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [3]);

                    if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [0])))
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [0]),
                                            local_002,
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [2]),
                                            Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, local_003),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [4])
                                        ])
                                ]);
                    }

                    Pine_PineValue local_006 =
                        Global_Anonymous.zzz_anon_59345918_dda26649(param_1_1);

                    Pine_PineValue local_007 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_006,
                            [0]);

                    if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_007)
                    {
                        Pine_PineValue local_008 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]);

                        return
                            Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [0]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [2]),
                                Global_Anonymous.zzz_anon_ac3e6060_386942a1(
                                    param_1_0,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_008,
                                        [3])),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [4]));
                    }

                    if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_007)
                    {
                        return CommonReusedValues.List_71a3df23;
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [0]),
                                    local_002,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [2]),
                                    Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, local_003),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [4])
                                ])
                        ]);
            }

            return
                Global_Anonymous.zzz_anon_9a7c1e1b_386942a1(
                    param_1_0,
                    Global_Anonymous.zzz_anon_7dd973c9_1b8db7d8(
                        param_1_1,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [0]),
                        local_002,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [2]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [3]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4])));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_af114e29_9571f2bd(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_001 =
            Pine_KernelFunctionSpecialized.int_add(8, param_1_1);

        Pine_PineValue local_002 =
            Pine_KernelFunctionFused.SkipAndTake(
                takeCount: 4,
                skipCountValue:
                Pine_KernelFunctionSpecialized.int_add(4, param_1_1),
                argument: param_1_0);

        if (local_002 == CommonReusedValues.Blob_Char_letter_n)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_37ef0489, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_letter_r)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_4c7a2d92, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_letter_t)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_4789147c, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_doublequote)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_9087256b, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_backslash)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_7934be19, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_slash)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_b91653d1, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_letter_b)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_d52034db, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_letter_f)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_ddef59c1, local_001]);
        }

        if (local_002 == CommonReusedValues.Blob_Char_letter_u)
        {
            return Global_Anonymous.zzz_anon_4822613b_206e486b(param_1_0, local_001);
        }

        return
            Pine_PineValue.List(
                [
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunctionSpecialized.concat(CommonReusedValues.Blob_82705a0a, local_002)
                                                ])
                                        ])
                                ])
                        ]),
                    local_001
                ]);
    }


    public static Pine_PineValue zzz_anon_b0876be7_3c458f0b(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2,
        Pine_PineValue param_1_3)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        Pine_PineValue local_param_1_3 =
            param_1_3;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(
                    takeCountValue:
                    Pine_IntegerEncoding.EncodeSignedInteger(
                        Pine_KernelFunctionSpecialized.length_as_int(local_param_1_2)),
                    skipCountValue:
                    Pine_KernelFunctionSpecialized.int_mul(4, local_param_1_0),
                    argument: local_param_1_3);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_1;
            }

            Pine_PineValue local_002 =
                Pine_KernelFunctionSpecialized.int_add(1, local_param_1_0);

            if (local_000 == local_param_1_2)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_002;

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionFused.ListAppendItem(prefix: local_param_1_1, itemToAppend: local_param_1_0);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    local_002;

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_bde8ecf0_3959ade7(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        Pine_ImmutableSliceBuilder local_param_1_2 =
            Pine_ImmutableSliceBuilder.Create(param_1_2);

        while (true)
        {
            if (local_param_1_1.IsEmptyList())
            {
                return
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.reverse(
                            local_param_1_2.Evaluate()),
                        local_param_1_0.Evaluate());
            }

            if (!(local_param_1_1.GetLength() == 0))
            {
                if (local_param_1_2.IsEmptyList())
                {
                    return
                        Pine_KernelFunctionSpecialized.concat(
                            Pine_KernelFunction.reverse(
                                local_param_1_1.Evaluate()),
                            local_param_1_0.Evaluate());
                }

                if (!(local_param_1_2.GetLength() == 0))
                {
                    {
                        local_param_1_0 =
                            local_param_1_0.PrependItems(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Bitwise.xor(
                                                local_param_1_1.GetHead(),
                                                local_param_1_2.GetHead())
                                        ])
                                ]);

                        local_param_1_1 =
                            local_param_1_1.Skip(1);

                        local_param_1_2 =
                            local_param_1_2.Skip(1);
                    }

                    continue;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_bde8ecf0_d5148ce6(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        Pine_ImmutableSliceBuilder local_param_1_2 =
            Pine_ImmutableSliceBuilder.Create(param_1_2);

        while (true)
        {
            if (local_param_1_1.IsEmptyList())
            {
                return
                    Pine_KernelFunctionSpecialized.concat(
                        Pine_KernelFunction.reverse(
                            local_param_1_2.Evaluate()),
                        local_param_1_0.Evaluate());
            }

            if (!(local_param_1_1.GetLength() == 0))
            {
                if (local_param_1_2.IsEmptyList())
                {
                    return
                        Pine_KernelFunctionSpecialized.concat(
                            Pine_KernelFunction.reverse(
                                local_param_1_1.Evaluate()),
                            local_param_1_0.Evaluate());
                }

                if (!(local_param_1_2.GetLength() == 0))
                {
                    {
                        local_param_1_0 =
                            local_param_1_0.PrependItems(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Bitwise.or(
                                                local_param_1_1.GetHead(),
                                                local_param_1_2.GetHead())
                                        ])
                                ]);

                        local_param_1_1 =
                            local_param_1_1.Skip(1);

                        local_param_1_2 =
                            local_param_1_2.Skip(1);
                    }

                    continue;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_bef7232d_3c2bb8d5(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableConcatBuilder local_param_1_1 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_1]);

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_0, argument: local_param_1_2);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_1.Evaluate();
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    Pine_KernelFunctionSpecialized.int_add(4, local_param_1_0);

                local_param_1_1 =
                    local_param_1_1.AppendItems(
                        [
                            Pine_PineValue.List(
                                [local_000])
                        ]);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_c0038bd7_9dbf17cd(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_1 == CommonReusedValues.Blob_Int_0)
            {
                return local_param_1_0;
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    local_param_1_1;

                Pine_PineValue local_param_1_1_temp =
                    Basics.modBy(local_param_1_1, local_param_1_0);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_1 =
                    local_param_1_1_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_c051d150_dda26649(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [4]);

        Pine_PineValue local_002 =
            Pine_KernelFunction.ValueFromBool(
                CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]));

        if (((((local_002 == Pine_PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 1, 3, 1, 0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 1, 3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [3, 1]);

            Pine_PineValue local_004 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            Pine_PineValue local_005 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [3, 1]);

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_003,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_003,
                                    [2]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [1]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [2]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [3]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [4])
                                            ])
                                    ]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [1]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [2]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [4]),
                                                Pine_PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                                        Pine_PineValue.List(
                                                            [
                                                                CommonReusedValues.List_dafb9d35,
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [1]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [2]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [3]),
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [4])
                                                            ])
                                                    ])
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (((local_002 == Pine_PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_006 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]);

            Pine_PineValue local_007 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Black == local_007)
            {
                Pine_PineValue local_008 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                Pine_PineValue local_009 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1]);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [4])
                                                ])
                                        ]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Red == local_007)
            {
                Pine_PineValue local_010 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                Pine_PineValue local_011 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1]);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [4])
                                                ])
                                        ]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return param_1_0;
    }


    public static Pine_PineValue zzz_anon_c78b4c00_dda26649(Pine_PineValue param_1_0)
    {
        return
            Pine_KernelFunctionSpecialized.equal(
                Pine_KernelFunctionSpecialized.take(0, param_1_0),
                Pine_PineValue.EmptyList);
    }


    public static Pine_PineValue zzz_anon_c9f48cad_2f3c7b11(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_003 =
            Json.Decode.skipWhitespace(param_1_1, param_1_2);

        Pine_PineValue local_004 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_003, argument: param_1_1);

        if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_e78d4da6, local_003]);
        }

        if (local_004 == CommonReusedValues.Blob_Char_braceclose)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [param_1_0])
                            ]),
                        Pine_KernelFunctionSpecialized.int_add(4, local_003)
                    ]);
        }

        if (local_004 == CommonReusedValues.Blob_Char_doublequote)
        {
            Pine_PineValue local_007 =
                Pine_KernelFunctionSpecialized.int_add(4, local_003);

            Pine_PineValue local_010 =
                Global_Anonymous.zzz_anon_1261ac32_458f62e0(param_1_1, local_007);

            Pine_PineValue local_011 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_010,
                    [0]);

            Pine_PineValue local_012 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_011,
                    [0]);

            if (CommonReusedValues.Blob_Str_Err == local_012)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_011,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_010,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Ok == local_012)
            {
                Pine_PineValue local_015 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_010,
                        [1]);

                Pine_PineValue local_018 =
                    Json.Decode.skipWhitespace(param_1_1, local_015);

                if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_018, argument: param_1_1) == CommonReusedValues.Blob_Char_colon)
                {
                    Pine_PineValue local_020 =
                        Pine_KernelFunctionSpecialized.int_add(4, local_018);

                    Pine_PineValue local_023 =
                        Json.Decode.skipWhitespace(param_1_1, local_020);

                    Pine_PineValue local_027 =
                        Global_Anonymous.zzz_anon_a418ab23_4792582f(param_1_1, local_023);

                    Pine_PineValue local_028 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_027,
                            [0]);

                    Pine_PineValue local_029 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_028,
                            [0]);

                    if (CommonReusedValues.Blob_Str_Err == local_029)
                    {
                        return
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_Err,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_Str_String,
                                                            Pine_PineValue.List(
                                                                [
                                                                    Pine_KernelFunctionSpecialized.concat(
                                                                        CommonReusedValues.Blob_be4af37b,
                                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                            local_028,
                                                                            [1, 0, 1, 0]))
                                                                ])
                                                        ])
                                                ])
                                        ]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_027,
                                        [1])
                                ]);
                    }

                    if (CommonReusedValues.Blob_Str_Ok == local_029)
                    {
                        Pine_PineValue local_032 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_027,
                                [1]);

                        Pine_PineValue local_035 =
                            Json.Decode.skipWhitespace(param_1_1, local_032);

                        Pine_PineValue local_036 =
                            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_035, argument: param_1_1);

                        if (Pine_KernelFunctionSpecialized.length_as_int(local_036) == 0)
                        {
                            return
                                Pine_PineValue.List(
                                    [CommonReusedValues.List_eb223cfd, local_035]);
                        }

                        if (local_036 == CommonReusedValues.Blob_Char_comma)
                        {
                            Pine_PineValue local_037 =
                                Pine_KernelFunctionFused.ListAppendItem(
                                    prefix: param_1_0,
                                    itemToAppend:
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_011,
                                                [1, 0]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_028,
                                                [1, 0])
                                        ]));

                            return
                                Global_Anonymous.zzz_anon_c9f48cad_c41a8a1a(
                                    local_037,
                                    param_1_1,
                                    Pine_KernelFunctionSpecialized.int_add(4, local_035));
                        }

                        if (local_036 == CommonReusedValues.Blob_Char_braceclose)
                        {
                            return
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_Ok,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_KernelFunctionFused.ListAppendItem(
                                                            prefix: param_1_0,
                                                            itemToAppend:
                                                            Pine_PineValue.List(
                                                                [
                                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                        local_011,
                                                                        [1, 0]),
                                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                        local_028,
                                                                        [1, 0])
                                                                ]))
                                                    ])
                                            ]),
                                        Pine_KernelFunctionSpecialized.int_add(4, local_035)
                                    ]);
                        }

                        return
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_Err,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_Str_String,
                                                            Pine_PineValue.List(
                                                                [
                                                                    Pine_KernelFunction.concat(
                                                                        Pine_PineValue.List(
                                                                            [CommonReusedValues.Blob_75974129, local_036, CommonReusedValues.Blob_Char_quote]))
                                                                ])
                                                        ])
                                                ])
                                        ]),
                                    local_035
                                ]);
                    }

                    throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_String,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_KernelFunction.concat(
                                                                Pine_PineValue.List(
                                                                    [
                                                                        CommonReusedValues.Blob_cd41159b,
                                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                            local_011,
                                                                            [1, 0, 1, 0]),
                                                                        CommonReusedValues.Blob_Char_quote
                                                                    ]))
                                                        ])
                                                ])
                                        ])
                                ]),
                            local_018
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return
            Pine_PineValue.List(
                [
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunction.concat(
                                                        Pine_PineValue.List(
                                                            [CommonReusedValues.Blob_3200f35a, local_004, CommonReusedValues.Blob_Char_quote]))
                                                ])
                                        ])
                                ])
                        ]),
                    local_003
                ]);
    }


    public static Pine_PineValue zzz_anon_c9f48cad_c41a8a1a(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_003 =
                Json.Decode.skipWhitespace(local_param_1_1, local_param_1_2);

            Pine_PineValue local_004 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_003, argument: local_param_1_1);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
            {
                return
                    Pine_PineValue.List(
                        [CommonReusedValues.List_e78d4da6, local_003]);
            }

            if (local_004 == CommonReusedValues.Blob_Char_braceclose)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [local_param_1_0])
                                ]),
                            Pine_KernelFunctionSpecialized.int_add(4, local_003)
                        ]);
            }

            if (local_004 == CommonReusedValues.Blob_Char_doublequote)
            {
                Pine_PineValue local_007 =
                    Pine_KernelFunctionSpecialized.int_add(4, local_003);

                Pine_PineValue local_010 =
                    Global_Anonymous.zzz_anon_1261ac32_458f62e0(local_param_1_1, local_007);

                Pine_PineValue local_011 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_010,
                        [0]);

                Pine_PineValue local_012 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_011,
                        [0]);

                if (CommonReusedValues.Blob_Str_Err == local_012)
                {
                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Err,
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_011,
                                                    [1, 0])
                                            ])
                                    ]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_010,
                                    [1])
                            ]);
                }

                if (CommonReusedValues.Blob_Str_Ok == local_012)
                {
                    Pine_PineValue local_015 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_010,
                            [1]);

                    Pine_PineValue local_018 =
                        Json.Decode.skipWhitespace(local_param_1_1, local_015);

                    if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_018, argument: local_param_1_1) == CommonReusedValues.Blob_Char_colon)
                    {
                        Pine_PineValue local_020 =
                            Pine_KernelFunctionSpecialized.int_add(4, local_018);

                        Pine_PineValue local_023 =
                            Json.Decode.skipWhitespace(local_param_1_1, local_020);

                        Pine_PineValue local_027 =
                            Global_Anonymous.zzz_anon_a418ab23_4792582f(local_param_1_1, local_023);

                        Pine_PineValue local_028 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_027,
                                [0]);

                        Pine_PineValue local_029 =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_028,
                                [0]);

                        if (CommonReusedValues.Blob_Str_Err == local_029)
                        {
                            return
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_Err,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_PineValue.List(
                                                            [
                                                                CommonReusedValues.Blob_Str_String,
                                                                Pine_PineValue.List(
                                                                    [
                                                                        Pine_KernelFunctionSpecialized.concat(
                                                                            CommonReusedValues.Blob_be4af37b,
                                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                                local_028,
                                                                                [1, 0, 1, 0]))
                                                                    ])
                                                            ])
                                                    ])
                                            ]),
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_027,
                                            [1])
                                    ]);
                        }

                        if (CommonReusedValues.Blob_Str_Ok == local_029)
                        {
                            Pine_PineValue local_032 =
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_027,
                                    [1]);

                            Pine_PineValue local_035 =
                                Json.Decode.skipWhitespace(local_param_1_1, local_032);

                            Pine_PineValue local_036 =
                                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_035, argument: local_param_1_1);

                            if (Pine_KernelFunctionSpecialized.length_as_int(local_036) == 0)
                            {
                                return
                                    Pine_PineValue.List(
                                        [CommonReusedValues.List_eb223cfd, local_035]);
                            }

                            if (local_036 == CommonReusedValues.Blob_Char_comma)
                            {
                                Pine_PineValue local_037 =
                                    Pine_KernelFunctionFused.ListAppendItem(
                                        prefix: local_param_1_0,
                                        itemToAppend:
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_011,
                                                    [1, 0]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_028,
                                                    [1, 0])
                                            ]));

                                {
                                    Pine_PineValue local_param_1_0_temp =
                                        local_037;

                                    Pine_PineValue local_param_1_2_temp =
                                        Pine_KernelFunctionSpecialized.int_add(4, local_035);

                                    local_param_1_0 =
                                        local_param_1_0_temp;

                                    local_param_1_2 =
                                        local_param_1_2_temp;
                                }

                                continue;
                            }

                            if (local_036 == CommonReusedValues.Blob_Char_braceclose)
                            {
                                return
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_Ok,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_KernelFunctionFused.ListAppendItem(
                                                                prefix: local_param_1_0,
                                                                itemToAppend:
                                                                Pine_PineValue.List(
                                                                    [
                                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                            local_011,
                                                                            [1, 0]),
                                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                            local_028,
                                                                            [1, 0])
                                                                    ]))
                                                        ])
                                                ]),
                                            Pine_KernelFunctionSpecialized.int_add(4, local_035)
                                        ]);
                            }

                            return
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_Err,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_PineValue.List(
                                                            [
                                                                CommonReusedValues.Blob_Str_String,
                                                                Pine_PineValue.List(
                                                                    [
                                                                        Pine_KernelFunction.concat(
                                                                            Pine_PineValue.List(
                                                                                [CommonReusedValues.Blob_75974129, local_036, CommonReusedValues.Blob_Char_quote]))
                                                                    ])
                                                            ])
                                                    ])
                                            ]),
                                        local_035
                                    ]);
                        }

                        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                    }

                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Err,
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_String,
                                                        Pine_PineValue.List(
                                                            [
                                                                Pine_KernelFunction.concat(
                                                                    Pine_PineValue.List(
                                                                        [
                                                                            CommonReusedValues.Blob_cd41159b,
                                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                                local_011,
                                                                                [1, 0, 1, 0]),
                                                                            CommonReusedValues.Blob_Char_quote
                                                                        ]))
                                                            ])
                                                    ])
                                            ])
                                    ]),
                                local_018
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Err,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_String,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_KernelFunction.concat(
                                                            Pine_PineValue.List(
                                                                [CommonReusedValues.Blob_3200f35a, local_004, CommonReusedValues.Blob_Char_quote]))
                                                    ])
                                            ])
                                    ])
                            ]),
                        local_003
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_cbaaa061_7d092ddb(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        if ((2 == Pine_KernelFunctionSpecialized.length_as_int(local_000)) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_001 =
                Pine.intFromValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]));

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_002)
            {
                Pine_PineValue local_005 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [1]);

                Pine_PineValue local_006 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [0]);

                if (CommonReusedValues.Blob_Str_ListValue == local_006)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_ListValue,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionSpecialized.take(
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1, 0]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_005,
                                                [1, 0]))
                                    ])
                            ]);
                }

                if (CommonReusedValues.Blob_Str_BlobValue == local_006)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_BlobValue,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionSpecialized.take(
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1, 0]),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_005,
                                                [1, 0]))
                                    ])
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            if (CommonReusedValues.Blob_Str_Err == local_002)
            {
                return CommonReusedValues.List_1f3f2fca;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_cf00dbf7_71eb7c46(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_1, argument: local_param_1_2);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return
                    Pine_PineValue.List(
                        [local_param_1_0, local_param_1_1]);
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_0)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0);

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_1)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            1,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_2)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            2,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_3)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            3,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_4)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            4,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_5)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            5,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_6)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            6,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_7)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            7,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_8)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            8,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_9)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            9,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_a)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            10,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_A)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            10,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_b)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            11,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_B)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            11,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_c)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            12,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_C)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            12,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_d)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            13,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_D)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            13,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_e)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            14,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_E)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            14,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_f)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            15,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_letter_F)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            15,
                            Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_0));

                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            return CommonReusedValues.List_7d7a3f6a;
        }
    }


    public static Pine_PineValue zzz_anon_d651d7e2_c3da1d69(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_BlobValue,
                        Pine_PineValue.List(
                            [
                                Global_Anonymous.zzz_anon_4d84519b_c3da1d69(
                                    Pine_PineValue.EmptyList,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        param_1_0,
                                        [1, 0]))
                            ])
                    ]);
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_d6ebdb03_28e23645(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_ImmutableConcatBuilder local_param_1_2 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_2]);

        while (true)
        {
            Pine_PineValue local_003 =
                Global_Anonymous.zzz_anon_84cfa0a1_4c3796cb(local_param_1_0, local_param_1_1);

            Pine_PineValue local_004 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_003, argument: local_param_1_0);

            if (local_004 == CommonReusedValues.Blob_Char_doublequote)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_KernelFunctionFused.ListAppendItem(
                                                prefix:
                                                local_param_1_2.Evaluate(),
                                                itemToAppend:
                                                Pine_KernelFunctionFused.SkipAndTake(
                                                    takeCountValue:
                                                    Pine_KernelFunctionSpecialized.int_add(
                                                        local_003,
                                                        Pine_KernelFunctionSpecialized.int_mul(-1, local_param_1_1)),
                                                    skipCountValue: local_param_1_1,
                                                    argument: local_param_1_0))
                                        ])
                                ]),
                            Pine_KernelFunctionSpecialized.int_add(4, local_003)
                        ]);
            }

            if (local_004 == CommonReusedValues.Blob_Char_backslash)
            {
                Pine_PineValue local_008 =
                    Global_Anonymous.zzz_anon_af114e29_9571f2bd(local_param_1_0, local_003);

                Pine_PineValue local_009 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_008,
                        [0]);

                Pine_PineValue local_010 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_009,
                        [0]);

                if (CommonReusedValues.Blob_Str_Ok == local_010)
                {
                    {
                        Pine_PineValue local_param_1_1_temp =
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_008,
                                [1]);

                        local_param_1_2 =
                            local_param_1_2.AppendItems(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine_KernelFunctionFused.SkipAndTake(
                                                takeCountValue:
                                                Pine_KernelFunctionSpecialized.int_add(
                                                    local_003,
                                                    Pine_KernelFunctionSpecialized.int_mul(-1, local_param_1_1)),
                                                skipCountValue: local_param_1_1,
                                                argument: local_param_1_0),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_009,
                                                [1, 0])
                                        ])
                                ]);

                        local_param_1_1 =
                            local_param_1_1_temp;
                    }

                    continue;
                }

                if (CommonReusedValues.Blob_Str_Err == local_010)
                {
                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Err,
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_009,
                                                    [1, 0])
                                            ])
                                    ]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [1])
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_6cd9e430, local_003]);
        }
    }


    public static Pine_PineValue zzz_anon_d7dea71a_fd2dcdca(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_ImmutableConcatBuilder local_param_1_1 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_1]);

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_IntegerEncoding.EncodeSignedInteger(
                    Pine_KernelFunctionSpecialized.length_as_int(local_param_1_0));

            Pine_PineValue local_001 =
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(2, local_000)
                ?
                (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(3, local_000)
                ?
                Pine_KernelFunctionFused.SkipLast(skipCount: 1, value: local_param_1_0)
                :
                CommonReusedValues.Blob_Int_0)
                :
                Pine_PineValue.EmptyList;

            if (local_001 == CommonReusedValues.Blob_Int_0)
            {
                return
                    Pine_KernelFunctionFused.ListPrependItem(
                        itemToPrepend: local_param_1_0,
                        suffix:
                        local_param_1_1.Evaluate());
            }

            {
                Pine_PineValue local_param_1_0_temp =
                    local_001;

                local_param_1_1 =
                    local_param_1_1.PrependItems(
                        [
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionSpecialized.int_add(
                                        local_param_1_0,
                                        Pine_KernelFunctionSpecialized.int_mul(
                                            Pine_IntegerEncoding.EncodeSignedInteger(-1),
                                            local_001,
                                            256))
                                ])
                        ]);

                local_param_1_0 =
                    local_param_1_0_temp;
            }

            continue;
        }
    }


    public static Pine_PineValue zzz_anon_d97a2014_dda26649(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.Blob_Char_space)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_tab)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_newline)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_carriagereturn)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_nobreakspace)
        {
            return Pine_PineKernelValues.TrueValue;
        }

        return Pine_PineKernelValues.FalseValue;
    }


    public static Pine_PineValue zzz_anon_d9d31de4_0e649b4d(Pine_PineValue param_1_0)
    {
        Pine_ImmutableSliceBuilder local_param_1_0 =
            Pine_ImmutableSliceBuilder.Create(param_1_0);

        while (true)
        {
            if (!(local_param_1_0.GetLength() == 0))
            {
                Pine_PineValue local_000 =
                    local_param_1_0.GetHead();

                Pine_PineValue local_001 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]);

                if (CommonReusedValues.Blob_Str_ListValue == local_001)
                {
                    Pine_PineValue local_003 =
                        Pine_KernelFunctionSpecialized.skip(
                            1,
                            local_param_1_0.Evaluate());

                    Pine_PineValue local_004 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_000,
                            [1, 0]);

                    if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
                    {
                        {
                            local_param_1_0 =
                                local_param_1_0.Skip(1);
                        }

                        continue;
                    }

                    return Global_Anonymous.zzz_anon_7385b2ee_72163947(local_004, local_003);
                }

                if (CommonReusedValues.Blob_Str_BlobValue == local_001)
                {
                    return
                        Global_Anonymous.zzz_anon_71085723_0e649b4d(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_000,
                                [1, 0]),
                            Pine_KernelFunctionSpecialized.skip(
                                1,
                                local_param_1_0.Evaluate()));
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return CommonReusedValues.List_1f3f2fca;
        }
    }


    public static Pine_PineValue zzz_anon_dbf42a10_90befd56(Pine_PineValue param_1_0)
    {
        return
            String.toInt(
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]));
    }


    public static Pine_PineValue zzz_anon_dc80c2ca_a342fb06(Pine_PineValue param_1_0)
    {
        if (BigInt.lt(param_1_0, CommonReusedValues.Blob_Int_256) == Pine_PineKernelValues.TrueValue)
        {
            Pine_PineValue local_001 =
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    Global_Anonymous.zzz_anon_7a86a9ad_91692913(param_1_0));

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (CommonReusedValues.Blob_Str_Nothing == local_002)
            {
                return CommonReusedValues.List_13731c89;
            }

            if (CommonReusedValues.Blob_Str_Just == local_002)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Just,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1, 0])
                                        ])
                                ])
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        Pine_PineValue local_003 =
            BigInt.divmod(param_1_0, CommonReusedValues.Blob_Int_256);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [0]);

        if (CommonReusedValues.Blob_Str_Nothing == local_004)
        {
            return CommonReusedValues.List_13731c89;
        }

        if (CommonReusedValues.Blob_Str_Just == local_004)
        {
            Pine_PineValue local_005 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [1, 0]);

            Pine_PineValue local_006 =
                Global_Anonymous.zzz_anon_dc80c2ca_a342fb06(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [0]));

            Pine_PineValue local_007 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Nothing == local_007)
            {
                return CommonReusedValues.List_13731c89;
            }

            if (CommonReusedValues.Blob_Str_Just == local_007)
            {
                Pine_PineValue local_008 =
                    Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                        Global_Anonymous.zzz_anon_7a86a9ad_91692913(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_005,
                                [1])));

                Pine_PineValue local_009 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_008,
                        [0]);

                if (CommonReusedValues.Blob_Str_Nothing == local_009)
                {
                    return CommonReusedValues.List_13731c89;
                }

                if (CommonReusedValues.Blob_Str_Just == local_009)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Just,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunctionFused.ListAppendItem(
                                            prefix:
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_006,
                                                [1, 0]),
                                            itemToAppend:
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_008,
                                                [1, 0]))
                                    ])
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_dd880f82_13e5e91e(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableSliceBuilder local_param_1_0 =
            Pine_ImmutableSliceBuilder.Create(param_1_0);

        Pine_ImmutableSliceBuilder local_param_1_1 =
            Pine_ImmutableSliceBuilder.Create(param_1_1);

        while (true)
        {
            if (local_param_1_0.IsEmptyList())
            {
                return Pine_PineKernelValues.TrueValue;
            }

            if (Basics.eq(
                local_param_1_0.GetHead(),
                local_param_1_1.GetHead()) == Pine_PineKernelValues.TrueValue)
            {
                {
                    local_param_1_0 =
                        local_param_1_0.Skip(1);

                    local_param_1_1 =
                        local_param_1_1.Skip(1);
                }

                continue;
            }

            return Pine_PineKernelValues.FalseValue;
        }
    }


    public static Pine_PineValue zzz_anon_de1b5d74_826201ed(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_002 =
            Global_Anonymous.zzz_anon_4cf95911_826201ed(param_1_0, param_1_1);

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [0]);

        if (CommonReusedValues.Blob_Str_Ok == local_004)
        {
            Pine_PineValue local_007 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [1]);

            if (Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_007, argument: param_1_0) == CommonReusedValues.Blob_Char_dot)
            {
                Pine_PineValue local_010 =
                    Pine_KernelFunctionSpecialized.int_add(4, local_007);

                Pine_PineValue local_013 =
                    Global_Anonymous.zzz_anon_46782f74_0d2b56f6(param_1_0, local_010);

                Pine_PineValue local_014 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_013,
                        [0]);

                Pine_PineValue local_015 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_014,
                        [0]);

                if (CommonReusedValues.Blob_Str_Ok == local_015)
                {
                    Pine_PineValue local_016 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_013,
                            [1]);

                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Ok,
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_FloatValue,
                                                        Pine_PineValue.List(
                                                            [
                                                                Pine_PineValue.List(
                                                                    [
                                                                        CommonReusedValues.Blob_Str_String,
                                                                        Pine_PineValue.List(
                                                                            [
                                                                                Pine_KernelFunctionFused.SkipAndTake(
                                                                                    takeCountValue:
                                                                                    Pine_KernelFunctionSpecialized.int_add(
                                                                                        local_016,
                                                                                        Pine_KernelFunctionSpecialized.int_mul(-1, param_1_1)),
                                                                                    skipCountValue: param_1_1,
                                                                                    argument: param_1_0)
                                                                            ])
                                                                    ])
                                                            ])
                                                    ])
                                            ])
                                    ]),
                                local_016
                            ]);
                }

                if (CommonReusedValues.Blob_Str_Err == local_015)
                {
                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Err,
                                        Pine_PineValue.List(
                                            [
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_014,
                                                    [1, 0])
                                            ])
                                    ]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_013,
                                    [1])
                            ]);
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_IntValue,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            local_003,
                                                            [1, 0])
                                                    ])
                                            ])
                                    ])
                            ]),
                        local_007
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Err == local_004)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Err,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_003,
                                            [1, 0])
                                    ])
                            ]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_002,
                            [1])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_e0c3df04_2f3c7b11(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_003 =
            Json.Decode.skipWhitespace(param_1_0, param_1_1);

        Pine_PineValue local_004 =
            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_003, argument: param_1_0);

        if (Pine_KernelFunctionSpecialized.length_as_int(local_004) == 0)
        {
            return
                Pine_PineValue.List(
                    [CommonReusedValues.List_cd453f15, local_003]);
        }

        if (local_004 == CommonReusedValues.Blob_Char_bracketclose)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.List_53b35141,
                        Pine_KernelFunctionSpecialized.int_add(4, local_003)
                    ]);
        }

        return Global_Anonymous.zzz_anon_fa4fc55c_2f3c7b11(Pine_PineValue.EmptyList, param_1_0, local_003);
    }


    public static Pine_PineValue zzz_anon_e6d15ff4_dda26649(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2,
        Pine_PineValue param_1_3,
        Pine_PineValue param_1_4)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_4,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_4,
            [0])))
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_3,
                    [1]);

            Pine_PineValue local_010 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [1]);

            Pine_PineValue local_011 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [2]);

            Pine_PineValue local_012 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [3]);

            Pine_PineValue local_013 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [4]);

            if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_3,
                [0])))
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.List_dafb9d35,
                                    param_1_1,
                                    param_1_2,
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.List_7222f8d4,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [1]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [2]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [3]),
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [4])
                                                ])
                                        ]),
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine_PineValue.List(
                                                [CommonReusedValues.List_7222f8d4, local_010, local_011, local_012, local_013])
                                        ])
                                ])
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                param_1_0,
                                local_010,
                                local_011,
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [CommonReusedValues.List_dafb9d35, param_1_1, param_1_2, param_1_3, local_012])
                                    ]),
                                local_013
                            ])
                    ]);
        }

        Pine_PineValue local_002 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_3,
                [1]);

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [3]);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [1]);

        if ((((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_004,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_003,
            [0]))) && (CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_3,
            [0])))
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [2]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [1]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [2]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [3]),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [4])
                                            ])
                                    ]),
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                param_1_1,
                                                param_1_2,
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [4]),
                                                param_1_4
                                            ])
                                    ])
                            ])
                    ]);
        }

        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                    Pine_PineValue.List(
                        [param_1_0, param_1_1, param_1_2, param_1_3, param_1_4])
                ]);
    }


    public static Pine_PineValue zzz_anon_e8f8319b_490cdf76(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Global_Anonymous.zzz_anon_30535a07_c1817879(
                    CommonReusedValues.Blob_Int_1,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_e9c5a80a_a6ea216c(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        return
            Pine.valueFromBool(
                CommonReusedValues.Blob_Str_ListValue == local_000
                ?
                (Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]) == Pine_PineValue.EmptyList
                ?
                Pine_PineKernelValues.TrueValue
                :
                (!(Pine_KernelFunctionSpecialized.length_as_int(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0])) == 0)
                ?
                Global_Anonymous.zzz_anon_03d2d269_8e4089c4(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0, 0]),
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            param_1_0,
                            [1, 0])))
                :
                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
                :
                (CommonReusedValues.Blob_Str_BlobValue == local_000
                ?
                (Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]) == Pine_PineValue.EmptyList
                ?
                Pine_PineKernelValues.TrueValue
                :
                (!(Pine_KernelFunctionSpecialized.length_as_int(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0])) == 0)
                ?
                Global_Anonymous.zzz_anon_03d2d269_8e4089c4(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0, 0]),
                    Pine_KernelFunctionSpecialized.skip(
                        1,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            param_1_0,
                            [1, 0])))
                :
                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
                :
                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")));
    }


    public static Pine_PineValue zzz_anon_ea679199_b65beb0f(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_2,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [CommonReusedValues.List_dafb9d35, param_1_0, param_1_1, CommonReusedValues.List_71a3df23, CommonReusedValues.List_71a3df23])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_2,
                    [1]);

            Pine_PineValue local_006 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [1]);

            Pine_PineValue local_007 =
                Basics.compare(param_1_0, local_006);

            Pine_PineValue local_008 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_007,
                    [0]);

            if (CommonReusedValues.Blob_Str_LT == local_008)
            {
                return
                    Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [0]),
                        local_006,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [2]),
                        Global_Anonymous.zzz_anon_ea679199_b65beb0f(
                            param_1_0,
                            param_1_1,
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_003,
                                [3])),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [4]));
            }

            if (CommonReusedValues.Blob_Str_EQ == local_008)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_003,
                                        [0]),
                                    local_006,
                                    param_1_1,
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_003,
                                        [3]),
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_003,
                                        [4])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_GT == local_008)
            {
                return
                    Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [0]),
                        local_006,
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [2]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [3]),
                        Global_Anonymous.zzz_anon_ea679199_b65beb0f(
                            param_1_0,
                            param_1_1,
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_003,
                                [4])));
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_ed3d09ec_0c02dd8c(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_BlobValue,
                    Pine_PineValue.List(
                        [
                            Global_Anonymous.zzz_anon_368f36cc_8a4785c3(param_1_0)
                        ])
                ]);
    }


    public static Pine_PineValue zzz_anon_f164dec2_b6de04bb(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_param_1_0,
                    [1, 3]);

            if ((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_param_1_0,
                [0])))
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        local_000;

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine_PineValue zzz_anon_f1cd4f95_0d2b56f6(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_2, argument: local_param_1_1);

            if (local_000 == CommonReusedValues.Blob_Char_digit_0)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0);

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_1)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            1,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_2)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            2,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_3)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            3,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_4)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            4,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_5)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            5,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_6)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            6,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_7)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            7,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_8)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            8,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_9)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            9,
                            Pine_KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [local_param_1_0])
                            ]),
                        local_param_1_2
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_f1f1da9a_dda26649(Pine_PineValue param_1_0)
    {
        return Global_Anonymous.zzz_anon_d7dea71a_fd2dcdca(param_1_0, Pine_PineValue.EmptyList);
    }


    public static Pine_PineValue zzz_anon_f3d6dba5_22efcada(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if (((CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (2 == Pine_KernelFunctionSpecialized.length_as_int(local_000))) && (CommonReusedValues.Blob_Str_ListValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_002 =
                Pine.intFromValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [0]));

            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [0]);

            if (CommonReusedValues.Blob_Str_Ok == local_003)
            {
                Pine_PineValue local_004 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1, 0]);

                Pine_PineValue local_005 =
                    Basics.idiv(local_004, CommonReusedValues.Blob_Int_8);

                Pine_PineValue local_006 =
                    Global_Anonymous.zzz_anon_610ee3fc_622604de(Pine_PineValue.EmptyList, local_005, CommonReusedValues.Blob_Int_0);

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionSpecialized.concat(
                                        Global_Anonymous.zzz_anon_9f1a9bb1_3c85cbf2(
                                            Pine_PineValue.EmptyList,
                                            Pine_KernelFunctionSpecialized.concat(
                                                Pine_KernelFunction.reverse(
                                                    Pine_KernelFunctionSpecialized.skip(
                                                        local_005,
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            local_001,
                                                            [1, 0]))),
                                                local_006),
                                            CommonReusedValues.Blob_Int_0,
                                            Pine_KernelFunctionSpecialized.int_add(
                                                local_004,
                                                Pine_KernelFunctionSpecialized.int_mul(
                                                    Pine_IntegerEncoding.EncodeSignedInteger(-1),
                                                    local_005,
                                                    8))),
                                        local_006)
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Err == local_003)
            {
                return CommonReusedValues.List_1f3f2fca;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return CommonReusedValues.List_1f3f2fca;
    }


    public static Pine_PineValue zzz_anon_f8cc3fb0_cbcb2ff6(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionSpecialized.int_mul(16, local_param_1_1);

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_000, local_param_1_0))
            {
                Pine_PineValue local_001 =
                    Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(local_param_1_0, local_000, CommonReusedValues.Blob_Int_0);

                return
                    Pine_KernelFunctionSpecialized.int_add(
                        Pine_KernelFunctionSpecialized.int_mul(16, local_001),
                        Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(
                            Pine_KernelFunctionSpecialized.int_add(
                                local_param_1_0,
                                Pine_KernelFunctionSpecialized.int_mul(local_001, local_000, -1)),
                            local_param_1_1,
                            CommonReusedValues.Blob_Int_0));
            }

            if (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_1, local_param_1_0))
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            local_param_1_0,
                            Pine_KernelFunctionSpecialized.int_mul(-1, local_param_1_1));

                    Pine_PineValue local_param_1_2_temp =
                        Pine_KernelFunctionSpecialized.int_add(1, local_param_1_2);

                    local_param_1_0 =
                        local_param_1_0_temp;

                    local_param_1_2 =
                        local_param_1_2_temp;
                }

                continue;
            }

            return local_param_1_2;
        }
    }


    public static Pine_PineValue zzz_anon_f993b96d_69cecf0f(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        return
            Basics.add(
                param_1_0,
                BigInt.negate(param_1_1));
    }


    public static Pine_PineValue zzz_anon_f9abafe1_f31f3b62(Pine_PineValue param_1_0)
    {
        return Global_Anonymous.zzz_anon_85977333_62796127(CommonReusedValues.Blob_Int_0, param_1_0);
    }


    public static Pine_PineValue zzz_anon_fa4fc55c_2f3c7b11(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_PineValue local_002 =
            Global_Anonymous.zzz_anon_a418ab23_4792582f(param_1_1, param_1_2);

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]);

        Pine_PineValue local_004 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [0]);

        if (CommonReusedValues.Blob_Str_Err == local_004)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Err,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_003,
                                            [1, 0])
                                    ])
                            ]),
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_002,
                            [1])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Ok == local_004)
        {
            Pine_PineValue local_008 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [1]);

            Pine_PineValue local_011 =
                Json.Decode.skipWhitespace(param_1_1, local_008);

            Pine_PineValue local_012 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_011, argument: param_1_1);

            if (Pine_KernelFunctionSpecialized.length_as_int(local_012) == 0)
            {
                return
                    Pine_PineValue.List(
                        [CommonReusedValues.List_0c9ef708, local_011]);
            }

            if (local_012 == CommonReusedValues.Blob_Char_comma)
            {
                Pine_PineValue local_013 =
                    Pine_KernelFunctionFused.ListAppendItem(
                        prefix: param_1_0,
                        itemToAppend:
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_003,
                            [1, 0]));

                return
                    Global_Anonymous.zzz_anon_fa4fc55c_7edd4fd7(
                        local_013,
                        param_1_1,
                        Pine_KernelFunctionSpecialized.int_add(4, local_011));
            }

            if (local_012 == CommonReusedValues.Blob_Char_bracketclose)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Ok,
                                    Pine_PineValue.List(
                                        [
                                            Pine_KernelFunctionFused.ListAppendItem(
                                                prefix: param_1_0,
                                                itemToAppend:
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [1, 0]))
                                        ])
                                ]),
                            Pine_KernelFunctionSpecialized.int_add(4, local_011)
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Err,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValue.List(
                                            [
                                                CommonReusedValues.Blob_Str_String,
                                                Pine_PineValue.List(
                                                    [
                                                        Pine_KernelFunction.concat(
                                                            Pine_PineValue.List(
                                                                [CommonReusedValues.Blob_56dbf05d, local_012, CommonReusedValues.Blob_Char_quote]))
                                                    ])
                                            ])
                                    ])
                            ]),
                        local_011
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue zzz_anon_fa4fc55c_7edd4fd7(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1,
        Pine_PineValue param_1_2)
    {
        Pine_ImmutableConcatBuilder local_param_1_0 =
            Pine_ImmutableConcatBuilder.Create(
                [param_1_0]);

        Pine_PineValue local_param_1_1 =
            param_1_1;

        Pine_PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine_PineValue local_002 =
                Global_Anonymous.zzz_anon_a418ab23_4792582f(local_param_1_1, local_param_1_2);

            Pine_PineValue local_003 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_002,
                    [0]);

            Pine_PineValue local_004 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0]);

            if (CommonReusedValues.Blob_Str_Err == local_004)
            {
                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_003,
                                                [1, 0])
                                        ])
                                ]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_002,
                                [1])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Ok == local_004)
            {
                Pine_PineValue local_008 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1]);

                Pine_PineValue local_011 =
                    Json.Decode.skipWhitespace(local_param_1_1, local_008);

                Pine_PineValue local_012 =
                    Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_011, argument: local_param_1_1);

                if (Pine_KernelFunctionSpecialized.length_as_int(local_012) == 0)
                {
                    return
                        Pine_PineValue.List(
                            [CommonReusedValues.List_0c9ef708, local_011]);
                }

                if (local_012 == CommonReusedValues.Blob_Char_comma)
                {
                    {
                        Pine_PineValue local_param_1_2_temp =
                            Pine_KernelFunctionSpecialized.int_add(4, local_011);

                        local_param_1_0 =
                            local_param_1_0.AppendItems(
                                [
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_003,
                                                [1, 0])
                                        ])
                                ]);

                        local_param_1_2 =
                            local_param_1_2_temp;
                    }

                    continue;
                }

                if (local_012 == CommonReusedValues.Blob_Char_bracketclose)
                {
                    return
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_Ok,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunctionFused.ListAppendItem(
                                                    prefix:
                                                    local_param_1_0.Evaluate(),
                                                    itemToAppend:
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_003,
                                                        [1, 0]))
                                            ])
                                    ]),
                                Pine_KernelFunctionSpecialized.int_add(4, local_011)
                            ]);
                }

                return
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_Err,
                                    Pine_PineValue.List(
                                        [
                                            Pine_PineValue.List(
                                                [
                                                    CommonReusedValues.Blob_Str_String,
                                                    Pine_PineValue.List(
                                                        [
                                                            Pine_KernelFunction.concat(
                                                                Pine_PineValue.List(
                                                                    [CommonReusedValues.Blob_56dbf05d, local_012, CommonReusedValues.Blob_Char_quote]))
                                                        ])
                                                ])
                                        ])
                                ]),
                            local_011
                        ]);
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue zzz_anon_fcb519b2_37c5864a(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionSpecialized.int_mul(
                    4,
                    Pine_IntegerEncoding.EncodeSignedInteger(
                        Pine_KernelFunctionSpecialized.length_as_int(local_param_1_0)));

            Pine_PineValue local_001 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_000, argument: local_param_1_1);

            if (local_001 == Pine_PineValue.EmptyList)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunction.concat(
                                                        Pine_KernelFunction.reverse(local_param_1_0))
                                                ])
                                        ])
                                ])
                        ]);
            }

            Pine_PineValue local_002 =
                Pine_IntegerEncoding.EncodeSignedInteger(
                    Pine_KernelFunctionSpecialized.length_as_int(local_001));

            if (CommonReusedValues.Blob_Int_4 == local_002)
            {
                {
                    Pine_PineValue local_param_1_0_temp =
                        Pine_KernelFunctionFused.ListPrependItem(
                            itemToPrepend:
                            Pine_KernelFunction.reverse(
                                Pine_KernelFunctionSpecialized.take(
                                    4,
                                    Pine_KernelFunctionSpecialized.concat(
                                        Pine_KernelFunction.reverse(
                                            Pine_KernelFunctionSpecialized.skip(
                                                1,
                                                Pine_KernelFunction.int_add(
                                                    Pine_PineValue.List(
                                                        [
                                                            Basics.mul(
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_001,
                                                                    [0]),
                                                                CommonReusedValues.Blob_Int_16777216),
                                                            Basics.mul(
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_001,
                                                                    [1]),
                                                                CommonReusedValues.Blob_Int_65536),
                                                            Basics.mul(
                                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_001,
                                                                    [2]),
                                                                CommonReusedValues.Blob_Int_256),
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_001,
                                                                [3])
                                                        ])))),
                                        CommonReusedValues.Blob_e429d1a2))),
                            suffix: local_param_1_0);

                    local_param_1_0 =
                        local_param_1_0_temp;
                }

                continue;
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunction.concat(
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_b0f3672d,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                String.fromInt(local_000),
                                                                [1, 0]),
                                                            CommonReusedValues.Blob_19541d83,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                String.fromInt(local_002),
                                                                [1, 0]),
                                                            CommonReusedValues.Blob_459693c6
                                                        ]))
                                            ])
                                    ])
                            ])
                    ]);
        }
    }


    public static Pine_PineValue zzz_anon_fe575105_eb1f9043(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine_PineValue local_001 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [3]);

        if ((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (CommonReusedValues.Blob_Str_Black == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0, 0]))
            {
                Pine_PineValue local_003 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [3]);

                if ((CommonReusedValues.Blob_Str_Red == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0])))
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                Pine_PineValue.List(
                                    [
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [0]),
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [1]),
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [2]),
                                        Global_Anonymous.zzz_anon_fe575105_eb1f9043(local_001),
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [4])
                                    ])
                            ]);
                }

                Pine_PineValue local_004 =
                    Global_Anonymous.zzz_anon_59345918_dda26649(param_1_0);

                Pine_PineValue local_005 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [0]);

                if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_005)
                {
                    Pine_PineValue local_006 =
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [1]);

                    return
                        Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [0]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [2]),
                            Global_Anonymous.zzz_anon_fe575105_eb1f9043(
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_006,
                                    [3])),
                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [4]));
                }

                if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_005)
                {
                    return CommonReusedValues.List_71a3df23;
                }

                throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine_PineValue.List(
                            [
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [0]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1]),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [2]),
                                Global_Anonymous.zzz_anon_fe575105_eb1f9043(local_001),
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [4])
                            ])
                    ]);
        }

        return CommonReusedValues.List_71a3df23;
    }
}
