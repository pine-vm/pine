namespace PrecompiledPineToDotNet;

public static class String
{
    public static Pine.Core.PineValue fromInt(Pine.Core.PineValue param_1_0)
    {
        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.KernelFunction.concat(
                                Global_Anonymous.zzz_anon_0f6e756a_a4f70149(param_1_0))
                        ])
                ]);
    }


    public static Pine.Core.PineValue padLeft(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_2,
                [1, 0]);

        Pine.Core.PineValue local_001 =
            Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                param_1_0,
                Pine.Core.Internal.KernelFunctionSpecialized.int_mul(
                    -1,
                    Pine.Core.Internal.KernelFunctionSpecialized.concat(
                        Pine.Core.KernelFunction.ValueFromBool(true),
                        Pine.Core.Internal.KernelFunctionSpecialized.bit_shift_right(
                            2,
                            Pine.Core.Internal.KernelFunctionSpecialized.skip(
                                1,
                                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(
                                    Pine.Core.Internal.KernelFunctionSpecialized.length_as_int(local_000)))))));

        if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_001, 0))
        {
            return param_1_2;
        }

        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.Internal.KernelFunctionSpecialized.concat(
                                Pine.Core.KernelFunction.concat(
                                    Global_Anonymous.zzz_anon_610ee3fc_622604de(Pine.Core.PineValue.EmptyList, local_001, param_1_1)),
                                local_000)
                        ])
                ]);
    }


    public static Pine.Core.PineValue toInt(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.Internal.KernelFunctionSpecialized.take(4, param_1_0);

        if (local_000 == CommonReusedValues.Blob_Char_hyphen)
        {
            Pine.Core.PineValue local_001 =
                Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_4);

            Pine.Core.PineValue local_002 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (CommonReusedValues.Blob_Str_Just == local_002)
            {
                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Just,
                            Pine.Core.PineValue.List(
                                [
                                    Pine.Core.Internal.KernelFunctionSpecialized.int_mul(
                                        -1,
                                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                            local_001,
                                            [1, 0]))
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Nothing == local_002)
            {
                return CommonReusedValues.List_13731c89;
            }

            throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        if (local_000 == CommonReusedValues.Blob_Char_plus)
        {
            return Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_4);
        }

        return Global_Anonymous.zzz_anon_1aac970b_200123d4(param_1_0, CommonReusedValues.Blob_Int_0);
    }


    public static Pine.Core.PineValue trim(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.Internal.KernelFunctionFused.TakeAndSkip(
                                skipCountValue:
                                Global_Anonymous.zzz_anon_449d95bc_da6f86d5(CommonReusedValues.Blob_Int_0, local_000),
                                takeCountValue:
                                Global_Anonymous.zzz_anon_627f403e_dca18c16(
                                    Pine.Core.KernelFunction.length(local_000),
                                    local_000),
                                argument: local_000)
                        ])
                ]);
    }


    public static Pine.Core.PineValue trimLeft(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.Internal.KernelFunctionSpecialized.skip(
                                Global_Anonymous.zzz_anon_449d95bc_da6f86d5(CommonReusedValues.Blob_Int_0, local_000),
                                local_000)
                        ])
                ]);
    }


    public static Pine.Core.PineValue trimRight(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_String,
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.Internal.KernelFunctionSpecialized.take(
                                Global_Anonymous.zzz_anon_627f403e_dca18c16(
                                    Pine.Core.KernelFunction.length(local_000),
                                    local_000),
                                local_000)
                        ])
                ]);
    }
}
