namespace PrecompiledPineToDotNet;

public static class Global_Anonymous
{
    public static Pine.Core.PineValue zzz_anon_0da2f7ed_200123d4(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        Pine.Core.PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine.Core.PineValue local_000 =
                Pine.Core.Internal.KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_2, argument: local_param_1_1);

            if (Pine.Core.Internal.KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Just,
                            Pine.Core.PineValue.List(
                                [local_param_1_0])
                        ]);
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_0)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0);

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_1)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        1,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_2)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        2,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_3)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        3,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_4)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        4,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_5)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        5,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_6)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        6,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_7)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        7,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_8)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        8,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_digit_9)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        9,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(10, local_param_1_0));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            return CommonReusedValues.List_13731c89;
        }
    }


    public static Pine.Core.PineValue zzz_anon_0f6e756a_a4f70149(Pine.Core.PineValue param_1_0)
    {
        if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0))
        {
            return Global_Anonymous.zzz_anon_12af8dcc_650df00b(param_1_0);
        }

        return
            Pine.Core.Internal.KernelFunctionSpecialized.concat(
                CommonReusedValues.List_Single_Blob_Char_hyphen,
                Global_Anonymous.zzz_anon_12af8dcc_650df00b(
                    Pine.Core.KernelFunction.negate(param_1_0)));
    }


    public static Pine.Core.PineValue zzz_anon_12af8dcc_650df00b(Pine.Core.PineValue param_1_0)
    {
        return Global_Anonymous.zzz_anon_632693ae_2f148225(param_1_0, Pine.Core.PineValue.EmptyList);
    }


    public static Pine.Core.PineValue zzz_anon_1aac970b_200123d4(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.Internal.KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: param_1_1, argument: param_1_0);

        if (local_000 == CommonReusedValues.Blob_Char_digit_0)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_0,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_1)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_1,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_2)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_2,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_3)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_3,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_4)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_4,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_5)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_5,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_6)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_6,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_7)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_7,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_8)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_8,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        if (local_000 == CommonReusedValues.Blob_Char_digit_9)
        {
            return
                Global_Anonymous.zzz_anon_0da2f7ed_200123d4(
                    CommonReusedValues.Blob_Int_9,
                    param_1_0,
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, param_1_1));
        }

        return CommonReusedValues.List_13731c89;
    }


    public static Pine.Core.PineValue zzz_anon_39fa68f8_2402eeb0(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        while (true)
        {
            if (local_param_1_0 == CommonReusedValues.Blob_Int_0)
            {
                return CommonReusedValues.Blob_Char_digit_0;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_1)
            {
                return CommonReusedValues.Blob_Char_digit_1;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_2)
            {
                return CommonReusedValues.Blob_Char_digit_2;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_3)
            {
                return CommonReusedValues.Blob_Char_digit_3;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_4)
            {
                return CommonReusedValues.Blob_Char_digit_4;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_5)
            {
                return CommonReusedValues.Blob_Char_digit_5;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_6)
            {
                return CommonReusedValues.Blob_Char_digit_6;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_7)
            {
                return CommonReusedValues.Blob_Char_digit_7;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_8)
            {
                return CommonReusedValues.Blob_Char_digit_8;
            }

            if (local_param_1_0 == CommonReusedValues.Blob_Int_9)
            {
                return CommonReusedValues.Blob_Char_digit_9;
            }

            continue;
        }
    }


    public static Pine.Core.PineValue zzz_anon_3c873ec4_dda26649(Pine.Core.PineValue param_1_0)
    {
        return
            Pine.Core.Internal.KernelFunctionSpecialized.equal(
                Pine.Core.Internal.KernelFunctionSpecialized.take(0, param_1_0),
                Pine.Core.PineValue.EmptyBlob);
    }


    public static Pine.Core.PineValue zzz_anon_449d95bc_da6f86d5(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine.Core.PineValue local_000 =
                Pine.Core.Internal.KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_0, argument: local_param_1_1);

            if (Pine.Core.Internal.KernelFunctionSpecialized.length_as_int(local_000) == 0)
            {
                return local_param_1_0;
            }

            if (Global_Anonymous.zzz_anon_d97a2014_dda26649(local_000) == Pine.Core.PineVM.PineKernelValues.TrueValue)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(4, local_param_1_0);

                local_param_1_0 =
                    local_param_1_0_temp;

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine.Core.PineValue zzz_anon_59345918_dda26649(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [4]);

        Pine.Core.PineValue local_002 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [1]);

        Pine.Core.PineValue local_003 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [3]);

        Pine.Core.PineValue local_004 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [1]);

        if (((((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_004,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_003,
            [0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine.Core.PineValue local_005 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [3, 1]);

            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_004,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_004,
                                    [2]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [1]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [2]),
                                                Pine.Core.PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                                        Pine.Core.PineValue.List(
                                                            [
                                                                CommonReusedValues.List_dafb9d35,
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [1]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [2]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [3]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_005,
                                                                    [4])
                                                            ])
                                                    ]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [3])
                                            ])
                                    ]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [1]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [2]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [4]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [4])
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine.Core.PineValue local_006 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]);

            Pine.Core.PineValue local_007 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Black == local_007)
            {
                Pine.Core.PineValue local_008 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [4])
                                                ])
                                        ]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [2]),
                                                    local_003,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Red == local_007)
            {
                Pine.Core.PineValue local_009 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [4])
                                                ])
                                        ]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [2]),
                                                    local_003,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_002,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return param_1_0;
    }


    public static Pine.Core.PineValue zzz_anon_610ee3fc_622604de(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        Pine.Core.PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_1, 0))
            {
                return local_param_1_0;
            }

            Pine.Core.PineValue local_param_1_0_temp =
                List.cons(local_param_1_2, local_param_1_0);

            Pine.Core.PineValue local_param_1_1_temp =
                Pine.Core.Internal.KernelFunctionSpecialized.int_add(-1, local_param_1_1);

            local_param_1_0 =
                local_param_1_0_temp;

            local_param_1_1 =
                local_param_1_1_temp;

            continue;
        }
    }


    public static Pine.Core.PineValue zzz_anon_627f403e_dca18c16(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0 == CommonReusedValues.Blob_Int_0)
            {
                return CommonReusedValues.Blob_Int_0;
            }

            Pine.Core.PineValue local_000 =
                Pine.Core.PineValue.List(
                    [
                        Pine.Core.Internal.KernelFunctionSpecialized.int_add(-4, local_param_1_0),
                        local_param_1_1
                    ]);

            if (Global_Anonymous.zzz_anon_d97a2014_dda26649(
                Pine.Core.Internal.KernelFunctionFused.SkipAndTake(
                    takeCount: 4,
                    skipCountValue:
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(-4, local_param_1_0),
                    argument: local_param_1_1)) == Pine.Core.PineVM.PineKernelValues.TrueValue)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(-4, local_param_1_0);

                local_param_1_0 =
                    local_param_1_0_temp;

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine.Core.PineValue zzz_anon_632693ae_2f148225(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_0, 0))
            {
                if (local_param_1_1 == Pine.Core.PineValue.EmptyList)
                {
                    return CommonReusedValues.List_Single_Blob_Char_digit_0;
                }

                return local_param_1_1;
            }

            Pine.Core.PineValue local_000 =
                Basics.idiv(local_param_1_0, CommonReusedValues.Blob_Int_10);

            Pine.Core.PineValue local_param_1_0_temp =
                local_000;

            Pine.Core.PineValue local_param_1_1_temp =
                Pine.Core.Internal.KernelFunctionSpecialized.concat(
                    Pine.Core.PineValue.List(
                        [
                            Global_Anonymous.zzz_anon_39fa68f8_2402eeb0(
                                Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                                    local_param_1_0,
                                    Pine.Core.Internal.KernelFunctionSpecialized.int_mul(-10, local_000)))
                        ]),
                    local_param_1_1);

            local_param_1_0 =
                local_param_1_0_temp;

            local_param_1_1 =
                local_param_1_1_temp;

            continue;
        }
    }


    public static Pine.Core.PineValue zzz_anon_7dd973c9_1b8db7d8(
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2,
        Pine.Core.PineValue param_1_3,
        Pine.Core.PineValue param_1_4,
        Pine.Core.PineValue param_1_5,
        Pine.Core.PineValue param_1_6)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_5,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_5,
            [0])))
        {
            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                param_1_2,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [2]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [3]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_dafb9d35,
                                                param_1_3,
                                                param_1_4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [4]),
                                                param_1_6
                                            ])
                                    ])
                            ])
                    ]);
        }

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_6,
                [1]);

        Pine.Core.PineValue local_002 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [3]);

        if ((((CommonReusedValues.Blob_Str_Black == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0]))) && (CommonReusedValues.Blob_Str_Black == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_6,
            [0])))
        {
            return Global_Anonymous.zzz_anon_c051d150_dda26649(param_1_1);
        }

        if (((CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0])) && (CommonReusedValues.Blob_Str_Black == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_6,
            [0])))
        {
            return Global_Anonymous.zzz_anon_c051d150_dda26649(param_1_1);
        }

        return param_1_1;
    }


    public static Pine.Core.PineValue zzz_anon_9a7c1e1b_386942a1(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_1,
                [0]);

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            Pine.Core.PineValue local_002 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (Basics.eq(param_1_0, local_002) == Pine.Core.PineVM.PineKernelValues.TrueValue)
            {
                Pine.Core.PineValue local_003 =
                    Pine.Core.PineValue.List(
                        [
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [4])
                        ]);

                Pine.Core.PineValue local_004 =
                    Global_Anonymous.zzz_anon_f164dec2_b6de04bb(
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4]));

                Pine.Core.PineValue local_005 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [0]);

                if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_005)
                {
                    Pine.Core.PineValue local_006 =
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [1]);

                    return
                        Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [0]),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [2]),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [3]),
                            Global_Anonymous.zzz_anon_fe575105_eb1f9043(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])));
                }

                if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_005)
                {
                    return CommonReusedValues.List_71a3df23;
                }

                throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [0]),
                    local_002,
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [2]),
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [3]),
                    Global_Anonymous.zzz_anon_ac3e6060_386942a1(
                        param_1_0,
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4])));
        }

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return CommonReusedValues.List_71a3df23;
        }

        throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine.Core.PineValue zzz_anon_ac3e6060_386942a1(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_1,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return CommonReusedValues.List_71a3df23;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_1,
                    [1]);

            Pine.Core.PineValue local_002 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (Basics.lt(param_1_0, local_002) == Pine.Core.PineVM.PineKernelValues.TrueValue)
            {
                Pine.Core.PineValue local_003 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [3]);

                Pine.Core.PineValue local_004 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_003,
                        [1]);

                if ((CommonReusedValues.Blob_Str_Black == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_004,
                    [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0])))
                {
                    Pine.Core.PineValue local_005 =
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [3]);

                    if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_005,
                        [0])))
                    {
                        return
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                    Pine.Core.PineValue.List(
                                        [
                                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [0]),
                                            local_002,
                                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [2]),
                                            Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, local_003),
                                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [4])
                                        ])
                                ]);
                    }

                    Pine.Core.PineValue local_006 =
                        Global_Anonymous.zzz_anon_59345918_dda26649(param_1_1);

                    Pine.Core.PineValue local_007 =
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_006,
                            [0]);

                    if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_007)
                    {
                        Pine.Core.PineValue local_008 =
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]);

                        return
                            Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [0]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [2]),
                                Global_Anonymous.zzz_anon_ac3e6060_386942a1(
                                    param_1_0,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_008,
                                        [3])),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_008,
                                    [4]));
                    }

                    if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_007)
                    {
                        return CommonReusedValues.List_71a3df23;
                    }

                    throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
                }

                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [0]),
                                    local_002,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [2]),
                                    Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, local_003),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [4])
                                ])
                        ]);
            }

            return
                Global_Anonymous.zzz_anon_9a7c1e1b_386942a1(
                    param_1_0,
                    Global_Anonymous.zzz_anon_7dd973c9_1b8db7d8(
                        param_1_1,
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [0]),
                        local_002,
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [2]),
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [3]),
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4])));
        }

        throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine.Core.PineValue zzz_anon_c051d150_dda26649(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [4]);

        Pine.Core.PineValue local_002 =
            Pine.Core.KernelFunction.ValueFromBool(
                CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]));

        if (((((local_002 == Pine.Core.PineVM.PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 1, 3, 1, 0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 1, 3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine.Core.PineValue local_003 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [3, 1]);

            Pine.Core.PineValue local_004 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            Pine.Core.PineValue local_005 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [3, 1]);

            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_003,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_003,
                                    [2]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [1]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [2]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [3]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_005,
                                                    [4])
                                            ])
                                    ]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [1]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [2]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_003,
                                                    [4]),
                                                Pine.Core.PineValue.List(
                                                    [
                                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                                        Pine.Core.PineValue.List(
                                                            [
                                                                CommonReusedValues.List_dafb9d35,
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [1]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [2]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [3]),
                                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                                    local_004,
                                                                    [4])
                                                            ])
                                                    ])
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (((local_002 == Pine.Core.PineVM.PineKernelValues.TrueValue) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [3, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine.Core.PineValue local_006 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_000,
                    [0]);

            Pine.Core.PineValue local_007 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_006,
                    [0]);

            if (CommonReusedValues.Blob_Str_Black == local_007)
            {
                Pine.Core.PineValue local_008 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                Pine.Core.PineValue local_009 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1]);

                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_008,
                                                        [4])
                                                ])
                                        ]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_009,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_Red == local_007)
            {
                Pine.Core.PineValue local_010 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_000,
                        [3, 1]);

                Pine.Core.PineValue local_011 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1]);

                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.List_7222f8d4,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [1]),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_000,
                                        [2]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_010,
                                                        [4])
                                                ])
                                        ]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_dafb9d35,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_011,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        return param_1_0;
    }


    public static Pine.Core.PineValue zzz_anon_c78b4c00_dda26649(Pine.Core.PineValue param_1_0)
    {
        return
            Pine.Core.Internal.KernelFunctionSpecialized.equal(
                Pine.Core.Internal.KernelFunctionSpecialized.take(0, param_1_0),
                Pine.Core.PineValue.EmptyList);
    }


    public static Pine.Core.PineValue zzz_anon_d97a2014_dda26649(Pine.Core.PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.Blob_Char_space)
        {
            return Pine.Core.PineVM.PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_tab)
        {
            return Pine.Core.PineVM.PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_newline)
        {
            return Pine.Core.PineVM.PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_carriagereturn)
        {
            return Pine.Core.PineVM.PineKernelValues.TrueValue;
        }

        if (param_1_0 == CommonReusedValues.Blob_Char_nobreakspace)
        {
            return Pine.Core.PineVM.PineKernelValues.TrueValue;
        }

        return Pine.Core.PineVM.PineKernelValues.FalseValue;
    }


    public static Pine.Core.PineValue zzz_anon_dd880f82_13e5e91e(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0 == Pine.Core.PineValue.EmptyList)
            {
                return Pine.Core.PineVM.PineKernelValues.TrueValue;
            }

            if (Basics.eq(
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_param_1_0,
                    [0]),
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_param_1_1,
                    [0])) == Pine.Core.PineVM.PineKernelValues.TrueValue)
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.skip(1, local_param_1_0);

                Pine.Core.PineValue local_param_1_1_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.skip(1, local_param_1_1);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_1 =
                    local_param_1_1_temp;

                continue;
            }

            return Pine.Core.PineVM.PineKernelValues.FalseValue;
        }
    }


    public static Pine.Core.PineValue zzz_anon_e6d15ff4_dda26649(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2,
        Pine.Core.PineValue param_1_3,
        Pine.Core.PineValue param_1_4)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_4,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_4,
            [0])))
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_3,
                    [1]);

            if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_3,
                [0])))
            {
                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    CommonReusedValues.List_dafb9d35,
                                    param_1_1,
                                    param_1_2,
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_7222f8d4,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_001,
                                                        [4])
                                                ])
                                        ]),
                                    Pine.Core.PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                            Pine.Core.PineValue.List(
                                                [
                                                    CommonReusedValues.List_7222f8d4,
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_000,
                                                        [1]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_000,
                                                        [2]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_000,
                                                        [3]),
                                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                        local_000,
                                                        [4])
                                                ])
                                        ])
                                ])
                        ]);
            }

            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                param_1_0,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [2]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_dafb9d35,
                                                param_1_1,
                                                param_1_2,
                                                param_1_3,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_000,
                                                    [3])
                                            ])
                                    ]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [4])
                            ])
                    ]);
        }

        Pine.Core.PineValue local_002 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_3,
                [1]);

        Pine.Core.PineValue local_003 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [3]);

        Pine.Core.PineValue local_004 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_003,
                [1]);

        if ((((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_004,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_003,
            [0]))) && (CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_002,
            [0, 0]))) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_3,
            [0])))
        {
            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.List_dafb9d35,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_002,
                                    [2]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [1]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [2]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [3]),
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_004,
                                                    [4])
                                            ])
                                    ]),
                                Pine.Core.PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                        Pine.Core.PineValue.List(
                                            [
                                                CommonReusedValues.List_7222f8d4,
                                                param_1_1,
                                                param_1_2,
                                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_002,
                                                    [4]),
                                                param_1_4
                                            ])
                                    ])
                            ])
                    ]);
        }

        return
            Pine.Core.PineValue.List(
                [
                    CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                    Pine.Core.PineValue.List(
                        [param_1_0, param_1_1, param_1_2, param_1_3, param_1_4])
                ]);
    }


    public static Pine.Core.PineValue zzz_anon_ea679199_b65beb0f(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_2,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [CommonReusedValues.List_dafb9d35, param_1_0, param_1_1, CommonReusedValues.List_71a3df23, CommonReusedValues.List_71a3df23])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_2,
                    [1]);

            Pine.Core.PineValue local_002 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            Pine.Core.PineValue local_003 =
                Basics.compare(param_1_0, local_002);

            Pine.Core.PineValue local_004 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0]);

            if (CommonReusedValues.Blob_Str_LT == local_004)
            {
                return
                    Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [0]),
                        local_002,
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [2]),
                        Global_Anonymous.zzz_anon_ea679199_b65beb0f(
                            param_1_0,
                            param_1_1,
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [3])),
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [4]));
            }

            if (CommonReusedValues.Blob_Str_EQ == local_004)
            {
                return
                    Pine.Core.PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                            Pine.Core.PineValue.List(
                                [
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [0]),
                                    local_002,
                                    param_1_1,
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [3]),
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [4])
                                ])
                        ]);
            }

            if (CommonReusedValues.Blob_Str_GT == local_004)
            {
                return
                    Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [0]),
                        local_002,
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [2]),
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_001,
                            [3]),
                        Global_Anonymous.zzz_anon_ea679199_b65beb0f(
                            param_1_0,
                            param_1_1,
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_001,
                                [4])));
            }

            throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }

        throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine.Core.PineValue zzz_anon_f164dec2_b6de04bb(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        while (true)
        {
            Pine.Core.PineValue local_000 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_param_1_0,
                    [1, 3]);

            if ((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_param_1_0,
                [0])))
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    local_000;

                local_param_1_0 =
                    local_param_1_0_temp;

                continue;
            }

            return local_param_1_0;
        }
    }


    public static Pine.Core.PineValue zzz_anon_f8cc3fb0_cbcb2ff6(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_param_1_0 =
            param_1_0;

        Pine.Core.PineValue local_param_1_1 =
            param_1_1;

        Pine.Core.PineValue local_param_1_2 =
            param_1_2;

        while (true)
        {
            Pine.Core.PineValue local_000 =
                Pine.Core.Internal.KernelFunctionSpecialized.int_mul(16, local_param_1_1);

            if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_000, local_param_1_0))
            {
                Pine.Core.PineValue local_001 =
                    Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(local_param_1_0, local_000, CommonReusedValues.Blob_Int_0);

                return
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(16, local_001),
                        Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(
                            Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                                local_param_1_0,
                                Pine.Core.Internal.KernelFunctionSpecialized.int_mul(local_001, local_000, -1)),
                            local_param_1_1,
                            CommonReusedValues.Blob_Int_0));
            }

            if (Pine.Core.Internal.KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(local_param_1_1, local_param_1_0))
            {
                Pine.Core.PineValue local_param_1_0_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(
                        local_param_1_0,
                        Pine.Core.Internal.KernelFunctionSpecialized.int_mul(-1, local_param_1_1));

                Pine.Core.PineValue local_param_1_2_temp =
                    Pine.Core.Internal.KernelFunctionSpecialized.int_add(1, local_param_1_2);

                local_param_1_0 =
                    local_param_1_0_temp;

                local_param_1_2 =
                    local_param_1_2_temp;

                continue;
            }

            return local_param_1_2;
        }
    }


    public static Pine.Core.PineValue zzz_anon_fe575105_eb1f9043(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1]);

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [3]);

        if ((CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0])))
        {
            Pine.Core.PineValue local_002 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [1]);

            if (CommonReusedValues.Blob_Str_Black == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0, 0]))
            {
                Pine.Core.PineValue local_003 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [3]);

                if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [1, 0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    local_003,
                    [0])))
                {
                    return
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                                Pine.Core.PineValue.List(
                                    [
                                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [0]),
                                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [1]),
                                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [2]),
                                        Global_Anonymous.zzz_anon_fe575105_eb1f9043(local_001),
                                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                            local_000,
                                            [4])
                                    ])
                            ]);
                }

                Pine.Core.PineValue local_004 =
                    Global_Anonymous.zzz_anon_59345918_dda26649(param_1_0);

                Pine.Core.PineValue local_005 =
                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                        local_004,
                        [0]);

                if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_005)
                {
                    Pine.Core.PineValue local_006 =
                        Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                            local_004,
                            [1]);

                    return
                        Global_Anonymous.zzz_anon_e6d15ff4_dda26649(
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [0]),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [1]),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [2]),
                            Global_Anonymous.zzz_anon_fe575105_eb1f9043(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_006,
                                    [3])),
                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                local_006,
                                [4]));
                }

                if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_005)
                {
                    return CommonReusedValues.List_71a3df23;
                }

                throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
            }

            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [0]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [2]),
                                Global_Anonymous.zzz_anon_fe575105_eb1f9043(local_001),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_000,
                                    [4])
                            ])
                    ]);
        }

        return CommonReusedValues.List_71a3df23;
    }
}
