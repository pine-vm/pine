namespace PrecompiledPineToDotNet;

public static class List
{
    public static Pine.Core.PineValue cons(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        return
            Pine.Core.Internal.KernelFunctionSpecialized.concat(
                Pine.Core.PineValue.List(
                    [param_1_0]),
                param_1_1);
    }
}
