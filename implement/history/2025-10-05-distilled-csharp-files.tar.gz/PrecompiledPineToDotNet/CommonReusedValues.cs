namespace PrecompiledPineToDotNet;

public static class CommonReusedValues
{
    public static readonly Pine.Core.PineValue Blob_Int_neg_1 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-1);

    public static readonly Pine.Core.PineValue Blob_Int_neg_4 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-4);

    public static readonly Pine.Core.PineValue Blob_Int_neg_10 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-10);

    public static readonly Pine.Core.PineValue Blob_Int_0 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(0);

    public static readonly Pine.Core.PineValue Blob_Int_1 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(1);

    public static readonly Pine.Core.PineValue Blob_Int_2 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(2);

    public static readonly Pine.Core.PineValue Blob_Int_3 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(3);

    public static readonly Pine.Core.PineValue Blob_Int_4 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(4);

    public static readonly Pine.Core.PineValue Blob_Int_5 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(5);

    public static readonly Pine.Core.PineValue Blob_Int_6 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(6);

    public static readonly Pine.Core.PineValue Blob_Int_7 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(7);

    public static readonly Pine.Core.PineValue Blob_Int_8 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(8);

    public static readonly Pine.Core.PineValue Blob_Int_9 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(9);

    public static readonly Pine.Core.PineValue Blob_Int_10 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(10);

    public static readonly Pine.Core.PineValue Blob_Int_16 =
        Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(16);

    public static readonly Pine.Core.PineValue Blob_Char_tab =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("\t");

    public static readonly Pine.Core.PineValue Blob_Char_newline =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("\n");

    public static readonly Pine.Core.PineValue Blob_Char_carriagereturn =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("\r");

    public static readonly Pine.Core.PineValue Blob_Char_space =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString(" ");

    public static readonly Pine.Core.PineValue Blob_Char_plus =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("+");

    public static readonly Pine.Core.PineValue Blob_Char_hyphen =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("-");

    public static readonly Pine.Core.PineValue Blob_Char_digit_0 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("0");

    public static readonly Pine.Core.PineValue Blob_Char_digit_1 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("1");

    public static readonly Pine.Core.PineValue Blob_Char_digit_2 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("2");

    public static readonly Pine.Core.PineValue Blob_Char_digit_3 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("3");

    public static readonly Pine.Core.PineValue Blob_Char_digit_4 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("4");

    public static readonly Pine.Core.PineValue Blob_Char_digit_5 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("5");

    public static readonly Pine.Core.PineValue Blob_Char_digit_6 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("6");

    public static readonly Pine.Core.PineValue Blob_Char_digit_7 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("7");

    public static readonly Pine.Core.PineValue Blob_Char_digit_8 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("8");

    public static readonly Pine.Core.PineValue Blob_Char_digit_9 =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("9");

    public static readonly Pine.Core.PineValue Blob_Char_nobreakspace =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString(" ");

    public static readonly Pine.Core.PineValue Blob_Str_EQ =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("EQ");

    public static readonly Pine.Core.PineValue Blob_Str_GT =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("GT");

    public static readonly Pine.Core.PineValue Blob_Str_LT =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("LT");

    public static readonly Pine.Core.PineValue Blob_Str_Red =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Red");

    public static readonly Pine.Core.PineValue Blob_Str_Just =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Just");

    public static readonly Pine.Core.PineValue Blob_Str_List =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("List");

    public static readonly Pine.Core.PineValue Blob_Str_head =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("head");

    public static readonly Pine.Core.PineValue Blob_Str_skip =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("skip");

    public static readonly Pine.Core.PineValue Blob_Str_take =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("take");

    public static readonly Pine.Core.PineValue Blob_Str_Black =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Black");

    public static readonly Pine.Core.PineValue Blob_Str_equal =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("equal");

    public static readonly Pine.Core.PineValue Blob_Str_String =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("String");

    public static readonly Pine.Core.PineValue Blob_Str_concat =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("concat");

    public static readonly Pine.Core.PineValue Blob_Str_length =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("length");

    public static readonly Pine.Core.PineValue Blob_Str_negate =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("negate");

    public static readonly Pine.Core.PineValue Blob_Str_Literal =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Literal");

    public static readonly Pine.Core.PineValue Blob_Str_Nothing =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Nothing");

    public static readonly Pine.Core.PineValue Blob_Str_int_add =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("int_add");

    public static readonly Pine.Core.PineValue Blob_Str_int_mul =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("int_mul");

    public static readonly Pine.Core.PineValue Blob_Str_Function =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Function");

    public static readonly Pine.Core.PineValue Blob_Str_Elm_Float =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Elm_Float");

    public static readonly Pine.Core.PineValue Blob_Str_Conditional =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Conditional");

    public static readonly Pine.Core.PineValue Blob_Str_Environment =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Environment");

    public static readonly Pine.Core.PineValue Blob_Str_ParseAndEval =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("ParseAndEval");

    public static readonly Pine.Core.PineValue Blob_Str_Set_elm_builtin =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Set_elm_builtin");

    public static readonly Pine.Core.PineValue Blob_Str_bit_shift_right =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("bit_shift_right");

    public static readonly Pine.Core.PineValue Blob_Str_KernelApplication =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("KernelApplication");

    public static readonly Pine.Core.PineValue Blob_Str_int_is_sorted_asc =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("int_is_sorted_asc");

    public static readonly Pine.Core.PineValue Blob_Str_RBNode_elm_builtin =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("RBNode_elm_builtin");

    public static readonly Pine.Core.PineValue Blob_Str_RBEmpty_elm_builtin =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("RBEmpty_elm_builtin");

    public static readonly Pine.Core.PineValue Blob_d348781a =
        Pine.Core.PopularEncodings.StringEncoding.ValueFromString("Error in case-of block: No matching branch.");

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_ =
        Pine.Core.PineValue.List(
            [Pine.Core.PineValue.EmptyBlob]);

    public static readonly Pine.Core.PineValue List_Single_List_Empty =
        Pine.Core.PineValue.List(
            [Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_Bool_False =
        Pine.Core.PineValue.List(
            [Pine.Core.PineVM.PineKernelValues.FalseValue]);

    public static readonly Pine.Core.PineValue List_Single_Bool_True =
        Pine.Core.PineValue.List(
            [Pine.Core.PineVM.PineKernelValues.TrueValue]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_neg_1 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-1)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_neg_4 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-4)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_neg_10 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(-10)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_0 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(0)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_1 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(1)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_2 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(2)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_3 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(3)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_4 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(4)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_5 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(5)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_6 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(6)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_7 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(7)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_8 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(8)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_9 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(9)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_10 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(10)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Int_16 =
        Pine.Core.PineValue.List(
            [
                Pine.Core.PopularEncodings.IntegerEncoding.EncodeSignedInteger(16)
            ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_tab =
        Pine.Core.PineValue.List(
            [Blob_Char_tab]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_newline =
        Pine.Core.PineValue.List(
            [Blob_Char_newline]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_carriagereturn =
        Pine.Core.PineValue.List(
            [Blob_Char_carriagereturn]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_space =
        Pine.Core.PineValue.List(
            [Blob_Char_space]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_plus =
        Pine.Core.PineValue.List(
            [Blob_Char_plus]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_hyphen =
        Pine.Core.PineValue.List(
            [Blob_Char_hyphen]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_0 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_0]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_1 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_1]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_2 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_2]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_3 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_3]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_4 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_4]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_5 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_5]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_6 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_6]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_7 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_7]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_8 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_8]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_digit_9 =
        Pine.Core.PineValue.List(
            [Blob_Char_digit_9]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Char_nobreakspace =
        Pine.Core.PineValue.List(
            [Blob_Char_nobreakspace]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_Blob_Char_hyphen =
        Pine.Core.PineValue.List(
            [List_Single_Blob_Char_hyphen]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_Blob_Char_digit_0 =
        Pine.Core.PineValue.List(
            [List_Single_Blob_Char_digit_0]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_EQ =
        Pine.Core.PineValue.List(
            [Blob_Str_EQ]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_GT =
        Pine.Core.PineValue.List(
            [Blob_Str_GT]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_LT =
        Pine.Core.PineValue.List(
            [Blob_Str_LT]);

    public static readonly Pine.Core.PineValue List_ac855cb8 =
        Pine.Core.PineValue.List(
            [Blob_Str_EQ, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_50724673 =
        Pine.Core.PineValue.List(
            [Blob_Str_GT, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_af0e3cad =
        Pine.Core.PineValue.List(
            [Blob_Str_LT, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_List_ac855cb8 =
        Pine.Core.PineValue.List(
            [List_ac855cb8]);

    public static readonly Pine.Core.PineValue List_Single_List_50724673 =
        Pine.Core.PineValue.List(
            [List_50724673]);

    public static readonly Pine.Core.PineValue List_Single_List_af0e3cad =
        Pine.Core.PineValue.List(
            [List_af0e3cad]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Red =
        Pine.Core.PineValue.List(
            [Blob_Str_Red]);

    public static readonly Pine.Core.PineValue List_dafb9d35 =
        Pine.Core.PineValue.List(
            [Blob_Str_Red, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_List_dafb9d35 =
        Pine.Core.PineValue.List(
            [List_dafb9d35]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Just =
        Pine.Core.PineValue.List(
            [Blob_Str_Just]);

    public static readonly Pine.Core.PineValue List_3bb3accf =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Empty]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Black =
        Pine.Core.PineValue.List(
            [Blob_Str_Black]);

    public static readonly Pine.Core.PineValue List_7222f8d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Black, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_List_7222f8d4 =
        Pine.Core.PineValue.List(
            [List_7222f8d4]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_String =
        Pine.Core.PineValue.List(
            [Blob_Str_String]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Nothing =
        Pine.Core.PineValue.List(
            [Blob_Str_Nothing]);

    public static readonly Pine.Core.PineValue List_13731c89 =
        Pine.Core.PineValue.List(
            [Blob_Str_Nothing, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_List_13731c89 =
        Pine.Core.PineValue.List(
            [List_13731c89]);

    public static readonly Pine.Core.PineValue List_81e583e7 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_]);

    public static readonly Pine.Core.PineValue List_e190d1f5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_Empty]);

    public static readonly Pine.Core.PineValue List_bb14d771 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Bool_False]);

    public static readonly Pine.Core.PineValue List_d0b6bef5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Bool_True]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Function =
        Pine.Core.PineValue.List(
            [Blob_Str_Function]);

    public static readonly Pine.Core.PineValue List_56404869 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_neg_1]);

    public static readonly Pine.Core.PineValue List_21ca5af5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_neg_4]);

    public static readonly Pine.Core.PineValue List_d2a677f1 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_neg_10]);

    public static readonly Pine.Core.PineValue List_b5d02807 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_0]);

    public static readonly Pine.Core.PineValue List_0dcd86c0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_1]);

    public static readonly Pine.Core.PineValue List_43b95777 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_2]);

    public static readonly Pine.Core.PineValue List_450c12a0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_3]);

    public static readonly Pine.Core.PineValue List_0c82888c =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_4]);

    public static readonly Pine.Core.PineValue List_c1b27e6e =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_5]);

    public static readonly Pine.Core.PineValue List_282dee3a =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_6]);

    public static readonly Pine.Core.PineValue List_9f1e38f9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_7]);

    public static readonly Pine.Core.PineValue List_14a0ba72 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_8]);

    public static readonly Pine.Core.PineValue List_a710c27f =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_9]);

    public static readonly Pine.Core.PineValue List_c41d9105 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_10]);

    public static readonly Pine.Core.PineValue List_6dda98c4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Int_16]);

    public static readonly Pine.Core.PineValue List_aa637125 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_tab]);

    public static readonly Pine.Core.PineValue List_afc7f021 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_newline]);

    public static readonly Pine.Core.PineValue List_0d6ad46e =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_carriagereturn]);

    public static readonly Pine.Core.PineValue List_e29763f2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_space]);

    public static readonly Pine.Core.PineValue List_c48683dd =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_plus]);

    public static readonly Pine.Core.PineValue List_87a2a774 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_hyphen]);

    public static readonly Pine.Core.PineValue List_4c2609c3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_0]);

    public static readonly Pine.Core.PineValue List_c3b08663 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_1]);

    public static readonly Pine.Core.PineValue List_e844984b =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_2]);

    public static readonly Pine.Core.PineValue List_a9196577 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_3]);

    public static readonly Pine.Core.PineValue List_9728f698 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_4]);

    public static readonly Pine.Core.PineValue List_86fad7dd =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_5]);

    public static readonly Pine.Core.PineValue List_c005c994 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_6]);

    public static readonly Pine.Core.PineValue List_33c6f4ad =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_7]);

    public static readonly Pine.Core.PineValue List_1a0b8610 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_8]);

    public static readonly Pine.Core.PineValue List_ecf5f39d =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_digit_9]);

    public static readonly Pine.Core.PineValue List_132b89ac =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Char_nobreakspace]);

    public static readonly Pine.Core.PineValue List_f9782095 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_Single_Blob_Char_hyphen]);

    public static readonly Pine.Core.PineValue List_e1230cbe =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_Single_Blob_Char_digit_0]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Elm_Float =
        Pine.Core.PineValue.List(
            [Blob_Str_Elm_Float]);

    public static readonly Pine.Core.PineValue List_99b8e21f =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_EQ]);

    public static readonly Pine.Core.PineValue List_1adbc696 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_GT]);

    public static readonly Pine.Core.PineValue List_4d678e38 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_LT]);

    public static readonly Pine.Core.PineValue List_45564a6a =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_ac855cb8]);

    public static readonly Pine.Core.PineValue List_2f59fd7a =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_50724673]);

    public static readonly Pine.Core.PineValue List_cd5e9e27 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_af0e3cad]);

    public static readonly Pine.Core.PineValue List_d07a7cd8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Red]);

    public static readonly Pine.Core.PineValue List_121967d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_dafb9d35]);

    public static readonly Pine.Core.PineValue List_bd06385a =
        Pine.Core.PineValue.List(
            [Blob_Str_Environment, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_d816deb1 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Just]);

    public static readonly Pine.Core.PineValue List_887c794a =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Black]);

    public static readonly Pine.Core.PineValue List_38148fc9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_7222f8d4]);

    public static readonly Pine.Core.PineValue List_95a1a4ad =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_String]);

    public static readonly Pine.Core.PineValue List_049cce88 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Nothing]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_Set_elm_builtin =
        Pine.Core.PineValue.List(
            [Blob_Str_Set_elm_builtin]);

    public static readonly Pine.Core.PineValue List_53090eac =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_13731c89]);

    public static readonly Pine.Core.PineValue List_2f1c6993 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Function]);

    public static readonly Pine.Core.PineValue List_4aad0d20 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_bd06385a]);

    public static readonly Pine.Core.PineValue List_ad18d3d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Elm_Float]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_RBNode_elm_builtin =
        Pine.Core.PineValue.List(
            [Blob_Str_RBNode_elm_builtin]);

    public static readonly Pine.Core.PineValue List_Single_Blob_Str_RBEmpty_elm_builtin =
        Pine.Core.PineValue.List(
            [Blob_Str_RBEmpty_elm_builtin]);

    public static readonly Pine.Core.PineValue List_71a3df23 =
        Pine.Core.PineValue.List(
            [Blob_Str_RBEmpty_elm_builtin, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_Single_List_71a3df23 =
        Pine.Core.PineValue.List(
            [List_71a3df23]);

    public static readonly Pine.Core.PineValue List_c1cc00b1 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_bd06385a]);

    public static readonly Pine.Core.PineValue List_71a831bc =
        Pine.Core.PineValue.List(
            [List_43b95777, List_bd06385a]);

    public static readonly Pine.Core.PineValue List_Single_List_c1cc00b1 =
        Pine.Core.PineValue.List(
            [List_c1cc00b1]);

    public static readonly Pine.Core.PineValue List_Single_List_71a831bc =
        Pine.Core.PineValue.List(
            [List_71a831bc]);

    public static readonly Pine.Core.PineValue List_594e965b =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_Set_elm_builtin]);

    public static readonly Pine.Core.PineValue List_4c301747 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c1cc00b1]);

    public static readonly Pine.Core.PineValue List_7ed5803b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_71a831bc]);

    public static readonly Pine.Core.PineValue List_3c66e257 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_RBNode_elm_builtin]);

    public static readonly Pine.Core.PineValue List_f751324e =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_Str_RBEmpty_elm_builtin]);

    public static readonly Pine.Core.PineValue List_27311de8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_71a3df23]);

    public static readonly Pine.Core.PineValue List_b49facc1 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_4c301747]);

    public static readonly Pine.Core.PineValue List_0c396738 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_7ed5803b]);

    public static readonly Pine.Core.PineValue List_a5cbaf18 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4aad0d20]);

    public static readonly Pine.Core.PineValue List_61fa9b59 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_ad7e5b86 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_ad7e5b86 =
        Pine.Core.PineValue.List(
            [List_ad7e5b86]);

    public static readonly Pine.Core.PineValue List_9517421c =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_f5d22246 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_e350b941 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_a28f3c19 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_ce6f52a7 =
        Pine.Core.PineValue.List(
            [List_c1b27e6e, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_75dd3db2 =
        Pine.Core.PineValue.List(
            [List_282dee3a, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_f7dfc6e5 =
        Pine.Core.PineValue.List(
            [List_9f1e38f9, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_8446c16b =
        Pine.Core.PineValue.List(
            [List_14a0ba72, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_6af9ff78 =
        Pine.Core.PineValue.List(
            [List_a710c27f, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_67227150 =
        Pine.Core.PineValue.List(
            [List_c41d9105, List_a5cbaf18]);

    public static readonly Pine.Core.PineValue List_Single_List_9517421c =
        Pine.Core.PineValue.List(
            [List_9517421c]);

    public static readonly Pine.Core.PineValue List_Single_List_f5d22246 =
        Pine.Core.PineValue.List(
            [List_f5d22246]);

    public static readonly Pine.Core.PineValue List_Single_List_e350b941 =
        Pine.Core.PineValue.List(
            [List_e350b941]);

    public static readonly Pine.Core.PineValue List_Single_List_a28f3c19 =
        Pine.Core.PineValue.List(
            [List_a28f3c19]);

    public static readonly Pine.Core.PineValue List_Single_List_ce6f52a7 =
        Pine.Core.PineValue.List(
            [List_ce6f52a7]);

    public static readonly Pine.Core.PineValue List_Single_List_75dd3db2 =
        Pine.Core.PineValue.List(
            [List_75dd3db2]);

    public static readonly Pine.Core.PineValue List_Single_List_f7dfc6e5 =
        Pine.Core.PineValue.List(
            [List_f7dfc6e5]);

    public static readonly Pine.Core.PineValue List_Single_List_8446c16b =
        Pine.Core.PineValue.List(
            [List_8446c16b]);

    public static readonly Pine.Core.PineValue List_Single_List_6af9ff78 =
        Pine.Core.PineValue.List(
            [List_6af9ff78]);

    public static readonly Pine.Core.PineValue List_Single_List_67227150 =
        Pine.Core.PineValue.List(
            [List_67227150]);

    public static readonly Pine.Core.PineValue List_Single_Blob_d348781a =
        Pine.Core.PineValue.List(
            [Blob_d348781a]);

    public static readonly Pine.Core.PineValue List_28767619 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ad7e5b86]);

    public static readonly Pine.Core.PineValue List_94d58849 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9517421c]);

    public static readonly Pine.Core.PineValue List_6a975ff5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f5d22246]);

    public static readonly Pine.Core.PineValue List_7b8c1bfc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e350b941]);

    public static readonly Pine.Core.PineValue List_96e328f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a28f3c19]);

    public static readonly Pine.Core.PineValue List_a4c2d7ab =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ce6f52a7]);

    public static readonly Pine.Core.PineValue List_5a3bfc4d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_75dd3db2]);

    public static readonly Pine.Core.PineValue List_56408778 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f7dfc6e5]);

    public static readonly Pine.Core.PineValue List_2ae850d9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8446c16b]);

    public static readonly Pine.Core.PineValue List_c4bcdd0c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6af9ff78]);

    public static readonly Pine.Core.PineValue List_ce8aa0ee =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_67227150]);

    public static readonly Pine.Core.PineValue List_65405503 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b49facc1]);

    public static readonly Pine.Core.PineValue List_97963d43 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0c396738]);

    public static readonly Pine.Core.PineValue List_db582731 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_Blob_d348781a]);

    public static readonly Pine.Core.PineValue List_7552bdea =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_65405503]);

    public static readonly Pine.Core.PineValue List_391923b1 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_97963d43]);

    public static readonly Pine.Core.PineValue List_f942a019 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_94d58849]);

    public static readonly Pine.Core.PineValue List_0175b775 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_6a975ff5]);

    public static readonly Pine.Core.PineValue List_57e7e72f =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_7b8c1bfc]);

    public static readonly Pine.Core.PineValue List_e175dee1 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_96e328f4]);

    public static readonly Pine.Core.PineValue List_b2076a7a =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a4c2d7ab]);

    public static readonly Pine.Core.PineValue List_e159da15 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_5a3bfc4d]);

    public static readonly Pine.Core.PineValue List_f70cb462 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_56408778]);

    public static readonly Pine.Core.PineValue List_5a8089d9 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_2ae850d9]);

    public static readonly Pine.Core.PineValue List_f1384f10 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c4bcdd0c]);

    public static readonly Pine.Core.PineValue List_00d19808 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_ce8aa0ee]);

    public static readonly Pine.Core.PineValue List_976730e9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_61fa9b59]);

    public static readonly Pine.Core.PineValue List_164af6d8 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_976730e9]);

    public static readonly Pine.Core.PineValue List_Single_List_164af6d8 =
        Pine.Core.PineValue.List(
            [List_164af6d8]);

    public static readonly Pine.Core.PineValue List_2facd5dd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_164af6d8]);

    public static readonly Pine.Core.PineValue List_f1126ab7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7552bdea]);

    public static readonly Pine.Core.PineValue List_3c738443 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_391923b1]);

    public static readonly Pine.Core.PineValue List_908d1ad7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f942a019]);

    public static readonly Pine.Core.PineValue List_e38aa202 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0175b775]);

    public static readonly Pine.Core.PineValue List_6f6d2891 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_57e7e72f]);

    public static readonly Pine.Core.PineValue List_39f2ae3c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e175dee1]);

    public static readonly Pine.Core.PineValue List_2f4a0deb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b2076a7a]);

    public static readonly Pine.Core.PineValue List_95e38d7c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e159da15]);

    public static readonly Pine.Core.PineValue List_34360713 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f70cb462]);

    public static readonly Pine.Core.PineValue List_6ce9509d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5a8089d9]);

    public static readonly Pine.Core.PineValue List_4e766e82 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f1384f10]);

    public static readonly Pine.Core.PineValue List_f64d25c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_00d19808]);

    public static readonly Pine.Core.PineValue List_16c4bb4a =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_57070c8f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_3c738443]);

    public static readonly Pine.Core.PineValue List_2456c204 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_908d1ad7]);

    public static readonly Pine.Core.PineValue List_4045f225 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_e38aa202]);

    public static readonly Pine.Core.PineValue List_48ca5353 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6f6d2891]);

    public static readonly Pine.Core.PineValue List_57c1abc7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_39f2ae3c]);

    public static readonly Pine.Core.PineValue List_cfeaf156 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2f4a0deb]);

    public static readonly Pine.Core.PineValue List_7ed4e0f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_95e38d7c]);

    public static readonly Pine.Core.PineValue List_3c772bcb =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_34360713]);

    public static readonly Pine.Core.PineValue List_bf96d906 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6ce9509d]);

    public static readonly Pine.Core.PineValue List_3b06b690 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_4e766e82]);

    public static readonly Pine.Core.PineValue List_9b2f94f1 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_f64d25c8]);

    public static readonly Pine.Core.PineValue List_d4599ed2 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_2facd5dd]);

    public static readonly Pine.Core.PineValue List_584a0752 =
        Pine.Core.PineValue.List(
            [List_3bb3accf, List_3c738443]);

    public static readonly Pine.Core.PineValue List_Single_List_584a0752 =
        Pine.Core.PineValue.List(
            [List_584a0752]);

    public static readonly Pine.Core.PineValue List_13c67965 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_5d630f29 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_3c738443]);

    public static readonly Pine.Core.PineValue List_fd602b70 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_34aa78aa =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_9e0cdcb8 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_3e645442 =
        Pine.Core.PineValue.List(
            [List_c1b27e6e, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_a413da40 =
        Pine.Core.PineValue.List(
            [List_282dee3a, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_Single_List_13c67965 =
        Pine.Core.PineValue.List(
            [List_13c67965]);

    public static readonly Pine.Core.PineValue List_Single_List_5d630f29 =
        Pine.Core.PineValue.List(
            [List_5d630f29]);

    public static readonly Pine.Core.PineValue List_Single_List_fd602b70 =
        Pine.Core.PineValue.List(
            [List_fd602b70]);

    public static readonly Pine.Core.PineValue List_Single_List_34aa78aa =
        Pine.Core.PineValue.List(
            [List_34aa78aa]);

    public static readonly Pine.Core.PineValue List_Single_List_9e0cdcb8 =
        Pine.Core.PineValue.List(
            [List_9e0cdcb8]);

    public static readonly Pine.Core.PineValue List_Single_List_3e645442 =
        Pine.Core.PineValue.List(
            [List_3e645442]);

    public static readonly Pine.Core.PineValue List_Single_List_a413da40 =
        Pine.Core.PineValue.List(
            [List_a413da40]);

    public static readonly Pine.Core.PineValue List_1d0e40fb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_584a0752]);

    public static readonly Pine.Core.PineValue List_85fcd3b2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_13c67965]);

    public static readonly Pine.Core.PineValue List_b011cd28 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5d630f29]);

    public static readonly Pine.Core.PineValue List_4668ada6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fd602b70]);

    public static readonly Pine.Core.PineValue List_54e81af9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_34aa78aa]);

    public static readonly Pine.Core.PineValue List_8b51b0f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9e0cdcb8]);

    public static readonly Pine.Core.PineValue List_20674cd5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3e645442]);

    public static readonly Pine.Core.PineValue List_af8fb68b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a413da40]);

    public static readonly Pine.Core.PineValue List_2b305696 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_1d0e40fb]);

    public static readonly Pine.Core.PineValue List_6b896037 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_85fcd3b2]);

    public static readonly Pine.Core.PineValue List_8562198d =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b011cd28]);

    public static readonly Pine.Core.PineValue List_3218a5a2 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_4668ada6]);

    public static readonly Pine.Core.PineValue List_5dfec468 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_54e81af9]);

    public static readonly Pine.Core.PineValue List_2299b635 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_8b51b0f4]);

    public static readonly Pine.Core.PineValue List_75387449 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_20674cd5]);

    public static readonly Pine.Core.PineValue List_68f88c9b =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_af8fb68b]);

    public static readonly Pine.Core.PineValue List_b43468c9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_16c4bb4a]);

    public static readonly Pine.Core.PineValue List_b1530ee5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_57070c8f]);

    public static readonly Pine.Core.PineValue List_6dbb5f29 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2456c204]);

    public static readonly Pine.Core.PineValue List_d08202cd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4045f225]);

    public static readonly Pine.Core.PineValue List_35cf017c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_48ca5353]);

    public static readonly Pine.Core.PineValue List_86d38b8d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_57c1abc7]);

    public static readonly Pine.Core.PineValue List_34849c45 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cfeaf156]);

    public static readonly Pine.Core.PineValue List_d181119a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7ed4e0f7]);

    public static readonly Pine.Core.PineValue List_96cfcb00 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3c772bcb]);

    public static readonly Pine.Core.PineValue List_d1b1c293 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bf96d906]);

    public static readonly Pine.Core.PineValue List_f8d1f5d9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3b06b690]);

    public static readonly Pine.Core.PineValue List_a165bdad =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9b2f94f1]);

    public static readonly Pine.Core.PineValue List_ffe23baf =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d4599ed2]);

    public static readonly Pine.Core.PineValue List_Single_List_b43468c9 =
        Pine.Core.PineValue.List(
            [List_b43468c9]);

    public static readonly Pine.Core.PineValue List_Single_List_b1530ee5 =
        Pine.Core.PineValue.List(
            [List_b1530ee5]);

    public static readonly Pine.Core.PineValue List_Single_List_6dbb5f29 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_Single_List_d08202cd =
        Pine.Core.PineValue.List(
            [List_d08202cd]);

    public static readonly Pine.Core.PineValue List_Single_List_86d38b8d =
        Pine.Core.PineValue.List(
            [List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_Single_List_d1b1c293 =
        Pine.Core.PineValue.List(
            [List_d1b1c293]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_b43468c9 =
        Pine.Core.PineValue.List(
            [List_Single_List_b43468c9]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_b1530ee5 =
        Pine.Core.PineValue.List(
            [List_Single_List_b1530ee5]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_6dbb5f29 =
        Pine.Core.PineValue.List(
            [List_Single_List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_d08202cd =
        Pine.Core.PineValue.List(
            [List_Single_List_d08202cd]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_86d38b8d =
        Pine.Core.PineValue.List(
            [List_Single_List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_d1b1c293 =
        Pine.Core.PineValue.List(
            [List_Single_List_d1b1c293]);

    public static readonly Pine.Core.PineValue List_d35e460e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_343863f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ffe23baf]);

    public static readonly Pine.Core.PineValue List_c0abcf7c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_b43468c9]);

    public static readonly Pine.Core.PineValue List_009614b4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_b1530ee5]);

    public static readonly Pine.Core.PineValue List_52d1ddaa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_bc0ffa85 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_d08202cd]);

    public static readonly Pine.Core.PineValue List_3b72ff38 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_ae2bb31e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_d1b1c293]);

    public static readonly Pine.Core.PineValue List_5116da8d =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_01f53f56 =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_b75288da =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_34849c45]);

    public static readonly Pine.Core.PineValue List_6e87169b =
        Pine.Core.PineValue.List(
            [Blob_Str_negate, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_201be182 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_201be182 =
        Pine.Core.PineValue.List(
            [List_201be182]);

    public static readonly Pine.Core.PineValue List_5043654b =
        Pine.Core.PineValue.List(
            [List_bb14d771, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_ebc294be =
        Pine.Core.PineValue.List(
            [List_bb14d771, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_62b47060 =
        Pine.Core.PineValue.List(
            [List_bb14d771, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_Single_List_5043654b =
        Pine.Core.PineValue.List(
            [List_5043654b]);

    public static readonly Pine.Core.PineValue List_Single_List_ebc294be =
        Pine.Core.PineValue.List(
            [List_ebc294be]);

    public static readonly Pine.Core.PineValue List_Single_List_62b47060 =
        Pine.Core.PineValue.List(
            [List_62b47060]);

    public static readonly Pine.Core.PineValue List_1a6050bf =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_44d35e66 =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_8f2aee6f =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_41c9dab6 =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_dde8d7dc =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_34849c45]);

    public static readonly Pine.Core.PineValue List_cf8077a9 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_b3202b6c =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_dfa0cd8f =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_614ed5f8 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_509b74a6 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_34849c45]);

    public static readonly Pine.Core.PineValue List_2e413ede =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_d181119a]);

    public static readonly Pine.Core.PineValue List_d22d0d79 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_8ea850ab =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_56404869]);

    public static readonly Pine.Core.PineValue List_bceeb83f =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_21ca5af5]);

    public static readonly Pine.Core.PineValue List_c515085a =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_1abb8ccc =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_0dcd86c0]);

    public static readonly Pine.Core.PineValue List_fc1d9d72 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_43b95777]);

    public static readonly Pine.Core.PineValue List_a121547c =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_450c12a0]);

    public static readonly Pine.Core.PineValue List_b6dde15a =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_8686044f =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_c1b27e6e]);

    public static readonly Pine.Core.PineValue List_ea49b6d9 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_282dee3a]);

    public static readonly Pine.Core.PineValue List_7ded369e =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_9f1e38f9]);

    public static readonly Pine.Core.PineValue List_90545386 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_14a0ba72]);

    public static readonly Pine.Core.PineValue List_72d76ef9 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_a710c27f]);

    public static readonly Pine.Core.PineValue List_fcd219b8 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_c41d9105]);

    public static readonly Pine.Core.PineValue List_3c72a55c =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_56404869]);

    public static readonly Pine.Core.PineValue List_7439a59e =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_e657a286 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_c41d9105]);

    public static readonly Pine.Core.PineValue List_d9c17fa9 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_56404869]);

    public static readonly Pine.Core.PineValue List_067bdde0 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_f4cfb374 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_56404869]);

    public static readonly Pine.Core.PineValue List_dce1c74c =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_7fe04a88 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_0dcd86c0]);

    public static readonly Pine.Core.PineValue List_8e1c8f32 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_f34058c1 =
        Pine.Core.PineValue.List(
            [List_d181119a, List_d2a677f1]);

    public static readonly Pine.Core.PineValue List_b3b65caa =
        Pine.Core.PineValue.List(
            [List_96cfcb00, List_6dda98c4]);

    public static readonly Pine.Core.PineValue List_Single_List_1a6050bf =
        Pine.Core.PineValue.List(
            [List_1a6050bf]);

    public static readonly Pine.Core.PineValue List_Single_List_44d35e66 =
        Pine.Core.PineValue.List(
            [List_44d35e66]);

    public static readonly Pine.Core.PineValue List_Single_List_8f2aee6f =
        Pine.Core.PineValue.List(
            [List_8f2aee6f]);

    public static readonly Pine.Core.PineValue List_Single_List_41c9dab6 =
        Pine.Core.PineValue.List(
            [List_41c9dab6]);

    public static readonly Pine.Core.PineValue List_Single_List_dde8d7dc =
        Pine.Core.PineValue.List(
            [List_dde8d7dc]);

    public static readonly Pine.Core.PineValue List_Single_List_cf8077a9 =
        Pine.Core.PineValue.List(
            [List_cf8077a9]);

    public static readonly Pine.Core.PineValue List_Single_List_b3202b6c =
        Pine.Core.PineValue.List(
            [List_b3202b6c]);

    public static readonly Pine.Core.PineValue List_Single_List_dfa0cd8f =
        Pine.Core.PineValue.List(
            [List_dfa0cd8f]);

    public static readonly Pine.Core.PineValue List_Single_List_614ed5f8 =
        Pine.Core.PineValue.List(
            [List_614ed5f8]);

    public static readonly Pine.Core.PineValue List_Single_List_509b74a6 =
        Pine.Core.PineValue.List(
            [List_509b74a6]);

    public static readonly Pine.Core.PineValue List_Single_List_2e413ede =
        Pine.Core.PineValue.List(
            [List_2e413ede]);

    public static readonly Pine.Core.PineValue List_Single_List_d22d0d79 =
        Pine.Core.PineValue.List(
            [List_d22d0d79]);

    public static readonly Pine.Core.PineValue List_Single_List_8ea850ab =
        Pine.Core.PineValue.List(
            [List_8ea850ab]);

    public static readonly Pine.Core.PineValue List_Single_List_bceeb83f =
        Pine.Core.PineValue.List(
            [List_bceeb83f]);

    public static readonly Pine.Core.PineValue List_Single_List_c515085a =
        Pine.Core.PineValue.List(
            [List_c515085a]);

    public static readonly Pine.Core.PineValue List_Single_List_1abb8ccc =
        Pine.Core.PineValue.List(
            [List_1abb8ccc]);

    public static readonly Pine.Core.PineValue List_Single_List_fc1d9d72 =
        Pine.Core.PineValue.List(
            [List_fc1d9d72]);

    public static readonly Pine.Core.PineValue List_Single_List_a121547c =
        Pine.Core.PineValue.List(
            [List_a121547c]);

    public static readonly Pine.Core.PineValue List_Single_List_b6dde15a =
        Pine.Core.PineValue.List(
            [List_b6dde15a]);

    public static readonly Pine.Core.PineValue List_Single_List_8686044f =
        Pine.Core.PineValue.List(
            [List_8686044f]);

    public static readonly Pine.Core.PineValue List_Single_List_ea49b6d9 =
        Pine.Core.PineValue.List(
            [List_ea49b6d9]);

    public static readonly Pine.Core.PineValue List_Single_List_7ded369e =
        Pine.Core.PineValue.List(
            [List_7ded369e]);

    public static readonly Pine.Core.PineValue List_Single_List_90545386 =
        Pine.Core.PineValue.List(
            [List_90545386]);

    public static readonly Pine.Core.PineValue List_Single_List_72d76ef9 =
        Pine.Core.PineValue.List(
            [List_72d76ef9]);

    public static readonly Pine.Core.PineValue List_Single_List_fcd219b8 =
        Pine.Core.PineValue.List(
            [List_fcd219b8]);

    public static readonly Pine.Core.PineValue List_Single_List_3c72a55c =
        Pine.Core.PineValue.List(
            [List_3c72a55c]);

    public static readonly Pine.Core.PineValue List_Single_List_7439a59e =
        Pine.Core.PineValue.List(
            [List_7439a59e]);

    public static readonly Pine.Core.PineValue List_Single_List_e657a286 =
        Pine.Core.PineValue.List(
            [List_e657a286]);

    public static readonly Pine.Core.PineValue List_Single_List_d9c17fa9 =
        Pine.Core.PineValue.List(
            [List_d9c17fa9]);

    public static readonly Pine.Core.PineValue List_Single_List_067bdde0 =
        Pine.Core.PineValue.List(
            [List_067bdde0]);

    public static readonly Pine.Core.PineValue List_Single_List_f4cfb374 =
        Pine.Core.PineValue.List(
            [List_f4cfb374]);

    public static readonly Pine.Core.PineValue List_Single_List_dce1c74c =
        Pine.Core.PineValue.List(
            [List_dce1c74c]);

    public static readonly Pine.Core.PineValue List_Single_List_7fe04a88 =
        Pine.Core.PineValue.List(
            [List_7fe04a88]);

    public static readonly Pine.Core.PineValue List_Single_List_8e1c8f32 =
        Pine.Core.PineValue.List(
            [List_8e1c8f32]);

    public static readonly Pine.Core.PineValue List_Single_List_f34058c1 =
        Pine.Core.PineValue.List(
            [List_f34058c1]);

    public static readonly Pine.Core.PineValue List_Single_List_b3b65caa =
        Pine.Core.PineValue.List(
            [List_b3b65caa]);

    public static readonly Pine.Core.PineValue List_56e1c57f =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_aa637125]);

    public static readonly Pine.Core.PineValue List_75f9b5a2 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_afc7f021]);

    public static readonly Pine.Core.PineValue List_69c24ab9 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_0d6ad46e]);

    public static readonly Pine.Core.PineValue List_c4911331 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_e29763f2]);

    public static readonly Pine.Core.PineValue List_7c3f1486 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_132b89ac]);

    public static readonly Pine.Core.PineValue List_86814860 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_c48683dd]);

    public static readonly Pine.Core.PineValue List_105e61bb =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_87a2a774]);

    public static readonly Pine.Core.PineValue List_202df1c1 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_4c2609c3]);

    public static readonly Pine.Core.PineValue List_c724a77d =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_c3b08663]);

    public static readonly Pine.Core.PineValue List_b120fa9d =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_e844984b]);

    public static readonly Pine.Core.PineValue List_d638dc84 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_a9196577]);

    public static readonly Pine.Core.PineValue List_629d020f =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_9728f698]);

    public static readonly Pine.Core.PineValue List_669f208d =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_86fad7dd]);

    public static readonly Pine.Core.PineValue List_2a208752 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_c005c994]);

    public static readonly Pine.Core.PineValue List_a86f3e07 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_33c6f4ad]);

    public static readonly Pine.Core.PineValue List_53356e85 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_1a0b8610]);

    public static readonly Pine.Core.PineValue List_6f3c5d41 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_ecf5f39d]);

    public static readonly Pine.Core.PineValue List_Single_List_56e1c57f =
        Pine.Core.PineValue.List(
            [List_56e1c57f]);

    public static readonly Pine.Core.PineValue List_Single_List_75f9b5a2 =
        Pine.Core.PineValue.List(
            [List_75f9b5a2]);

    public static readonly Pine.Core.PineValue List_Single_List_69c24ab9 =
        Pine.Core.PineValue.List(
            [List_69c24ab9]);

    public static readonly Pine.Core.PineValue List_Single_List_c4911331 =
        Pine.Core.PineValue.List(
            [List_c4911331]);

    public static readonly Pine.Core.PineValue List_Single_List_7c3f1486 =
        Pine.Core.PineValue.List(
            [List_7c3f1486]);

    public static readonly Pine.Core.PineValue List_Single_List_86814860 =
        Pine.Core.PineValue.List(
            [List_86814860]);

    public static readonly Pine.Core.PineValue List_Single_List_105e61bb =
        Pine.Core.PineValue.List(
            [List_105e61bb]);

    public static readonly Pine.Core.PineValue List_Single_List_202df1c1 =
        Pine.Core.PineValue.List(
            [List_202df1c1]);

    public static readonly Pine.Core.PineValue List_Single_List_c724a77d =
        Pine.Core.PineValue.List(
            [List_c724a77d]);

    public static readonly Pine.Core.PineValue List_Single_List_b120fa9d =
        Pine.Core.PineValue.List(
            [List_b120fa9d]);

    public static readonly Pine.Core.PineValue List_Single_List_d638dc84 =
        Pine.Core.PineValue.List(
            [List_d638dc84]);

    public static readonly Pine.Core.PineValue List_Single_List_629d020f =
        Pine.Core.PineValue.List(
            [List_629d020f]);

    public static readonly Pine.Core.PineValue List_Single_List_669f208d =
        Pine.Core.PineValue.List(
            [List_669f208d]);

    public static readonly Pine.Core.PineValue List_Single_List_2a208752 =
        Pine.Core.PineValue.List(
            [List_2a208752]);

    public static readonly Pine.Core.PineValue List_Single_List_a86f3e07 =
        Pine.Core.PineValue.List(
            [List_a86f3e07]);

    public static readonly Pine.Core.PineValue List_Single_List_53356e85 =
        Pine.Core.PineValue.List(
            [List_53356e85]);

    public static readonly Pine.Core.PineValue List_Single_List_6f3c5d41 =
        Pine.Core.PineValue.List(
            [List_6f3c5d41]);

    public static readonly Pine.Core.PineValue List_8304a9e2 =
        Pine.Core.PineValue.List(
            [List_d181119a, List_45564a6a]);

    public static readonly Pine.Core.PineValue List_Single_List_8304a9e2 =
        Pine.Core.PineValue.List(
            [List_8304a9e2]);

    public static readonly Pine.Core.PineValue List_ad2fad57 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2b305696]);

    public static readonly Pine.Core.PineValue List_c6d77eca =
        Pine.Core.PineValue.List(
            [List_976730e9, List_28767619]);

    public static readonly Pine.Core.PineValue List_1e7ff67e =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_bd06385a]);

    public static readonly Pine.Core.PineValue List_607249b5 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_bd06385a]);

    public static readonly Pine.Core.PineValue List_45d6e69b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_201be182]);

    public static readonly Pine.Core.PineValue List_1f27fb25 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5043654b]);

    public static readonly Pine.Core.PineValue List_23bb8f95 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ebc294be]);

    public static readonly Pine.Core.PineValue List_69f0dbcb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_62b47060]);

    public static readonly Pine.Core.PineValue List_793dba03 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_c0abcf7c]);

    public static readonly Pine.Core.PineValue List_d7034195 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_3b72ff38]);

    public static readonly Pine.Core.PineValue List_Single_List_793dba03 =
        Pine.Core.PineValue.List(
            [List_793dba03]);

    public static readonly Pine.Core.PineValue List_Single_List_d7034195 =
        Pine.Core.PineValue.List(
            [List_d7034195]);

    public static readonly Pine.Core.PineValue List_9cd0e5ac =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1a6050bf]);

    public static readonly Pine.Core.PineValue List_3b615ac8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_44d35e66]);

    public static readonly Pine.Core.PineValue List_5149771a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f2aee6f]);

    public static readonly Pine.Core.PineValue List_7b310b74 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_41c9dab6]);

    public static readonly Pine.Core.PineValue List_24040db4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_dde8d7dc]);

    public static readonly Pine.Core.PineValue List_0c93e820 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cf8077a9]);

    public static readonly Pine.Core.PineValue List_5d219a6c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b3202b6c]);

    public static readonly Pine.Core.PineValue List_bc7bc6eb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_dfa0cd8f]);

    public static readonly Pine.Core.PineValue List_7904c6a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_614ed5f8]);

    public static readonly Pine.Core.PineValue List_6832cb8c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_509b74a6]);

    public static readonly Pine.Core.PineValue List_fa626fb6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2e413ede]);

    public static readonly Pine.Core.PineValue List_9c09bcd4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d22d0d79]);

    public static readonly Pine.Core.PineValue List_8cfa47af =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8ea850ab]);

    public static readonly Pine.Core.PineValue List_c1caa9ce =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bceeb83f]);

    public static readonly Pine.Core.PineValue List_c384906f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c515085a]);

    public static readonly Pine.Core.PineValue List_2fbd364c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1abb8ccc]);

    public static readonly Pine.Core.PineValue List_e226eaf2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fc1d9d72]);

    public static readonly Pine.Core.PineValue List_1495bfe0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a121547c]);

    public static readonly Pine.Core.PineValue List_3cbc0077 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b6dde15a]);

    public static readonly Pine.Core.PineValue List_c8df3faa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8686044f]);

    public static readonly Pine.Core.PineValue List_0ae6e3d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ea49b6d9]);

    public static readonly Pine.Core.PineValue List_319e8969 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7ded369e]);

    public static readonly Pine.Core.PineValue List_450a4601 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_90545386]);

    public static readonly Pine.Core.PineValue List_a600a39c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_72d76ef9]);

    public static readonly Pine.Core.PineValue List_00efda36 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fcd219b8]);

    public static readonly Pine.Core.PineValue List_97e04f57 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3c72a55c]);

    public static readonly Pine.Core.PineValue List_c221633e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7439a59e]);

    public static readonly Pine.Core.PineValue List_5fd40085 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e657a286]);

    public static readonly Pine.Core.PineValue List_a12542a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d9c17fa9]);

    public static readonly Pine.Core.PineValue List_5b9ce173 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_067bdde0]);

    public static readonly Pine.Core.PineValue List_a83d5f28 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f4cfb374]);

    public static readonly Pine.Core.PineValue List_a3acbbf8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_dce1c74c]);

    public static readonly Pine.Core.PineValue List_90d23f25 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7fe04a88]);

    public static readonly Pine.Core.PineValue List_cc1aecae =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8e1c8f32]);

    public static readonly Pine.Core.PineValue List_12e6de70 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f34058c1]);

    public static readonly Pine.Core.PineValue List_5eadd240 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b3b65caa]);

    public static readonly Pine.Core.PineValue List_c37ef632 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6b896037]);

    public static readonly Pine.Core.PineValue List_4de8c353 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8562198d]);

    public static readonly Pine.Core.PineValue List_ee3ba15f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3218a5a2]);

    public static readonly Pine.Core.PineValue List_8467fd97 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5dfec468]);

    public static readonly Pine.Core.PineValue List_5f0dd535 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2299b635]);

    public static readonly Pine.Core.PineValue List_350f5fcc =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_75387449]);

    public static readonly Pine.Core.PineValue List_ace2ae94 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_68f88c9b]);

    public static readonly Pine.Core.PineValue List_a97ad260 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_56e1c57f]);

    public static readonly Pine.Core.PineValue List_164ea311 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_75f9b5a2]);

    public static readonly Pine.Core.PineValue List_3e8dc048 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_69c24ab9]);

    public static readonly Pine.Core.PineValue List_5b3619ce =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c4911331]);

    public static readonly Pine.Core.PineValue List_c159733d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7c3f1486]);

    public static readonly Pine.Core.PineValue List_cfa0f4b7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_86814860]);

    public static readonly Pine.Core.PineValue List_777cbee3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_105e61bb]);

    public static readonly Pine.Core.PineValue List_bc60a7c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_202df1c1]);

    public static readonly Pine.Core.PineValue List_bead607d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c724a77d]);

    public static readonly Pine.Core.PineValue List_21ae8a6f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b120fa9d]);

    public static readonly Pine.Core.PineValue List_1d2e8caa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d638dc84]);

    public static readonly Pine.Core.PineValue List_3fac1535 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_629d020f]);

    public static readonly Pine.Core.PineValue List_cc7b0613 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_669f208d]);

    public static readonly Pine.Core.PineValue List_edd4c1e1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2a208752]);

    public static readonly Pine.Core.PineValue List_9942c461 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a86f3e07]);

    public static readonly Pine.Core.PineValue List_93980072 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_53356e85]);

    public static readonly Pine.Core.PineValue List_70d5c11b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6f3c5d41]);

    public static readonly Pine.Core.PineValue List_65aff69b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8304a9e2]);

    public static readonly Pine.Core.PineValue List_cbdf5919 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_2f1c6993]);

    public static readonly Pine.Core.PineValue List_Single_List_cbdf5919 =
        Pine.Core.PineValue.List(
            [List_cbdf5919]);

    public static readonly Pine.Core.PineValue List_52b5baa6 =
        Pine.Core.PineValue.List(
            [List_d816deb1, List_52d1ddaa]);

    public static readonly Pine.Core.PineValue List_Single_List_52b5baa6 =
        Pine.Core.PineValue.List(
            [List_52b5baa6]);

    public static readonly Pine.Core.PineValue List_baac9ffb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_793dba03]);

    public static readonly Pine.Core.PineValue List_bfd00849 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d7034195]);

    public static readonly Pine.Core.PineValue List_a53f1292 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c37ef632]);

    public static readonly Pine.Core.PineValue List_290d4c0d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ee3ba15f]);

    public static readonly Pine.Core.PineValue List_756f9fb0 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_8467fd97]);

    public static readonly Pine.Core.PineValue List_e093bbe2 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_5f0dd535]);

    public static readonly Pine.Core.PineValue List_66fda06d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_350f5fcc]);

    public static readonly Pine.Core.PineValue List_8cb8829f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ace2ae94]);

    public static readonly Pine.Core.PineValue List_dc3b52cc =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_0c93e820]);

    public static readonly Pine.Core.PineValue List_8dbfac3c =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_5d219a6c]);

    public static readonly Pine.Core.PineValue List_7320d8af =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_bc7bc6eb]);

    public static readonly Pine.Core.PineValue List_a28160e0 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_7904c6a3]);

    public static readonly Pine.Core.PineValue List_2bb7e1c2 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_6832cb8c]);

    public static readonly Pine.Core.PineValue List_a7f8e96d =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_fa626fb6]);

    public static readonly Pine.Core.PineValue List_68402a1f =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_9cd0e5ac]);

    public static readonly Pine.Core.PineValue List_72511297 =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_9c09bcd4]);

    public static readonly Pine.Core.PineValue List_565652da =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_45d6e69b]);

    public static readonly Pine.Core.PineValue List_30a14c44 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c384906f]);

    public static readonly Pine.Core.PineValue List_603fc0f6 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2fbd364c]);

    public static readonly Pine.Core.PineValue List_8a712b74 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_e226eaf2]);

    public static readonly Pine.Core.PineValue List_2dfe985a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_1495bfe0]);

    public static readonly Pine.Core.PineValue List_dd1c3ed5 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3cbc0077]);

    public static readonly Pine.Core.PineValue List_a10d2195 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c8df3faa]);

    public static readonly Pine.Core.PineValue List_6012d098 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_0ae6e3d8]);

    public static readonly Pine.Core.PineValue List_b57a6f71 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_319e8969]);

    public static readonly Pine.Core.PineValue List_42cb48d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_450a4601]);

    public static readonly Pine.Core.PineValue List_dfcd41a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a600a39c]);

    public static readonly Pine.Core.PineValue List_822c2d35 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a97ad260]);

    public static readonly Pine.Core.PineValue List_b7a34d27 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_164ea311]);

    public static readonly Pine.Core.PineValue List_8b302879 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3e8dc048]);

    public static readonly Pine.Core.PineValue List_57c9b765 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_5b3619ce]);

    public static readonly Pine.Core.PineValue List_d40f476d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c159733d]);

    public static readonly Pine.Core.PineValue List_a07389bc =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_cfa0f4b7]);

    public static readonly Pine.Core.PineValue List_42a63978 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_777cbee3]);

    public static readonly Pine.Core.PineValue List_e6f68a03 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_bc60a7c6]);

    public static readonly Pine.Core.PineValue List_440fbe8c =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_bead607d]);

    public static readonly Pine.Core.PineValue List_3669bc56 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_21ae8a6f]);

    public static readonly Pine.Core.PineValue List_f9a58f24 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_1d2e8caa]);

    public static readonly Pine.Core.PineValue List_ad41dc24 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3fac1535]);

    public static readonly Pine.Core.PineValue List_cba51789 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_cc7b0613]);

    public static readonly Pine.Core.PineValue List_becb772b =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_edd4c1e1]);

    public static readonly Pine.Core.PineValue List_7f5bc416 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_9942c461]);

    public static readonly Pine.Core.PineValue List_3a26f015 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_93980072]);

    public static readonly Pine.Core.PineValue List_898001d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_70d5c11b]);

    public static readonly Pine.Core.PineValue List_dcfd7fa2 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_7b310b74]);

    public static readonly Pine.Core.PineValue List_f1eb41c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_24040db4]);

    public static readonly Pine.Core.PineValue List_87642022 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cbdf5919]);

    public static readonly Pine.Core.PineValue List_406b3c89 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_65aff69b]);

    public static readonly Pine.Core.PineValue List_5c04fa57 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_c1caa9ce]);

    public static readonly Pine.Core.PineValue List_7cdfbae4 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_c221633e]);

    public static readonly Pine.Core.PineValue List_48f2c0f0 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_5b9ce173]);

    public static readonly Pine.Core.PineValue List_0934a05a =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_90d23f25]);

    public static readonly Pine.Core.PineValue List_cbddcd64 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_cc1aecae]);

    public static readonly Pine.Core.PineValue List_c000b476 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_8cfa47af]);

    public static readonly Pine.Core.PineValue List_b98b999e =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_97e04f57]);

    public static readonly Pine.Core.PineValue List_74c24411 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_5fd40085]);

    public static readonly Pine.Core.PineValue List_7310c8bc =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_a12542a5]);

    public static readonly Pine.Core.PineValue List_ee9b9f21 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_a83d5f28]);

    public static readonly Pine.Core.PineValue List_4858a565 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_12e6de70]);

    public static readonly Pine.Core.PineValue List_c2cb27ba =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_5eadd240]);

    public static readonly Pine.Core.PineValue List_9a9bd68c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_52b5baa6]);

    public static readonly Pine.Core.PineValue List_9f80ab63 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d35e460e]);

    public static readonly Pine.Core.PineValue List_288d34f6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_343863f3]);

    public static readonly Pine.Core.PineValue List_6aba02f2 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c6d77eca]);

    public static readonly Pine.Core.PineValue List_87c481f1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5116da8d]);

    public static readonly Pine.Core.PineValue List_f050a3a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_01f53f56]);

    public static readonly Pine.Core.PineValue List_9a2e6868 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b75288da]);

    public static readonly Pine.Core.PineValue List_838a4b21 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6e87169b]);

    public static readonly Pine.Core.PineValue List_Single_List_838a4b21 =
        Pine.Core.PineValue.List(
            [List_838a4b21]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_838a4b21 =
        Pine.Core.PineValue.List(
            [List_Single_List_838a4b21]);

    public static readonly Pine.Core.PineValue List_6c4757ae =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_1e7ff67e]);

    public static readonly Pine.Core.PineValue List_0425a888 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_607249b5]);

    public static readonly Pine.Core.PineValue List_0eea03d6 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_288d34f6]);

    public static readonly Pine.Core.PineValue List_44a94f99 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_87642022]);

    public static readonly Pine.Core.PineValue List_c845a04b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_838a4b21]);

    public static readonly Pine.Core.PineValue List_22c1a614 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_288d34f6]);

    public static readonly Pine.Core.PineValue List_Single_List_22c1a614 =
        Pine.Core.PineValue.List(
            [List_22c1a614]);

    public static readonly Pine.Core.PineValue List_e2703db8 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_9cd0e5ac]);

    public static readonly Pine.Core.PineValue List_2586c3c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_3b615ac8]);

    public static readonly Pine.Core.PineValue List_a89dfaa5 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_5149771a]);

    public static readonly Pine.Core.PineValue List_5e60c3b8 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_24040db4]);

    public static readonly Pine.Core.PineValue List_fe813e16 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_c384906f]);

    public static readonly Pine.Core.PineValue List_844b05ea =
        Pine.Core.PineValue.List(
            [List_6aba02f2, List_56404869]);

    public static readonly Pine.Core.PineValue List_e9dfc2d2 =
        Pine.Core.PineValue.List(
            [List_87c481f1, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_15f6c6fe =
        Pine.Core.PineValue.List(
            [List_f050a3a3, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_3cd77ae6 =
        Pine.Core.PineValue.List(
            [List_9a2e6868, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_Single_List_844b05ea =
        Pine.Core.PineValue.List(
            [List_844b05ea]);

    public static readonly Pine.Core.PineValue List_Single_List_e9dfc2d2 =
        Pine.Core.PineValue.List(
            [List_e9dfc2d2]);

    public static readonly Pine.Core.PineValue List_Single_List_15f6c6fe =
        Pine.Core.PineValue.List(
            [List_15f6c6fe]);

    public static readonly Pine.Core.PineValue List_Single_List_3cd77ae6 =
        Pine.Core.PineValue.List(
            [List_3cd77ae6]);

    public static readonly Pine.Core.PineValue List_689950c1 =
        Pine.Core.PineValue.List(
            [List_d816deb1, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_689950c1 =
        Pine.Core.PineValue.List(
            [List_689950c1]);

    public static readonly Pine.Core.PineValue List_c2dc0202 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_22c1a614]);

    public static readonly Pine.Core.PineValue List_4af1f0ec =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a53f1292]);

    public static readonly Pine.Core.PineValue List_768cc61e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_290d4c0d]);

    public static readonly Pine.Core.PineValue List_a71e519b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_756f9fb0]);

    public static readonly Pine.Core.PineValue List_43d1faf6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e093bbe2]);

    public static readonly Pine.Core.PineValue List_e15c7b5b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_66fda06d]);

    public static readonly Pine.Core.PineValue List_6a6a2dde =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8cb8829f]);

    public static readonly Pine.Core.PineValue List_e7e7947e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dc3b52cc]);

    public static readonly Pine.Core.PineValue List_3d7e42b0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8dbfac3c]);

    public static readonly Pine.Core.PineValue List_e7bc1ec8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7320d8af]);

    public static readonly Pine.Core.PineValue List_e4c8bd61 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a28160e0]);

    public static readonly Pine.Core.PineValue List_6ee5ba57 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2bb7e1c2]);

    public static readonly Pine.Core.PineValue List_9058636f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a7f8e96d]);

    public static readonly Pine.Core.PineValue List_077af9fc =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_68402a1f]);

    public static readonly Pine.Core.PineValue List_edbaaf20 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_72511297]);

    public static readonly Pine.Core.PineValue List_Single_List_4af1f0ec =
        Pine.Core.PineValue.List(
            [List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_4af1f0ec =
        Pine.Core.PineValue.List(
            [List_Single_List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_c9797743 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_565652da]);

    public static readonly Pine.Core.PineValue List_fdc0b299 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_fdc0b299 =
        Pine.Core.PineValue.List(
            [List_fdc0b299]);

    public static readonly Pine.Core.PineValue List_86533e31 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_30a14c44]);

    public static readonly Pine.Core.PineValue List_17822585 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_603fc0f6]);

    public static readonly Pine.Core.PineValue List_d221b4a8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8a712b74]);

    public static readonly Pine.Core.PineValue List_964ab9eb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2dfe985a]);

    public static readonly Pine.Core.PineValue List_fc9faf1d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dd1c3ed5]);

    public static readonly Pine.Core.PineValue List_f87b80d6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a10d2195]);

    public static readonly Pine.Core.PineValue List_ad4f2fb3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6012d098]);

    public static readonly Pine.Core.PineValue List_78d72533 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b57a6f71]);

    public static readonly Pine.Core.PineValue List_d2e3da11 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_42cb48d7]);

    public static readonly Pine.Core.PineValue List_e0f436ab =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dfcd41a3]);

    public static readonly Pine.Core.PineValue List_ef375b29 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_822c2d35]);

    public static readonly Pine.Core.PineValue List_87e4f8c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b7a34d27]);

    public static readonly Pine.Core.PineValue List_4ac3f89e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8b302879]);

    public static readonly Pine.Core.PineValue List_809b3b53 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_57c9b765]);

    public static readonly Pine.Core.PineValue List_977e4e6c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d40f476d]);

    public static readonly Pine.Core.PineValue List_2f8121ff =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a07389bc]);

    public static readonly Pine.Core.PineValue List_cc7e0e58 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_42a63978]);

    public static readonly Pine.Core.PineValue List_f51b8ded =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e6f68a03]);

    public static readonly Pine.Core.PineValue List_e64f48d5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_440fbe8c]);

    public static readonly Pine.Core.PineValue List_1ee8f4a1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3669bc56]);

    public static readonly Pine.Core.PineValue List_ac1b4431 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f9a58f24]);

    public static readonly Pine.Core.PineValue List_d71bc0a6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ad41dc24]);

    public static readonly Pine.Core.PineValue List_4923799e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cba51789]);

    public static readonly Pine.Core.PineValue List_753c87a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_becb772b]);

    public static readonly Pine.Core.PineValue List_2f4aebd4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7f5bc416]);

    public static readonly Pine.Core.PineValue List_8e2f37cd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3a26f015]);

    public static readonly Pine.Core.PineValue List_9d026cc8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_898001d7]);

    public static readonly Pine.Core.PineValue List_7a215074 =
        Pine.Core.PineValue.List(
            [List_049cce88, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_7a215074 =
        Pine.Core.PineValue.List(
            [List_7a215074]);

    public static readonly Pine.Core.PineValue List_da715c2d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_844b05ea]);

    public static readonly Pine.Core.PineValue List_37fe0cf3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e9dfc2d2]);

    public static readonly Pine.Core.PineValue List_8f890a69 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_15f6c6fe]);

    public static readonly Pine.Core.PineValue List_2bffc265 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3cd77ae6]);

    public static readonly Pine.Core.PineValue List_96b83b24 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dcfd7fa2]);

    public static readonly Pine.Core.PineValue List_7d0d2ed9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f1eb41c8]);

    public static readonly Pine.Core.PineValue List_2da1ee5d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_406b3c89]);

    public static readonly Pine.Core.PineValue List_f7e47dc9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5c04fa57]);

    public static readonly Pine.Core.PineValue List_e20932bd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7cdfbae4]);

    public static readonly Pine.Core.PineValue List_c7049af9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_48f2c0f0]);

    public static readonly Pine.Core.PineValue List_13c1b98b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0934a05a]);

    public static readonly Pine.Core.PineValue List_c18dedfa =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cbddcd64]);

    public static readonly Pine.Core.PineValue List_9496b055 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c000b476]);

    public static readonly Pine.Core.PineValue List_47457b14 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b98b999e]);

    public static readonly Pine.Core.PineValue List_b65b91d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_74c24411]);

    public static readonly Pine.Core.PineValue List_7a9bb0f9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7310c8bc]);

    public static readonly Pine.Core.PineValue List_aa0efd15 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ee9b9f21]);

    public static readonly Pine.Core.PineValue List_a6002954 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4858a565]);

    public static readonly Pine.Core.PineValue List_9d4300f6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c2cb27ba]);

    public static readonly Pine.Core.PineValue List_Single_List_9d4300f6 =
        Pine.Core.PineValue.List(
            [List_9d4300f6]);

    public static readonly Pine.Core.PineValue List_c3316bb8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_689950c1]);

    public static readonly Pine.Core.PineValue List_cdc0cc19 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_c0abcf7c]);

    public static readonly Pine.Core.PineValue List_Single_List_cdc0cc19 =
        Pine.Core.PineValue.List(
            [List_cdc0cc19]);

    public static readonly Pine.Core.PineValue List_fb2711a8 =
        Pine.Core.PineValue.List(
            [List_ad18d3d3, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_fb2711a8 =
        Pine.Core.PineValue.List(
            [List_fb2711a8]);

    public static readonly Pine.Core.PineValue List_3152db3d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_583bd6fe =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_cb7ad7b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a71e519b]);

    public static readonly Pine.Core.PineValue List_faacd549 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_43d1faf6]);

    public static readonly Pine.Core.PineValue List_960690b4 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_e15c7b5b]);

    public static readonly Pine.Core.PineValue List_fffb5b92 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6a6a2dde]);

    public static readonly Pine.Core.PineValue List_432dee6f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_e7e7947e]);

    public static readonly Pine.Core.PineValue List_b0ae5add =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_3d7e42b0]);

    public static readonly Pine.Core.PineValue List_52a12e26 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_e7bc1ec8]);

    public static readonly Pine.Core.PineValue List_84b06bd2 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c2dc0202]);

    public static readonly Pine.Core.PineValue List_18e799b0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_21967383 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fdc0b299]);

    public static readonly Pine.Core.PineValue List_a52c4e61 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7a215074]);

    public static readonly Pine.Core.PineValue List_4cc842d0 =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_c96ff444 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_37fe0cf3]);

    public static readonly Pine.Core.PineValue List_8ede81db =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_8f890a69]);

    public static readonly Pine.Core.PineValue List_9ccdb191 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2bffc265]);

    public static readonly Pine.Core.PineValue List_604d4279 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cdc0cc19]);

    public static readonly Pine.Core.PineValue List_cd861d37 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_628590d7 =
        Pine.Core.PineValue.List(
            [List_077af9fc, List_81e583e7]);

    public static readonly Pine.Core.PineValue List_51a87b3c =
        Pine.Core.PineValue.List(
            [List_077af9fc, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_cd861d37 =
        Pine.Core.PineValue.List(
            [List_cd861d37]);

    public static readonly Pine.Core.PineValue List_Single_List_628590d7 =
        Pine.Core.PineValue.List(
            [List_628590d7]);

    public static readonly Pine.Core.PineValue List_Single_List_51a87b3c =
        Pine.Core.PineValue.List(
            [List_51a87b3c]);

    public static readonly Pine.Core.PineValue List_093bd8ec =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fb2711a8]);

    public static readonly Pine.Core.PineValue List_932561b8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0eea03d6]);

    public static readonly Pine.Core.PineValue List_04fe9790 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_44a94f99]);

    public static readonly Pine.Core.PineValue List_8f8475f4 =
        Pine.Core.PineValue.List(
            [List_bb14d771, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_8f8475f4 =
        Pine.Core.PineValue.List(
            [List_8f8475f4]);

    public static readonly Pine.Core.PineValue List_cb2eac87 =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_43c3a629 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_2acabf78 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_bba1eeca =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_a71e519b]);

    public static readonly Pine.Core.PineValue List_bbd6707a =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_43d1faf6]);

    public static readonly Pine.Core.PineValue List_72360bb6 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_e15c7b5b]);

    public static readonly Pine.Core.PineValue List_a561fb22 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_6a6a2dde]);

    public static readonly Pine.Core.PineValue List_fe24865c =
        Pine.Core.PineValue.List(
            [List_43b95777, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_8094be42 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_9058636f]);

    public static readonly Pine.Core.PineValue List_89e2dbe2 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_a4ac239c =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_56404869]);

    public static readonly Pine.Core.PineValue List_84523d46 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_18b551f9 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_296ab145 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_6dda98c4]);

    public static readonly Pine.Core.PineValue List_Single_List_cb2eac87 =
        Pine.Core.PineValue.List(
            [List_cb2eac87]);

    public static readonly Pine.Core.PineValue List_Single_List_43c3a629 =
        Pine.Core.PineValue.List(
            [List_43c3a629]);

    public static readonly Pine.Core.PineValue List_Single_List_2acabf78 =
        Pine.Core.PineValue.List(
            [List_2acabf78]);

    public static readonly Pine.Core.PineValue List_Single_List_bba1eeca =
        Pine.Core.PineValue.List(
            [List_bba1eeca]);

    public static readonly Pine.Core.PineValue List_Single_List_bbd6707a =
        Pine.Core.PineValue.List(
            [List_bbd6707a]);

    public static readonly Pine.Core.PineValue List_Single_List_72360bb6 =
        Pine.Core.PineValue.List(
            [List_72360bb6]);

    public static readonly Pine.Core.PineValue List_Single_List_a561fb22 =
        Pine.Core.PineValue.List(
            [List_a561fb22]);

    public static readonly Pine.Core.PineValue List_Single_List_fe24865c =
        Pine.Core.PineValue.List(
            [List_fe24865c]);

    public static readonly Pine.Core.PineValue List_Single_List_8094be42 =
        Pine.Core.PineValue.List(
            [List_8094be42]);

    public static readonly Pine.Core.PineValue List_Single_List_89e2dbe2 =
        Pine.Core.PineValue.List(
            [List_89e2dbe2]);

    public static readonly Pine.Core.PineValue List_Single_List_a4ac239c =
        Pine.Core.PineValue.List(
            [List_a4ac239c]);

    public static readonly Pine.Core.PineValue List_Single_List_84523d46 =
        Pine.Core.PineValue.List(
            [List_84523d46]);

    public static readonly Pine.Core.PineValue List_Single_List_18b551f9 =
        Pine.Core.PineValue.List(
            [List_18b551f9]);

    public static readonly Pine.Core.PineValue List_Single_List_296ab145 =
        Pine.Core.PineValue.List(
            [List_296ab145]);

    public static readonly Pine.Core.PineValue List_c8ce1e23 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c3316bb8]);

    public static readonly Pine.Core.PineValue List_3e2edc8f =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_da715c2d]);

    public static readonly Pine.Core.PineValue List_195833a9 =
        Pine.Core.PineValue.List(
            [List_594e965b, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_195833a9 =
        Pine.Core.PineValue.List(
            [List_195833a9]);

    public static readonly Pine.Core.PineValue List_5a003ee9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_9d4300f6]);

    public static readonly Pine.Core.PineValue List_27222e0d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_21967383]);

    public static readonly Pine.Core.PineValue List_b172fbd6 =
        Pine.Core.PineValue.List(
            [List_d0b6bef5, List_9496b055]);

    public static readonly Pine.Core.PineValue List_b81534b6 =
        Pine.Core.PineValue.List(
            [List_d0b6bef5, List_47457b14]);

    public static readonly Pine.Core.PineValue List_6d34492d =
        Pine.Core.PineValue.List(
            [List_d0b6bef5, List_7a9bb0f9]);

    public static readonly Pine.Core.PineValue List_1d374f35 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_28767619]);

    public static readonly Pine.Core.PineValue List_2d6356a2 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_28767619]);

    public static readonly Pine.Core.PineValue List_f9f39fec =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_28767619]);

    public static readonly Pine.Core.PineValue List_d56d288f =
        Pine.Core.PineValue.List(
            [List_34849c45, List_28767619]);

    public static readonly Pine.Core.PineValue List_5ed70eaf =
        Pine.Core.PineValue.List(
            [List_d181119a, List_28767619]);

    public static readonly Pine.Core.PineValue List_Single_List_b172fbd6 =
        Pine.Core.PineValue.List(
            [List_b172fbd6]);

    public static readonly Pine.Core.PineValue List_Single_List_b81534b6 =
        Pine.Core.PineValue.List(
            [List_b81534b6]);

    public static readonly Pine.Core.PineValue List_Single_List_6d34492d =
        Pine.Core.PineValue.List(
            [List_6d34492d]);

    public static readonly Pine.Core.PineValue List_362c65cf =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_0dcd86c0]);

    public static readonly Pine.Core.PineValue List_d34a2066 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_43b95777]);

    public static readonly Pine.Core.PineValue List_94767eab =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_450c12a0]);

    public static readonly Pine.Core.PineValue List_cf9d127d =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_0c82888c]);

    public static readonly Pine.Core.PineValue List_ff6345a5 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_c1b27e6e]);

    public static readonly Pine.Core.PineValue List_5942885c =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_282dee3a]);

    public static readonly Pine.Core.PineValue List_b3cf3439 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_9f1e38f9]);

    public static readonly Pine.Core.PineValue List_0fd47c70 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_14a0ba72]);

    public static readonly Pine.Core.PineValue List_f9acc462 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_a710c27f]);

    public static readonly Pine.Core.PineValue List_Single_List_362c65cf =
        Pine.Core.PineValue.List(
            [List_362c65cf]);

    public static readonly Pine.Core.PineValue List_Single_List_d34a2066 =
        Pine.Core.PineValue.List(
            [List_d34a2066]);

    public static readonly Pine.Core.PineValue List_Single_List_94767eab =
        Pine.Core.PineValue.List(
            [List_94767eab]);

    public static readonly Pine.Core.PineValue List_Single_List_cf9d127d =
        Pine.Core.PineValue.List(
            [List_cf9d127d]);

    public static readonly Pine.Core.PineValue List_Single_List_ff6345a5 =
        Pine.Core.PineValue.List(
            [List_ff6345a5]);

    public static readonly Pine.Core.PineValue List_Single_List_5942885c =
        Pine.Core.PineValue.List(
            [List_5942885c]);

    public static readonly Pine.Core.PineValue List_Single_List_b3cf3439 =
        Pine.Core.PineValue.List(
            [List_b3cf3439]);

    public static readonly Pine.Core.PineValue List_Single_List_0fd47c70 =
        Pine.Core.PineValue.List(
            [List_0fd47c70]);

    public static readonly Pine.Core.PineValue List_Single_List_f9acc462 =
        Pine.Core.PineValue.List(
            [List_f9acc462]);

    public static readonly Pine.Core.PineValue List_f01d9003 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a52c4e61]);

    public static readonly Pine.Core.PineValue List_48ef2b7b =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_48ef2b7b =
        Pine.Core.PineValue.List(
            [List_48ef2b7b]);

    public static readonly Pine.Core.PineValue List_14b62d60 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cd861d37]);

    public static readonly Pine.Core.PineValue List_feb31c4b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_628590d7]);

    public static readonly Pine.Core.PineValue List_eea56b61 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_51a87b3c]);

    public static readonly Pine.Core.PineValue List_23afeea9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e2703db8]);

    public static readonly Pine.Core.PineValue List_7e774b12 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2586c3c6]);

    public static readonly Pine.Core.PineValue List_a39c07a7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a89dfaa5]);

    public static readonly Pine.Core.PineValue List_e6a1f4f0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5e60c3b8]);

    public static readonly Pine.Core.PineValue List_32d71b95 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fe813e16]);

    public static readonly Pine.Core.PineValue List_6386e244 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f8475f4]);

    public static readonly Pine.Core.PineValue List_6962715f =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_18e799b0]);

    public static readonly Pine.Core.PineValue List_Single_List_6962715f =
        Pine.Core.PineValue.List(
            [List_6962715f]);

    public static readonly Pine.Core.PineValue List_4d3b6f7f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cb2eac87]);

    public static readonly Pine.Core.PineValue List_c12fd35a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_43c3a629]);

    public static readonly Pine.Core.PineValue List_b92e3174 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2acabf78]);

    public static readonly Pine.Core.PineValue List_a4606c8d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bba1eeca]);

    public static readonly Pine.Core.PineValue List_81f884e6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bbd6707a]);

    public static readonly Pine.Core.PineValue List_7a49c37b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_72360bb6]);

    public static readonly Pine.Core.PineValue List_0fe3d024 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a561fb22]);

    public static readonly Pine.Core.PineValue List_6d80c629 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fe24865c]);

    public static readonly Pine.Core.PineValue List_a9d4a80f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8094be42]);

    public static readonly Pine.Core.PineValue List_5e3370cb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_89e2dbe2]);

    public static readonly Pine.Core.PineValue List_a40c9373 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a4ac239c]);

    public static readonly Pine.Core.PineValue List_affeafd7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_84523d46]);

    public static readonly Pine.Core.PineValue List_174dc04f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_18b551f9]);

    public static readonly Pine.Core.PineValue List_6fd5cc88 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_296ab145]);

    public static readonly Pine.Core.PineValue List_346ea80c =
        Pine.Core.PineValue.List(
            [List_f751324e, List_9f80ab63]);

    public static readonly Pine.Core.PineValue List_Single_List_346ea80c =
        Pine.Core.PineValue.List(
            [List_346ea80c]);

    public static readonly Pine.Core.PineValue List_3981b96a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_093bd8ec]);

    public static readonly Pine.Core.PineValue List_424fde1c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_195833a9]);

    public static readonly Pine.Core.PineValue List_4fb806b3 =
        Pine.Core.PineValue.List(
            [List_db582731, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_45aab610 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b172fbd6]);

    public static readonly Pine.Core.PineValue List_0da2d82f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b81534b6]);

    public static readonly Pine.Core.PineValue List_8a25cb53 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6d34492d]);

    public static readonly Pine.Core.PineValue List_8762ed28 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_362c65cf]);

    public static readonly Pine.Core.PineValue List_c70dd18d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d34a2066]);

    public static readonly Pine.Core.PineValue List_5668dd78 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_94767eab]);

    public static readonly Pine.Core.PineValue List_4f8c0bc2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cf9d127d]);

    public static readonly Pine.Core.PineValue List_8c3ec5ad =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ff6345a5]);

    public static readonly Pine.Core.PineValue List_1c8d7ab5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5942885c]);

    public static readonly Pine.Core.PineValue List_8d087e65 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b3cf3439]);

    public static readonly Pine.Core.PineValue List_9ec486cd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0fd47c70]);

    public static readonly Pine.Core.PineValue List_6f43c67d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f9acc462]);

    public static readonly Pine.Core.PineValue List_fef34e0d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_48ef2b7b]);

    public static readonly Pine.Core.PineValue List_12173aa2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6962715f]);

    public static readonly Pine.Core.PineValue List_2102b77e =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c12fd35a]);

    public static readonly Pine.Core.PineValue List_0bc76b59 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b92e3174]);

    public static readonly Pine.Core.PineValue List_89f7e4e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a4606c8d]);

    public static readonly Pine.Core.PineValue List_ff537757 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_81f884e6]);

    public static readonly Pine.Core.PineValue List_13ac85b3 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_7a49c37b]);

    public static readonly Pine.Core.PineValue List_673e4d01 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_0fe3d024]);

    public static readonly Pine.Core.PineValue List_09da05b0 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_6d80c629]);

    public static readonly Pine.Core.PineValue List_bae6cac0 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_5e3370cb]);

    public static readonly Pine.Core.PineValue List_5f16dbfc =
        Pine.Core.PineValue.List(
            [List_977e4e6c, List_bb14d771, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_c85c303e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_346ea80c]);

    public static readonly Pine.Core.PineValue List_206eacc3 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_14b62d60]);

    public static readonly Pine.Core.PineValue List_b18f964f =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_feb31c4b]);

    public static readonly Pine.Core.PineValue List_f7ad2307 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_eea56b61]);

    public static readonly Pine.Core.PineValue List_8baea653 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_affeafd7]);

    public static readonly Pine.Core.PineValue List_f48d98d2 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_424fde1c]);

    public static readonly Pine.Core.PineValue List_d871e219 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_976730e9]);

    public static readonly Pine.Core.PineValue List_Single_List_d871e219 =
        Pine.Core.PineValue.List(
            [List_d871e219]);

    public static readonly Pine.Core.PineValue List_8319f06f =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_a40c9373]);

    public static readonly Pine.Core.PineValue List_770c8d31 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_174dc04f]);

    public static readonly Pine.Core.PineValue List_d9a8bf69 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_a40c9373]);

    public static readonly Pine.Core.PineValue List_6ad75546 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_6fd5cc88]);

    public static readonly Pine.Core.PineValue List_ffb3657e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3152db3d]);

    public static readonly Pine.Core.PineValue List_de173be4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_583bd6fe]);

    public static readonly Pine.Core.PineValue List_596f69a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cb7ad7b9]);

    public static readonly Pine.Core.PineValue List_2595e97f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_faacd549]);

    public static readonly Pine.Core.PineValue List_f088da70 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_960690b4]);

    public static readonly Pine.Core.PineValue List_610179c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fffb5b92]);

    public static readonly Pine.Core.PineValue List_2a20fde4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_432dee6f]);

    public static readonly Pine.Core.PineValue List_0910978f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b0ae5add]);

    public static readonly Pine.Core.PineValue List_5ff4573d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_52a12e26]);

    public static readonly Pine.Core.PineValue List_62c9c6c5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_84b06bd2]);

    public static readonly Pine.Core.PineValue List_2fc6c58a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_fef34e0d]);

    public static readonly Pine.Core.PineValue List_c9704e9c =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c85c303e]);

    public static readonly Pine.Core.PineValue List_7ad89f45 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_8762ed28]);

    public static readonly Pine.Core.PineValue List_6840e7e9 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_c70dd18d]);

    public static readonly Pine.Core.PineValue List_354c0c42 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_5668dd78]);

    public static readonly Pine.Core.PineValue List_a808e609 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_4f8c0bc2]);

    public static readonly Pine.Core.PineValue List_3873c51a =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_8c3ec5ad]);

    public static readonly Pine.Core.PineValue List_0a42aae6 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_1c8d7ab5]);

    public static readonly Pine.Core.PineValue List_4523c4ba =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_8d087e65]);

    public static readonly Pine.Core.PineValue List_9b120256 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_9ec486cd]);

    public static readonly Pine.Core.PineValue List_812d99b3 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_6f43c67d]);

    public static readonly Pine.Core.PineValue List_e609c3f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_1d374f35]);

    public static readonly Pine.Core.PineValue List_fe772476 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_2d6356a2]);

    public static readonly Pine.Core.PineValue List_af278ce0 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_f9f39fec]);

    public static readonly Pine.Core.PineValue List_24a01a94 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_d56d288f]);

    public static readonly Pine.Core.PineValue List_fe2319f6 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_5ed70eaf]);

    public static readonly Pine.Core.PineValue List_80491b1d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4cc842d0]);

    public static readonly Pine.Core.PineValue List_Single_List_fe772476 =
        Pine.Core.PineValue.List(
            [List_fe772476]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_fe772476 =
        Pine.Core.PineValue.List(
            [List_Single_List_fe772476]);

    public static readonly Pine.Core.PineValue List_6a0ea7a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c96ff444]);

    public static readonly Pine.Core.PineValue List_0ff05915 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8ede81db]);

    public static readonly Pine.Core.PineValue List_85d9e8e7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9ccdb191]);

    public static readonly Pine.Core.PineValue List_d766d462 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d871e219]);

    public static readonly Pine.Core.PineValue List_0f57ab74 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2a20fde4]);

    public static readonly Pine.Core.PineValue List_679d82ba =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_0910978f]);

    public static readonly Pine.Core.PineValue List_05cd5327 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_5ff4573d]);

    public static readonly Pine.Core.PineValue List_b273ca6e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_62c9c6c5]);

    public static readonly Pine.Core.PineValue List_142a1a25 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c8ce1e23]);

    public static readonly Pine.Core.PineValue List_a70b19c4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3e2edc8f]);

    public static readonly Pine.Core.PineValue List_73ef2378 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_4fb806b3]);

    public static readonly Pine.Core.PineValue List_e53e9917 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_27222e0d]);

    public static readonly Pine.Core.PineValue List_ffb62471 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_fe772476]);

    public static readonly Pine.Core.PineValue List_b929e186 =
        Pine.Core.PineValue.List(
            [Blob_Str_bit_shift_right, List_a9d4a80f]);

    public static readonly Pine.Core.PineValue List_1a4e9839 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f01d9003]);

    public static readonly Pine.Core.PineValue List_402fa2b4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_5f16dbfc]);

    public static readonly Pine.Core.PineValue List_595202e7 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_2a20fde4]);

    public static readonly Pine.Core.PineValue List_db448c5f =
        Pine.Core.PineValue.List(
            [List_43b95777, List_2a20fde4]);

    public static readonly Pine.Core.PineValue List_3f16d529 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_0910978f]);

    public static readonly Pine.Core.PineValue List_05867a60 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_5ff4573d]);

    public static readonly Pine.Core.PineValue List_d9e2cd23 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_2a20fde4]);

    public static readonly Pine.Core.PineValue List_fb9d2e08 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_2a20fde4]);

    public static readonly Pine.Core.PineValue List_Single_List_595202e7 =
        Pine.Core.PineValue.List(
            [List_595202e7]);

    public static readonly Pine.Core.PineValue List_Single_List_db448c5f =
        Pine.Core.PineValue.List(
            [List_db448c5f]);

    public static readonly Pine.Core.PineValue List_Single_List_3f16d529 =
        Pine.Core.PineValue.List(
            [List_3f16d529]);

    public static readonly Pine.Core.PineValue List_Single_List_05867a60 =
        Pine.Core.PineValue.List(
            [List_05867a60]);

    public static readonly Pine.Core.PineValue List_Single_List_d9e2cd23 =
        Pine.Core.PineValue.List(
            [List_d9e2cd23]);

    public static readonly Pine.Core.PineValue List_Single_List_fb9d2e08 =
        Pine.Core.PineValue.List(
            [List_fb9d2e08]);

    public static readonly Pine.Core.PineValue List_d46b5c67 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_4d3b6f7f]);

    public static readonly Pine.Core.PineValue List_f033d1a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_affeafd7]);

    public static readonly Pine.Core.PineValue List_68fb05d5 =
        Pine.Core.PineValue.List(
            [Blob_Str_negate, List_6a0ea7a9]);

    public static readonly Pine.Core.PineValue List_ba30935e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3981b96a]);

    public static readonly Pine.Core.PineValue List_820f62d2 =
        Pine.Core.PineValue.List(
            [List_99b8e21f, List_596f69a3]);

    public static readonly Pine.Core.PineValue List_fcdf73fe =
        Pine.Core.PineValue.List(
            [List_1adbc696, List_596f69a3]);

    public static readonly Pine.Core.PineValue List_857ce55e =
        Pine.Core.PineValue.List(
            [List_4d678e38, List_596f69a3]);

    public static readonly Pine.Core.PineValue List_Single_List_820f62d2 =
        Pine.Core.PineValue.List(
            [List_820f62d2]);

    public static readonly Pine.Core.PineValue List_Single_List_fcdf73fe =
        Pine.Core.PineValue.List(
            [List_fcdf73fe]);

    public static readonly Pine.Core.PineValue List_Single_List_857ce55e =
        Pine.Core.PineValue.List(
            [List_857ce55e]);

    public static readonly Pine.Core.PineValue List_e29cf251 =
        Pine.Core.PineValue.List(
            [List_e609c3f7, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_b91fb51b =
        Pine.Core.PineValue.List(
            [List_80491b1d, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_Single_List_e29cf251 =
        Pine.Core.PineValue.List(
            [List_e29cf251]);

    public static readonly Pine.Core.PineValue List_Single_List_b91fb51b =
        Pine.Core.PineValue.List(
            [List_b91fb51b]);

    public static readonly Pine.Core.PineValue List_1a2b5777 =
        Pine.Core.PineValue.List(
            [List_f1126ab7, List_b1530ee5]);

    public static readonly Pine.Core.PineValue List_2adfb4d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_595202e7]);

    public static readonly Pine.Core.PineValue List_ce82fd26 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_db448c5f]);

    public static readonly Pine.Core.PineValue List_dbf0d640 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3f16d529]);

    public static readonly Pine.Core.PineValue List_f42f8d01 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_05867a60]);

    public static readonly Pine.Core.PineValue List_43a0500c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d9e2cd23]);

    public static readonly Pine.Core.PineValue List_5e595ef0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fb9d2e08]);

    public static readonly Pine.Core.PineValue List_c88b942a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2102b77e]);

    public static readonly Pine.Core.PineValue List_d0698c30 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0bc76b59]);

    public static readonly Pine.Core.PineValue List_b5d4188c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_89f7e4e4]);

    public static readonly Pine.Core.PineValue List_534540da =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ff537757]);

    public static readonly Pine.Core.PineValue List_abb731bd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_13ac85b3]);

    public static readonly Pine.Core.PineValue List_98c18bfa =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_673e4d01]);

    public static readonly Pine.Core.PineValue List_ddf7fc1c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_09da05b0]);

    public static readonly Pine.Core.PineValue List_a22f03df =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bae6cac0]);

    public static readonly Pine.Core.PineValue List_2ca5e701 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_206eacc3]);

    public static readonly Pine.Core.PineValue List_3c873ec4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b18f964f]);

    public static readonly Pine.Core.PineValue List_c78b4c00 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f7ad2307]);

    public static readonly Pine.Core.PineValue List_04720006 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_ffb3657e]);

    public static readonly Pine.Core.PineValue List_Single_List_04720006 =
        Pine.Core.PineValue.List(
            [List_04720006]);

    public static readonly Pine.Core.PineValue List_f01ccf80 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8baea653]);

    public static readonly Pine.Core.PineValue List_b324b656 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_820f62d2]);

    public static readonly Pine.Core.PineValue List_a4b0ba97 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fcdf73fe]);

    public static readonly Pine.Core.PineValue List_53a6fb87 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_857ce55e]);

    public static readonly Pine.Core.PineValue List_ec4da5db =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e29cf251]);

    public static readonly Pine.Core.PineValue List_2469bd07 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b91fb51b]);

    public static readonly Pine.Core.PineValue List_7b6856d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f48d98d2]);

    public static readonly Pine.Core.PineValue List_52fe4ebd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8319f06f]);

    public static readonly Pine.Core.PineValue List_40007240 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_770c8d31]);

    public static readonly Pine.Core.PineValue List_66f15e7d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d9a8bf69]);

    public static readonly Pine.Core.PineValue List_fc312819 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6ad75546]);

    public static readonly Pine.Core.PineValue List_5fd176c9 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_baac9ffb]);

    public static readonly Pine.Core.PineValue List_58e3388d =
        Pine.Core.PineValue.List(
            [List_976730e9, List_bfd00849]);

    public static readonly Pine.Core.PineValue List_ce7f9fc1 =
        Pine.Core.PineValue.List(
            [List_ad18d3d3, List_ffb3657e]);

    public static readonly Pine.Core.PineValue List_Single_List_ce7f9fc1 =
        Pine.Core.PineValue.List(
            [List_ce7f9fc1]);

    public static readonly Pine.Core.PineValue List_d61ec4ce =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c88b942a]);

    public static readonly Pine.Core.PineValue List_ab8a69c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_d0698c30]);

    public static readonly Pine.Core.PineValue List_91f9edc1 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_b5d4188c]);

    public static readonly Pine.Core.PineValue List_f7a33c0e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_534540da]);

    public static readonly Pine.Core.PineValue List_4b2732e7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_abb731bd]);

    public static readonly Pine.Core.PineValue List_e46638fd =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_98c18bfa]);

    public static readonly Pine.Core.PineValue List_6ac25a38 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ddf7fc1c]);

    public static readonly Pine.Core.PineValue List_b655c855 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a22f03df]);

    public static readonly Pine.Core.PineValue List_8479e2bd =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_2adfb4d8]);

    public static readonly Pine.Core.PineValue List_70f5d900 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_ce82fd26]);

    public static readonly Pine.Core.PineValue List_98f3bf04 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_dbf0d640]);

    public static readonly Pine.Core.PineValue List_463af270 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_f42f8d01]);

    public static readonly Pine.Core.PineValue List_161aa3e3 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_43a0500c]);

    public static readonly Pine.Core.PineValue List_58f3b9a8 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_5e595ef0]);

    public static readonly Pine.Core.PineValue List_9eca7ab0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2fc6c58a]);

    public static readonly Pine.Core.PineValue List_40dce4c9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_04720006]);

    public static readonly Pine.Core.PineValue List_f87f6843 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c9704e9c]);

    public static readonly Pine.Core.PineValue List_9aed9073 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7ad89f45]);

    public static readonly Pine.Core.PineValue List_49eff0fb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6840e7e9]);

    public static readonly Pine.Core.PineValue List_0218d8fb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_354c0c42]);

    public static readonly Pine.Core.PineValue List_a872793e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a808e609]);

    public static readonly Pine.Core.PineValue List_5df552c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3873c51a]);

    public static readonly Pine.Core.PineValue List_d219d6b8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0a42aae6]);

    public static readonly Pine.Core.PineValue List_3e03e978 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4523c4ba]);

    public static readonly Pine.Core.PineValue List_a9acb40e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9b120256]);

    public static readonly Pine.Core.PineValue List_31f795f9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_812d99b3]);

    public static readonly Pine.Core.PineValue List_9862e7a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_b324b656]);

    public static readonly Pine.Core.PineValue List_d4eacb79 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a4b0ba97]);

    public static readonly Pine.Core.PineValue List_4c7605a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_53a6fb87]);

    public static readonly Pine.Core.PineValue List_994dea27 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2469bd07]);

    public static readonly Pine.Core.PineValue List_4717bb9a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ce7f9fc1]);

    public static readonly Pine.Core.PineValue List_8799f419 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0f57ab74]);

    public static readonly Pine.Core.PineValue List_85a158ff =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_679d82ba]);

    public static readonly Pine.Core.PineValue List_925d8478 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_05cd5327]);

    public static readonly Pine.Core.PineValue List_82113c5f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b273ca6e]);

    public static readonly Pine.Core.PineValue List_Single_List_8799f419 =
        Pine.Core.PineValue.List(
            [List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_8799f419 =
        Pine.Core.PineValue.List(
            [List_Single_List_8799f419]);

    public static readonly Pine.Core.PineValue List_1004f2a5 =
        Pine.Core.PineValue.List(
            [List_0ff05915, List_cd5e9e27, List_45564a6a]);

    public static readonly Pine.Core.PineValue List_2885d797 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_40dce4c9]);

    public static readonly Pine.Core.PineValue List_7e881476 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_1a2b5777]);

    public static readonly Pine.Core.PineValue List_777aa93d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b929e186]);

    public static readonly Pine.Core.PineValue List_b1ba27e4 =
        Pine.Core.PineValue.List(
            [List_d0b6bef5, List_66f15e7d]);

    public static readonly Pine.Core.PineValue List_Single_List_b1ba27e4 =
        Pine.Core.PineValue.List(
            [List_b1ba27e4]);

    public static readonly Pine.Core.PineValue List_4f6bc250 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_ffb3657e]);

    public static readonly Pine.Core.PineValue List_8f4c0899 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_de173be4]);

    public static readonly Pine.Core.PineValue List_833e20da =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_596f69a3]);

    public static readonly Pine.Core.PineValue List_c6d1dd59 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_2595e97f]);

    public static readonly Pine.Core.PineValue List_08c40c8b =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_f088da70]);

    public static readonly Pine.Core.PineValue List_ca64e8e1 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_610179c6]);

    public static readonly Pine.Core.PineValue List_Single_List_4f6bc250 =
        Pine.Core.PineValue.List(
            [List_4f6bc250]);

    public static readonly Pine.Core.PineValue List_Single_List_8f4c0899 =
        Pine.Core.PineValue.List(
            [List_8f4c0899]);

    public static readonly Pine.Core.PineValue List_Single_List_833e20da =
        Pine.Core.PineValue.List(
            [List_833e20da]);

    public static readonly Pine.Core.PineValue List_Single_List_c6d1dd59 =
        Pine.Core.PineValue.List(
            [List_c6d1dd59]);

    public static readonly Pine.Core.PineValue List_Single_List_08c40c8b =
        Pine.Core.PineValue.List(
            [List_08c40c8b]);

    public static readonly Pine.Core.PineValue List_Single_List_ca64e8e1 =
        Pine.Core.PineValue.List(
            [List_ca64e8e1]);

    public static readonly Pine.Core.PineValue List_32dabd2b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_8799f419]);

    public static readonly Pine.Core.PineValue List_c42737be =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d46b5c67]);

    public static readonly Pine.Core.PineValue List_046b8932 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f033d1a5]);

    public static readonly Pine.Core.PineValue List_26563753 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_8799f419]);

    public static readonly Pine.Core.PineValue List_6467391b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_68fb05d5]);

    public static readonly Pine.Core.PineValue List_f1143e1d =
        Pine.Core.PineValue.List(
            [List_f751324e, List_ffb3657e]);

    public static readonly Pine.Core.PineValue List_c2c5e7da =
        Pine.Core.PineValue.List(
            [List_f751324e, List_de173be4]);

    public static readonly Pine.Core.PineValue List_Single_List_f1143e1d =
        Pine.Core.PineValue.List(
            [List_f1143e1d]);

    public static readonly Pine.Core.PineValue List_Single_List_c2c5e7da =
        Pine.Core.PineValue.List(
            [List_c2c5e7da]);

    public static readonly Pine.Core.PineValue List_f70b5d52 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_4717bb9a]);

    public static readonly Pine.Core.PineValue List_b89cb472 =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_8799f419]);

    public static readonly Pine.Core.PineValue List_8068f6f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_5fd176c9]);

    public static readonly Pine.Core.PineValue List_0b37ace8 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_58e3388d]);

    public static readonly Pine.Core.PineValue List_4eac3b9e =
        Pine.Core.PineValue.List(
            [List_db582731, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_55a6d783 =
        Pine.Core.PineValue.List(
            [List_db582731, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_a5a9b04f =
        Pine.Core.PineValue.List(
            [List_db582731, List_a71e519b]);

    public static readonly Pine.Core.PineValue List_d003d670 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b1ba27e4]);

    public static readonly Pine.Core.PineValue List_ff3d75c9 =
        Pine.Core.PineValue.List(
            [List_56404869, List_8799f419]);

    public static readonly Pine.Core.PineValue List_9789176a =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_ff3d75c9 =
        Pine.Core.PineValue.List(
            [List_ff3d75c9]);

    public static readonly Pine.Core.PineValue List_Single_List_9789176a =
        Pine.Core.PineValue.List(
            [List_9789176a]);

    public static readonly Pine.Core.PineValue List_7425a542 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4f6bc250]);

    public static readonly Pine.Core.PineValue List_b4b1c59e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f4c0899]);

    public static readonly Pine.Core.PineValue List_59fee864 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_833e20da]);

    public static readonly Pine.Core.PineValue List_a15cd850 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c6d1dd59]);

    public static readonly Pine.Core.PineValue List_ca6cf1a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_08c40c8b]);

    public static readonly Pine.Core.PineValue List_a98295db =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ca64e8e1]);

    public static readonly Pine.Core.PineValue List_62e16c6a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f1143e1d]);

    public static readonly Pine.Core.PineValue List_baf6794c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c2c5e7da]);

    public static readonly Pine.Core.PineValue List_54b5d8d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_ec4da5db]);

    public static readonly Pine.Core.PineValue List_d6a4b8d3 =
        Pine.Core.PineValue.List(
            [List_d0b6bef5, List_777aa93d]);

    public static readonly Pine.Core.PineValue List_Single_List_d6a4b8d3 =
        Pine.Core.PineValue.List(
            [List_d6a4b8d3]);

    public static readonly Pine.Core.PineValue List_f6b501fb =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_162ee665 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_037c832d =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_039fa762 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_c9162e88 =
        Pine.Core.PineValue.List(
            [List_34849c45, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_88b4c3d4 =
        Pine.Core.PineValue.List(
            [List_34849c45, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_Single_List_f6b501fb =
        Pine.Core.PineValue.List(
            [List_f6b501fb]);

    public static readonly Pine.Core.PineValue List_Single_List_162ee665 =
        Pine.Core.PineValue.List(
            [List_162ee665]);

    public static readonly Pine.Core.PineValue List_Single_List_037c832d =
        Pine.Core.PineValue.List(
            [List_037c832d]);

    public static readonly Pine.Core.PineValue List_Single_List_039fa762 =
        Pine.Core.PineValue.List(
            [List_039fa762]);

    public static readonly Pine.Core.PineValue List_Single_List_c9162e88 =
        Pine.Core.PineValue.List(
            [List_c9162e88]);

    public static readonly Pine.Core.PineValue List_Single_List_88b4c3d4 =
        Pine.Core.PineValue.List(
            [List_88b4c3d4]);

    public static readonly Pine.Core.PineValue List_a9521d08 =
        Pine.Core.PineValue.List(
            [List_2ca5e701, List_cd5e9e27, List_45564a6a]);

    public static readonly Pine.Core.PineValue List_6e0fabaf =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ff3d75c9]);

    public static readonly Pine.Core.PineValue List_b7351701 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9789176a]);

    public static readonly Pine.Core.PineValue List_1da3871f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d61ec4ce]);

    public static readonly Pine.Core.PineValue List_1fd0a7ec =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ab8a69c6]);

    public static readonly Pine.Core.PineValue List_17d1a6b3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_91f9edc1]);

    public static readonly Pine.Core.PineValue List_32f28aea =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f7a33c0e]);

    public static readonly Pine.Core.PineValue List_606eb286 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4b2732e7]);

    public static readonly Pine.Core.PineValue List_ebff857e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e46638fd]);

    public static readonly Pine.Core.PineValue List_6cab91e9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6ac25a38]);

    public static readonly Pine.Core.PineValue List_1c80da68 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b655c855]);

    public static readonly Pine.Core.PineValue List_2bd6ac0a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8479e2bd]);

    public static readonly Pine.Core.PineValue List_5b4cf3a4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_70f5d900]);

    public static readonly Pine.Core.PineValue List_7f4d99c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_98f3bf04]);

    public static readonly Pine.Core.PineValue List_585c20f1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_463af270]);

    public static readonly Pine.Core.PineValue List_ba221580 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_161aa3e3]);

    public static readonly Pine.Core.PineValue List_fe232d5c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_58f3b9a8]);

    public static readonly Pine.Core.PineValue List_05bb98be =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_1004f2a5]);

    public static readonly Pine.Core.PineValue List_ace4d308 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_7425a542]);

    public static readonly Pine.Core.PineValue List_2d6da7e5 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_b4b1c59e]);

    public static readonly Pine.Core.PineValue List_9f7a7cd7 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_59fee864]);

    public static readonly Pine.Core.PineValue List_b0ddd955 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a15cd850]);

    public static readonly Pine.Core.PineValue List_0cab55af =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_ca6cf1a9]);

    public static readonly Pine.Core.PineValue List_cc5a2385 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a98295db]);

    public static readonly Pine.Core.PineValue List_abba545a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_62e16c6a]);

    public static readonly Pine.Core.PineValue List_ea63c8b4 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_baf6794c]);

    public static readonly Pine.Core.PineValue List_3318278d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d6a4b8d3]);

    public static readonly Pine.Core.PineValue List_e79e127e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9862e7a9]);

    public static readonly Pine.Core.PineValue List_deeafbf1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d4eacb79]);

    public static readonly Pine.Core.PineValue List_57c5f356 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4c7605a3]);

    public static readonly Pine.Core.PineValue List_9dc6ec10 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_994dea27]);

    public static readonly Pine.Core.PineValue List_393b2916 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f6b501fb]);

    public static readonly Pine.Core.PineValue List_5f35ef89 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_162ee665]);

    public static readonly Pine.Core.PineValue List_282fb064 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_037c832d]);

    public static readonly Pine.Core.PineValue List_97774c0f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_039fa762]);

    public static readonly Pine.Core.PineValue List_bdc1e95c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c9162e88]);

    public static readonly Pine.Core.PineValue List_29bdeb39 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_88b4c3d4]);

    public static readonly Pine.Core.PineValue List_def35774 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_b978ab71 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1fd0a7ec]);

    public static readonly Pine.Core.PineValue List_15a46a83 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_17d1a6b3]);

    public static readonly Pine.Core.PineValue List_f85d63b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_32f28aea]);

    public static readonly Pine.Core.PineValue List_847799d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_606eb286]);

    public static readonly Pine.Core.PineValue List_ecbca41e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ebff857e]);

    public static readonly Pine.Core.PineValue List_f1bcf698 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2bd6ac0a]);

    public static readonly Pine.Core.PineValue List_892ac20b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_5b4cf3a4]);

    public static readonly Pine.Core.PineValue List_768921f8 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_7f4d99c6]);

    public static readonly Pine.Core.PineValue List_7ea52643 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_585c20f1]);

    public static readonly Pine.Core.PineValue List_6bfa79d5 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ba221580]);

    public static readonly Pine.Core.PineValue List_5ab2613e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_fe232d5c]);

    public static readonly Pine.Core.PineValue List_7efafede =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_4eac3b9e]);

    public static readonly Pine.Core.PineValue List_3f936680 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_55a6d783]);

    public static readonly Pine.Core.PineValue List_85bff313 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a5a9b04f]);

    public static readonly Pine.Core.PineValue List_f81f258c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2885d797]);

    public static readonly Pine.Core.PineValue List_8a385b2d =
        Pine.Core.PineValue.List(
            [List_976730e9, List_604d4279]);

    public static readonly Pine.Core.PineValue List_1aabcf9b =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_86d38b8d, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_cd1eb242 =
        Pine.Core.PineValue.List(
            [List_96cfcb00, List_35cf017c, List_56404869]);

    public static readonly Pine.Core.PineValue List_Single_List_1aabcf9b =
        Pine.Core.PineValue.List(
            [List_1aabcf9b]);

    public static readonly Pine.Core.PineValue List_Single_List_cd1eb242 =
        Pine.Core.PineValue.List(
            [List_cd1eb242]);

    public static readonly Pine.Core.PineValue List_b1ea9fed =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_6e0fabaf]);

    public static readonly Pine.Core.PineValue List_43ac8eb1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_32dabd2b]);

    public static readonly Pine.Core.PineValue List_b4b50f0d =
        Pine.Core.PineValue.List(
            [List_bc0ffa85, List_c0abcf7c]);

    public static readonly Pine.Core.PineValue List_Single_List_b4b50f0d =
        Pine.Core.PineValue.List(
            [List_b4b50f0d]);

    public static readonly Pine.Core.PineValue List_e5afd133 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_282fb064]);

    public static readonly Pine.Core.PineValue List_954801a6 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_29bdeb39]);

    public static readonly Pine.Core.PineValue List_5482cbd9 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_3318278d]);

    public static readonly Pine.Core.PineValue List_52f39464 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_88598e13 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_1fd0a7ec]);

    public static readonly Pine.Core.PineValue List_ed69165c =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_17d1a6b3]);

    public static readonly Pine.Core.PineValue List_824c9e81 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_32f28aea]);

    public static readonly Pine.Core.PineValue List_6df4a3d6 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_606eb286]);

    public static readonly Pine.Core.PineValue List_e3f06f32 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_3df96b30 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_1fd0a7ec]);

    public static readonly Pine.Core.PineValue List_55244944 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_17d1a6b3]);

    public static readonly Pine.Core.PineValue List_b83b4832 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_32f28aea]);

    public static readonly Pine.Core.PineValue List_622102a4 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_606eb286]);

    public static readonly Pine.Core.PineValue List_83632eda =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_e3e47ce9 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_1fd0a7ec]);

    public static readonly Pine.Core.PineValue List_44d7de34 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_17d1a6b3]);

    public static readonly Pine.Core.PineValue List_2f586336 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_32f28aea]);

    public static readonly Pine.Core.PineValue List_4d2af7e0 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_606eb286]);

    public static readonly Pine.Core.PineValue List_e0d900a3 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_ebff857e]);

    public static readonly Pine.Core.PineValue List_583c861d =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_2b5f3983 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_1fd0a7ec]);

    public static readonly Pine.Core.PineValue List_cd4e169f =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_17d1a6b3]);

    public static readonly Pine.Core.PineValue List_83165e04 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_32f28aea]);

    public static readonly Pine.Core.PineValue List_0a1369a8 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_606eb286]);

    public static readonly Pine.Core.PineValue List_Single_List_52f39464 =
        Pine.Core.PineValue.List(
            [List_52f39464]);

    public static readonly Pine.Core.PineValue List_Single_List_88598e13 =
        Pine.Core.PineValue.List(
            [List_88598e13]);

    public static readonly Pine.Core.PineValue List_Single_List_ed69165c =
        Pine.Core.PineValue.List(
            [List_ed69165c]);

    public static readonly Pine.Core.PineValue List_Single_List_824c9e81 =
        Pine.Core.PineValue.List(
            [List_824c9e81]);

    public static readonly Pine.Core.PineValue List_Single_List_6df4a3d6 =
        Pine.Core.PineValue.List(
            [List_6df4a3d6]);

    public static readonly Pine.Core.PineValue List_Single_List_e3f06f32 =
        Pine.Core.PineValue.List(
            [List_e3f06f32]);

    public static readonly Pine.Core.PineValue List_Single_List_3df96b30 =
        Pine.Core.PineValue.List(
            [List_3df96b30]);

    public static readonly Pine.Core.PineValue List_Single_List_55244944 =
        Pine.Core.PineValue.List(
            [List_55244944]);

    public static readonly Pine.Core.PineValue List_Single_List_b83b4832 =
        Pine.Core.PineValue.List(
            [List_b83b4832]);

    public static readonly Pine.Core.PineValue List_Single_List_622102a4 =
        Pine.Core.PineValue.List(
            [List_622102a4]);

    public static readonly Pine.Core.PineValue List_Single_List_83632eda =
        Pine.Core.PineValue.List(
            [List_83632eda]);

    public static readonly Pine.Core.PineValue List_Single_List_e3e47ce9 =
        Pine.Core.PineValue.List(
            [List_e3e47ce9]);

    public static readonly Pine.Core.PineValue List_Single_List_44d7de34 =
        Pine.Core.PineValue.List(
            [List_44d7de34]);

    public static readonly Pine.Core.PineValue List_Single_List_2f586336 =
        Pine.Core.PineValue.List(
            [List_2f586336]);

    public static readonly Pine.Core.PineValue List_Single_List_4d2af7e0 =
        Pine.Core.PineValue.List(
            [List_4d2af7e0]);

    public static readonly Pine.Core.PineValue List_Single_List_e0d900a3 =
        Pine.Core.PineValue.List(
            [List_e0d900a3]);

    public static readonly Pine.Core.PineValue List_Single_List_583c861d =
        Pine.Core.PineValue.List(
            [List_583c861d]);

    public static readonly Pine.Core.PineValue List_Single_List_2b5f3983 =
        Pine.Core.PineValue.List(
            [List_2b5f3983]);

    public static readonly Pine.Core.PineValue List_Single_List_cd4e169f =
        Pine.Core.PineValue.List(
            [List_cd4e169f]);

    public static readonly Pine.Core.PineValue List_Single_List_83165e04 =
        Pine.Core.PineValue.List(
            [List_83165e04]);

    public static readonly Pine.Core.PineValue List_Single_List_0a1369a8 =
        Pine.Core.PineValue.List(
            [List_0a1369a8]);

    public static readonly Pine.Core.PineValue List_d84e947d =
        Pine.Core.PineValue.List(
            [Blob_Str_negate, List_9dc6ec10]);

    public static readonly Pine.Core.PineValue List_11e84499 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f70b5d52]);

    public static readonly Pine.Core.PineValue List_134d2bc4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b89cb472]);

    public static readonly Pine.Core.PineValue List_36b880a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_bdc1e95c]);

    public static readonly Pine.Core.PineValue List_be815d84 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a9521d08]);

    public static readonly Pine.Core.PineValue List_8c46c627 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1aabcf9b]);

    public static readonly Pine.Core.PineValue List_ddc25906 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cd1eb242]);

    public static readonly Pine.Core.PineValue List_3dc9c9d1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b4b50f0d]);

    public static readonly Pine.Core.PineValue List_0fe7ddcf =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_52f39464]);

    public static readonly Pine.Core.PineValue List_0fc264fc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_88598e13]);

    public static readonly Pine.Core.PineValue List_dbe1de7f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ed69165c]);

    public static readonly Pine.Core.PineValue List_b2e51baa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_824c9e81]);

    public static readonly Pine.Core.PineValue List_b4f40ae1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6df4a3d6]);

    public static readonly Pine.Core.PineValue List_42c73090 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e3f06f32]);

    public static readonly Pine.Core.PineValue List_d4bb20ba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3df96b30]);

    public static readonly Pine.Core.PineValue List_3672794e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_55244944]);

    public static readonly Pine.Core.PineValue List_a0d10a7a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b83b4832]);

    public static readonly Pine.Core.PineValue List_b8da4293 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_622102a4]);

    public static readonly Pine.Core.PineValue List_b05b3490 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_83632eda]);

    public static readonly Pine.Core.PineValue List_5dcb8c94 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e3e47ce9]);

    public static readonly Pine.Core.PineValue List_b8fb56a2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_44d7de34]);

    public static readonly Pine.Core.PineValue List_22ec8bb7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2f586336]);

    public static readonly Pine.Core.PineValue List_089580a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4d2af7e0]);

    public static readonly Pine.Core.PineValue List_62e91f11 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e0d900a3]);

    public static readonly Pine.Core.PineValue List_6297a7f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_583c861d]);

    public static readonly Pine.Core.PineValue List_98571722 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2b5f3983]);

    public static readonly Pine.Core.PineValue List_721b4c51 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cd4e169f]);

    public static readonly Pine.Core.PineValue List_031cf20f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_83165e04]);

    public static readonly Pine.Core.PineValue List_de2dc2b2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0a1369a8]);

    public static readonly Pine.Core.PineValue List_8f7015ea =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_54b5d8d8]);

    public static readonly Pine.Core.PineValue List_b9088cc3 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_12173aa2]);

    public static readonly Pine.Core.PineValue List_be37996c =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_baac9ffb]);

    public static readonly Pine.Core.PineValue List_d76d5211 =
        Pine.Core.PineValue.List(
            [List_bc0ffa85, List_a3acbbf8]);

    public static readonly Pine.Core.PineValue List_74f707c0 =
        Pine.Core.PineValue.List(
            [List_bc0ffa85, List_cc1aecae]);

    public static readonly Pine.Core.PineValue List_Single_List_d76d5211 =
        Pine.Core.PineValue.List(
            [List_d76d5211]);

    public static readonly Pine.Core.PineValue List_Single_List_74f707c0 =
        Pine.Core.PineValue.List(
            [List_74f707c0]);

    public static readonly Pine.Core.PineValue List_1da9cb1a =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_0fe7ddcf]);

    public static readonly Pine.Core.PineValue List_ce5f9eb8 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_0fc264fc]);

    public static readonly Pine.Core.PineValue List_0ca3caaf =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_dbe1de7f]);

    public static readonly Pine.Core.PineValue List_ddd209ba =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b2e51baa]);

    public static readonly Pine.Core.PineValue List_a38cc497 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b4f40ae1]);

    public static readonly Pine.Core.PineValue List_97d7e580 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_42c73090]);

    public static readonly Pine.Core.PineValue List_ae7aa55b =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_d4bb20ba]);

    public static readonly Pine.Core.PineValue List_fd78effe =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_3672794e]);

    public static readonly Pine.Core.PineValue List_071ec652 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a0d10a7a]);

    public static readonly Pine.Core.PineValue List_6f3a37d1 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b8da4293]);

    public static readonly Pine.Core.PineValue List_859c3d33 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b05b3490]);

    public static readonly Pine.Core.PineValue List_6b31cf52 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_5dcb8c94]);

    public static readonly Pine.Core.PineValue List_d4c9c9f5 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b8fb56a2]);

    public static readonly Pine.Core.PineValue List_3ac4d789 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_22ec8bb7]);

    public static readonly Pine.Core.PineValue List_b6e56a5e =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_089580a3]);

    public static readonly Pine.Core.PineValue List_d2ee54ad =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_62e91f11]);

    public static readonly Pine.Core.PineValue List_50b9d951 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_6297a7f4]);

    public static readonly Pine.Core.PineValue List_f71f7a8b =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_98571722]);

    public static readonly Pine.Core.PineValue List_f1870c13 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_721b4c51]);

    public static readonly Pine.Core.PineValue List_35a4a134 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_031cf20f]);

    public static readonly Pine.Core.PineValue List_4c82a74d =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_de2dc2b2]);

    public static readonly Pine.Core.PineValue List_c0210a02 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ace4d308]);

    public static readonly Pine.Core.PineValue List_e349ba15 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2d6da7e5]);

    public static readonly Pine.Core.PineValue List_40975626 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9f7a7cd7]);

    public static readonly Pine.Core.PineValue List_0331bb71 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b0ddd955]);

    public static readonly Pine.Core.PineValue List_bbd76f00 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0cab55af]);

    public static readonly Pine.Core.PineValue List_65f3484c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cc5a2385]);

    public static readonly Pine.Core.PineValue List_dc74ad16 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_ddc25906]);

    public static readonly Pine.Core.PineValue List_ff977232 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_8a385b2d]);

    public static readonly Pine.Core.PineValue List_754ca20c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_abba545a]);

    public static readonly Pine.Core.PineValue List_ee9cff15 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ea63c8b4]);

    public static readonly Pine.Core.PineValue List_c1dbb369 =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_43ac8eb1]);

    public static readonly Pine.Core.PineValue List_Single_List_c1dbb369 =
        Pine.Core.PineValue.List(
            [List_c1dbb369]);

    public static readonly Pine.Core.PineValue List_e4fdbb4a =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_5f35ef89]);

    public static readonly Pine.Core.PineValue List_fcae4a4b =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_282fb064]);

    public static readonly Pine.Core.PineValue List_0347b797 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_97774c0f]);

    public static readonly Pine.Core.PineValue List_929c9d51 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d76d5211]);

    public static readonly Pine.Core.PineValue List_097a386d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_74f707c0]);

    public static readonly Pine.Core.PineValue List_12df02f3 =
        Pine.Core.PineValue.List(
            [List_887c794a, List_43ac8eb1]);

    public static readonly Pine.Core.PineValue List_Single_List_12df02f3 =
        Pine.Core.PineValue.List(
            [List_12df02f3]);

    public static readonly Pine.Core.PineValue List_908ec70a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_def35774]);

    public static readonly Pine.Core.PineValue List_1e3edf76 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b978ab71]);

    public static readonly Pine.Core.PineValue List_6aa5c3cc =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_15a46a83]);

    public static readonly Pine.Core.PineValue List_43da2098 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f85d63b9]);

    public static readonly Pine.Core.PineValue List_72133849 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_847799d4]);

    public static readonly Pine.Core.PineValue List_8b600da6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ecbca41e]);

    public static readonly Pine.Core.PineValue List_fe634606 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f1bcf698]);

    public static readonly Pine.Core.PineValue List_8e784b64 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_892ac20b]);

    public static readonly Pine.Core.PineValue List_be509776 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_768921f8]);

    public static readonly Pine.Core.PineValue List_2f1cd3eb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7ea52643]);

    public static readonly Pine.Core.PineValue List_918ce5b6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6bfa79d5]);

    public static readonly Pine.Core.PineValue List_7e084b53 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5ab2613e]);

    public static readonly Pine.Core.PineValue List_Single_List_908ec70a =
        Pine.Core.PineValue.List(
            [List_908ec70a]);

    public static readonly Pine.Core.PineValue List_Single_List_fe634606 =
        Pine.Core.PineValue.List(
            [List_fe634606]);

    public static readonly Pine.Core.PineValue List_Single_List_918ce5b6 =
        Pine.Core.PineValue.List(
            [List_918ce5b6]);

    public static readonly Pine.Core.PineValue List_Single_List_7e084b53 =
        Pine.Core.PineValue.List(
            [List_7e084b53]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_908ec70a =
        Pine.Core.PineValue.List(
            [List_Single_List_908ec70a]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_fe634606 =
        Pine.Core.PineValue.List(
            [List_Single_List_fe634606]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_918ce5b6 =
        Pine.Core.PineValue.List(
            [List_Single_List_918ce5b6]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_7e084b53 =
        Pine.Core.PineValue.List(
            [List_Single_List_7e084b53]);

    public static readonly Pine.Core.PineValue List_41a68dd1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c1dbb369]);

    public static readonly Pine.Core.PineValue List_d41904f0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b1ea9fed]);

    public static readonly Pine.Core.PineValue List_Single_List_d41904f0 =
        Pine.Core.PineValue.List(
            [List_d41904f0]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_d41904f0 =
        Pine.Core.PineValue.List(
            [List_Single_List_d41904f0]);

    public static readonly Pine.Core.PineValue List_2820c509 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e5afd133]);

    public static readonly Pine.Core.PineValue List_fec26d68 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_954801a6]);

    public static readonly Pine.Core.PineValue List_0221aff4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5482cbd9]);

    public static readonly Pine.Core.PineValue List_Single_List_0221aff4 =
        Pine.Core.PineValue.List(
            [List_0221aff4]);

    public static readonly Pine.Core.PineValue List_aa66e5be =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_12df02f3]);

    public static readonly Pine.Core.PineValue List_68f4906d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6aa5c3cc]);

    public static readonly Pine.Core.PineValue List_4ff52d72 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_43da2098]);

    public static readonly Pine.Core.PineValue List_cbee86a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_72133849]);

    public static readonly Pine.Core.PineValue List_bce9c711 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_8b600da6]);

    public static readonly Pine.Core.PineValue List_095a660b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_918ce5b6]);

    public static readonly Pine.Core.PineValue List_98a4bcd7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_7e084b53]);

    public static readonly Pine.Core.PineValue List_79ad41ac =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_908ec70a]);

    public static readonly Pine.Core.PineValue List_9cc43055 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_fe634606]);

    public static readonly Pine.Core.PineValue List_a4286e44 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_918ce5b6]);

    public static readonly Pine.Core.PineValue List_2e378702 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_7e084b53]);

    public static readonly Pine.Core.PineValue List_2fecb8a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d84e947d]);

    public static readonly Pine.Core.PineValue List_9d653d49 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_36b880a5]);

    public static readonly Pine.Core.PineValue List_9d528f9d =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_1e3edf76]);

    public static readonly Pine.Core.PineValue List_bb55e443 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_b9088cc3]);

    public static readonly Pine.Core.PineValue List_0705b819 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_be37996c]);

    public static readonly Pine.Core.PineValue List_Single_List_0705b819 =
        Pine.Core.PineValue.List(
            [List_0705b819]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_0705b819 =
        Pine.Core.PineValue.List(
            [List_Single_List_0705b819]);

    public static readonly Pine.Core.PineValue List_ac807715 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_d41904f0]);

    public static readonly Pine.Core.PineValue List_7916b715 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_41a68dd1]);

    public static readonly Pine.Core.PineValue List_9c18825b =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_918ce5b6]);

    public static readonly Pine.Core.PineValue List_205d3be2 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_7e084b53]);

    public static readonly Pine.Core.PineValue List_8f23ae42 =
        Pine.Core.PineValue.List(
            [List_fe634606, List_0dcd86c0]);

    public static readonly Pine.Core.PineValue List_Single_List_9c18825b =
        Pine.Core.PineValue.List(
            [List_9c18825b]);

    public static readonly Pine.Core.PineValue List_Single_List_205d3be2 =
        Pine.Core.PineValue.List(
            [List_205d3be2]);

    public static readonly Pine.Core.PineValue List_Single_List_8f23ae42 =
        Pine.Core.PineValue.List(
            [List_8f23ae42]);

    public static readonly Pine.Core.PineValue List_3ee8b153 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_aa66e5be]);

    public static readonly Pine.Core.PineValue List_f0fceb46 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_0705b819]);

    public static readonly Pine.Core.PineValue List_23e8d21e =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_0221aff4]);

    public static readonly Pine.Core.PineValue List_81929877 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_b217a620 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_989a3a14 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_fe930b2c =
        Pine.Core.PineValue.List(
            [List_768cc61e, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_Single_List_81929877 =
        Pine.Core.PineValue.List(
            [List_81929877]);

    public static readonly Pine.Core.PineValue List_Single_List_b217a620 =
        Pine.Core.PineValue.List(
            [List_b217a620]);

    public static readonly Pine.Core.PineValue List_Single_List_989a3a14 =
        Pine.Core.PineValue.List(
            [List_989a3a14]);

    public static readonly Pine.Core.PineValue List_Single_List_fe930b2c =
        Pine.Core.PineValue.List(
            [List_fe930b2c]);

    public static readonly Pine.Core.PineValue List_b71ec3d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9c18825b]);

    public static readonly Pine.Core.PineValue List_98e0e124 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_205d3be2]);

    public static readonly Pine.Core.PineValue List_b2679444 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f23ae42]);

    public static readonly Pine.Core.PineValue List_922d407b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1da9cb1a]);

    public static readonly Pine.Core.PineValue List_5f115c04 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ce5f9eb8]);

    public static readonly Pine.Core.PineValue List_1b2c35d9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0ca3caaf]);

    public static readonly Pine.Core.PineValue List_8e29b702 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ddd209ba]);

    public static readonly Pine.Core.PineValue List_1612ec6e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a38cc497]);

    public static readonly Pine.Core.PineValue List_61f00d35 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_97d7e580]);

    public static readonly Pine.Core.PineValue List_3d745061 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ae7aa55b]);

    public static readonly Pine.Core.PineValue List_9f0c42bf =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fd78effe]);

    public static readonly Pine.Core.PineValue List_8b9e3057 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_071ec652]);

    public static readonly Pine.Core.PineValue List_b4797819 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6f3a37d1]);

    public static readonly Pine.Core.PineValue List_c4712195 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_859c3d33]);

    public static readonly Pine.Core.PineValue List_4d767988 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6b31cf52]);

    public static readonly Pine.Core.PineValue List_24c67c9d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d4c9c9f5]);

    public static readonly Pine.Core.PineValue List_2097609a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3ac4d789]);

    public static readonly Pine.Core.PineValue List_ef6eabf3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b6e56a5e]);

    public static readonly Pine.Core.PineValue List_a0f394b0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d2ee54ad]);

    public static readonly Pine.Core.PineValue List_847f3c7a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_50b9d951]);

    public static readonly Pine.Core.PineValue List_2e61fa25 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f71f7a8b]);

    public static readonly Pine.Core.PineValue List_37755a2f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f1870c13]);

    public static readonly Pine.Core.PineValue List_1c295777 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_35a4a134]);

    public static readonly Pine.Core.PineValue List_d3e9925c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4c82a74d]);

    public static readonly Pine.Core.PineValue List_7b45cce4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dc74ad16]);

    public static readonly Pine.Core.PineValue List_400282b1 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_7a9bb0f9]);

    public static readonly Pine.Core.PineValue List_985fed4e =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_a6002954]);

    public static readonly Pine.Core.PineValue List_8eb4c1ce =
        Pine.Core.PineValue.List(
            [List_c7049af9, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_Single_List_400282b1 =
        Pine.Core.PineValue.List(
            [List_400282b1]);

    public static readonly Pine.Core.PineValue List_Single_List_985fed4e =
        Pine.Core.PineValue.List(
            [List_985fed4e]);

    public static readonly Pine.Core.PineValue List_Single_List_8eb4c1ce =
        Pine.Core.PineValue.List(
            [List_8eb4c1ce]);

    public static readonly Pine.Core.PineValue List_a6e20029 =
        Pine.Core.PineValue.List(
            [List_db582731, List_8799f419]);

    public static readonly Pine.Core.PineValue List_feef8adf =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e4fdbb4a]);

    public static readonly Pine.Core.PineValue List_61576e1f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fcae4a4b]);

    public static readonly Pine.Core.PineValue List_f8bfc2d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0347b797]);

    public static readonly Pine.Core.PineValue List_d9dcda92 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_81929877]);

    public static readonly Pine.Core.PineValue List_f7b33d72 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b217a620]);

    public static readonly Pine.Core.PineValue List_a511c140 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_989a3a14]);

    public static readonly Pine.Core.PineValue List_8a1bfa3f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fe930b2c]);

    public static readonly Pine.Core.PineValue List_691e9adc =
        Pine.Core.PineValue.List(
            [List_c0abcf7c, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_691e9adc =
        Pine.Core.PineValue.List(
            [List_691e9adc]);

    public static readonly Pine.Core.PineValue List_4f19f71f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_922d407b]);

    public static readonly Pine.Core.PineValue List_95fdbd86 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_5f115c04]);

    public static readonly Pine.Core.PineValue List_d6ddabd7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1b2c35d9]);

    public static readonly Pine.Core.PineValue List_526ef4cf =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_8e29b702]);

    public static readonly Pine.Core.PineValue List_e914e125 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1612ec6e]);

    public static readonly Pine.Core.PineValue List_0cc66467 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_61f00d35]);

    public static readonly Pine.Core.PineValue List_4f2839e5 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_3d745061]);

    public static readonly Pine.Core.PineValue List_d516c738 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_9f0c42bf]);

    public static readonly Pine.Core.PineValue List_c0a3984e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_8b9e3057]);

    public static readonly Pine.Core.PineValue List_7517e945 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_b4797819]);

    public static readonly Pine.Core.PineValue List_c79ebb3a =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c4712195]);

    public static readonly Pine.Core.PineValue List_d099562f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_4d767988]);

    public static readonly Pine.Core.PineValue List_7d3d72bc =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_24c67c9d]);

    public static readonly Pine.Core.PineValue List_004b043f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2097609a]);

    public static readonly Pine.Core.PineValue List_6d91266b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ef6eabf3]);

    public static readonly Pine.Core.PineValue List_08e78bab =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a0f394b0]);

    public static readonly Pine.Core.PineValue List_130375f2 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_847f3c7a]);

    public static readonly Pine.Core.PineValue List_342ad337 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2e61fa25]);

    public static readonly Pine.Core.PineValue List_f40e530d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_37755a2f]);

    public static readonly Pine.Core.PineValue List_dca04908 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1c295777]);

    public static readonly Pine.Core.PineValue List_9a9945c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_d3e9925c]);

    public static readonly Pine.Core.PineValue List_4cc45924 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b71ec3d3]);

    public static readonly Pine.Core.PineValue List_f4eb4ff7 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_98e0e124]);

    public static readonly Pine.Core.PineValue List_3a178f28 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_b2679444]);

    public static readonly Pine.Core.PineValue List_27ca9399 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_400282b1]);

    public static readonly Pine.Core.PineValue List_8bbd8c8b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_985fed4e]);

    public static readonly Pine.Core.PineValue List_8e4979de =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8eb4c1ce]);

    public static readonly Pine.Core.PineValue List_8d520cae =
        Pine.Core.PineValue.List(
            [List_d816deb1, List_ac807715]);

    public static readonly Pine.Core.PineValue List_Single_List_8d520cae =
        Pine.Core.PineValue.List(
            [List_8d520cae]);

    public static readonly Pine.Core.PineValue List_2e587246 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_81511394 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_f7b33d72]);

    public static readonly Pine.Core.PineValue List_90a1f73c =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a511c140]);

    public static readonly Pine.Core.PineValue List_58fe30de =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_691e9adc]);

    public static readonly Pine.Core.PineValue List_6a455358 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_68f4906d]);

    public static readonly Pine.Core.PineValue List_e86eeac3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4ff52d72]);

    public static readonly Pine.Core.PineValue List_dbce3a57 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cbee86a5]);

    public static readonly Pine.Core.PineValue List_fb43f2b1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bce9c711]);

    public static readonly Pine.Core.PineValue List_cdd6200c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_095a660b]);

    public static readonly Pine.Core.PineValue List_72e5e6b2 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_98a4bcd7]);

    public static readonly Pine.Core.PineValue List_385bdaa4 =
        Pine.Core.PineValue.List(
            [List_bc0ffa85, List_18e799b0]);

    public static readonly Pine.Core.PineValue List_Single_List_385bdaa4 =
        Pine.Core.PineValue.List(
            [List_385bdaa4]);

    public static readonly Pine.Core.PineValue List_5cb57174 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_97cfc8ff =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_8c46c627]);

    public static readonly Pine.Core.PineValue List_Single_List_97cfc8ff =
        Pine.Core.PineValue.List(
            [List_97cfc8ff]);

    public static readonly Pine.Core.PineValue List_b437d778 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9d528f9d]);

    public static readonly Pine.Core.PineValue List_be2048c0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8d520cae]);

    public static readonly Pine.Core.PineValue List_451fda34 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_8a1bfa3f]);

    public static readonly Pine.Core.PineValue List_Single_List_451fda34 =
        Pine.Core.PineValue.List(
            [List_451fda34]);

    public static readonly Pine.Core.PineValue List_2ebf8fc7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7916b715]);

    public static readonly Pine.Core.PineValue List_0147dd5b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_385bdaa4]);

    public static readonly Pine.Core.PineValue List_8c532958 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_27ca9399]);

    public static readonly Pine.Core.PineValue List_02c263d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_8bbd8c8b]);

    public static readonly Pine.Core.PineValue List_0c25448d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3ee8b153]);

    public static readonly Pine.Core.PineValue List_3ff20474 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_58fe30de]);

    public static readonly Pine.Core.PineValue List_590b0e3f =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a6e20029]);

    public static readonly Pine.Core.PineValue List_62698512 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_97cfc8ff]);

    public static readonly Pine.Core.PineValue List_2207f032 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_451fda34]);

    public static readonly Pine.Core.PineValue List_66864eae =
        Pine.Core.PineValue.List(
            [List_d181119a, List_12173aa2]);

    public static readonly Pine.Core.PineValue List_3944b07e =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d08202cd, List_976730e9]);

    public static readonly Pine.Core.PineValue List_Single_List_3944b07e =
        Pine.Core.PineValue.List(
            [List_3944b07e]);

    public static readonly Pine.Core.PineValue List_1625972e =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_6a455358]);

    public static readonly Pine.Core.PineValue List_bd7902ca =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_e86eeac3]);

    public static readonly Pine.Core.PineValue List_24c84dcc =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_dbce3a57]);

    public static readonly Pine.Core.PineValue List_Single_List_1625972e =
        Pine.Core.PineValue.List(
            [List_1625972e]);

    public static readonly Pine.Core.PineValue List_Single_List_bd7902ca =
        Pine.Core.PineValue.List(
            [List_bd7902ca]);

    public static readonly Pine.Core.PineValue List_Single_List_24c84dcc =
        Pine.Core.PineValue.List(
            [List_24c84dcc]);

    public static readonly Pine.Core.PineValue List_335abcaf =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_2c859eb4 =
        Pine.Core.PineValue.List(
            [List_887c794a, List_fb43f2b1]);

    public static readonly Pine.Core.PineValue List_Single_List_2c859eb4 =
        Pine.Core.PineValue.List(
            [List_2c859eb4]);

    public static readonly Pine.Core.PineValue List_910e92c3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4f19f71f]);

    public static readonly Pine.Core.PineValue List_fd7e3c44 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_95fdbd86]);

    public static readonly Pine.Core.PineValue List_10015539 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d6ddabd7]);

    public static readonly Pine.Core.PineValue List_9ecbdaf8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_526ef4cf]);

    public static readonly Pine.Core.PineValue List_d02158f5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e914e125]);

    public static readonly Pine.Core.PineValue List_52e7b97a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_0cc66467]);

    public static readonly Pine.Core.PineValue List_23c9f203 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4f2839e5]);

    public static readonly Pine.Core.PineValue List_eae9cc4c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d516c738]);

    public static readonly Pine.Core.PineValue List_f9cba928 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c0a3984e]);

    public static readonly Pine.Core.PineValue List_259077d1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7517e945]);

    public static readonly Pine.Core.PineValue List_859a991a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c79ebb3a]);

    public static readonly Pine.Core.PineValue List_fa47e3e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d099562f]);

    public static readonly Pine.Core.PineValue List_973a2c91 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7d3d72bc]);

    public static readonly Pine.Core.PineValue List_2c50f745 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_004b043f]);

    public static readonly Pine.Core.PineValue List_68a4a753 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6d91266b]);

    public static readonly Pine.Core.PineValue List_50d46cba =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_08e78bab]);

    public static readonly Pine.Core.PineValue List_982167ce =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_130375f2]);

    public static readonly Pine.Core.PineValue List_f8ddc64b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_342ad337]);

    public static readonly Pine.Core.PineValue List_7ae431de =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f40e530d]);

    public static readonly Pine.Core.PineValue List_d8c73140 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dca04908]);

    public static readonly Pine.Core.PineValue List_04ad43ca =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9a9945c8]);

    public static readonly Pine.Core.PineValue List_f1258270 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4cc45924]);

    public static readonly Pine.Core.PineValue List_4e5ebd57 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f4eb4ff7]);

    public static readonly Pine.Core.PineValue List_Single_List_982167ce =
        Pine.Core.PineValue.List(
            [List_982167ce]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_982167ce =
        Pine.Core.PineValue.List(
            [List_Single_List_982167ce]);

    public static readonly Pine.Core.PineValue List_5bca49c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3a178f28]);

    public static readonly Pine.Core.PineValue List_b6459452 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3944b07e]);

    public static readonly Pine.Core.PineValue List_befbd539 =
        Pine.Core.PineValue.List(
            [List_61576e1f, List_2f59fd7a, List_cd5e9e27]);

    public static readonly Pine.Core.PineValue List_71050795 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1625972e]);

    public static readonly Pine.Core.PineValue List_2d0c106f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bd7902ca]);

    public static readonly Pine.Core.PineValue List_e3d69dcd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_24c84dcc]);

    public static readonly Pine.Core.PineValue List_ae1aefbc =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2e587246]);

    public static readonly Pine.Core.PineValue List_ef611d67 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_81511394]);

    public static readonly Pine.Core.PineValue List_2c5eb8d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_90a1f73c]);

    public static readonly Pine.Core.PineValue List_6c873f4c =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a4286e44]);

    public static readonly Pine.Core.PineValue List_10690a5e =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_2e378702]);

    public static readonly Pine.Core.PineValue List_68e439ed =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_a70b19c4]);

    public static readonly Pine.Core.PineValue List_Single_List_6c873f4c =
        Pine.Core.PineValue.List(
            [List_6c873f4c]);

    public static readonly Pine.Core.PineValue List_Single_List_10690a5e =
        Pine.Core.PineValue.List(
            [List_10690a5e]);

    public static readonly Pine.Core.PineValue List_Single_List_68e439ed =
        Pine.Core.PineValue.List(
            [List_68e439ed]);

    public static readonly Pine.Core.PineValue List_279fcf62 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5cb57174]);

    public static readonly Pine.Core.PineValue List_71c082fa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2c859eb4]);

    public static readonly Pine.Core.PineValue List_902e12bd =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_859a991a]);

    public static readonly Pine.Core.PineValue List_3b4ed2c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_973a2c91]);

    public static readonly Pine.Core.PineValue List_5ee6ce30 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_50d46cba]);

    public static readonly Pine.Core.PineValue List_80423c0e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_f1258270]);

    public static readonly Pine.Core.PineValue List_1ca7d868 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_4e5ebd57]);

    public static readonly Pine.Core.PineValue List_eee0ebd2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_982167ce]);

    public static readonly Pine.Core.PineValue List_0b614622 =
        Pine.Core.PineValue.List(
            [List_ffb62471, List_34849c45]);

    public static readonly Pine.Core.PineValue List_Single_List_0b614622 =
        Pine.Core.PineValue.List(
            [List_0b614622]);

    public static readonly Pine.Core.PineValue List_d30942e3 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_66864eae]);

    public static readonly Pine.Core.PineValue List_8f6303d1 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_71050795]);

    public static readonly Pine.Core.PineValue List_9b9eb504 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2d0c106f]);

    public static readonly Pine.Core.PineValue List_5ac710ad =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_e3d69dcd]);

    public static readonly Pine.Core.PineValue List_4bba8540 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6c873f4c]);

    public static readonly Pine.Core.PineValue List_2c5ed6a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_10690a5e]);

    public static readonly Pine.Core.PineValue List_7aae6b0c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_68e439ed]);

    public static readonly Pine.Core.PineValue List_f1224b7e =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_e609c3f7, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_Single_List_f1224b7e =
        Pine.Core.PineValue.List(
            [List_f1224b7e]);

    public static readonly Pine.Core.PineValue List_833c8967 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_859a991a]);

    public static readonly Pine.Core.PineValue List_2a04cc12 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_973a2c91]);

    public static readonly Pine.Core.PineValue List_5825420a =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_50d46cba]);

    public static readonly Pine.Core.PineValue List_d68325d7 =
        Pine.Core.PineValue.List(
            [List_910e92c3, List_0dcd86c0]);

    public static readonly Pine.Core.PineValue List_Single_List_833c8967 =
        Pine.Core.PineValue.List(
            [List_833c8967]);

    public static readonly Pine.Core.PineValue List_Single_List_2a04cc12 =
        Pine.Core.PineValue.List(
            [List_2a04cc12]);

    public static readonly Pine.Core.PineValue List_Single_List_5825420a =
        Pine.Core.PineValue.List(
            [List_5825420a]);

    public static readonly Pine.Core.PineValue List_Single_List_d68325d7 =
        Pine.Core.PineValue.List(
            [List_d68325d7]);

    public static readonly Pine.Core.PineValue List_7bc32dc1 =
        Pine.Core.PineValue.List(
            [List_24a01a94, List_d08202cd, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_Single_List_7bc32dc1 =
        Pine.Core.PineValue.List(
            [List_7bc32dc1]);

    public static readonly Pine.Core.PineValue List_6d171847 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8c532958]);

    public static readonly Pine.Core.PineValue List_cd8dc28c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_02c263d7]);

    public static readonly Pine.Core.PineValue List_Single_List_cd8dc28c =
        Pine.Core.PineValue.List(
            [List_cd8dc28c]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_cd8dc28c =
        Pine.Core.PineValue.List(
            [List_Single_List_cd8dc28c]);

    public static readonly Pine.Core.PineValue List_47c8000c =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_71c082fa]);

    public static readonly Pine.Core.PineValue List_4bde3051 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0b614622]);

    public static readonly Pine.Core.PineValue List_462b85bd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3ff20474]);

    public static readonly Pine.Core.PineValue List_74d4a5fa =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_f0fceb46]);

    public static readonly Pine.Core.PineValue List_Single_List_74d4a5fa =
        Pine.Core.PineValue.List(
            [List_74d4a5fa]);

    public static readonly Pine.Core.PineValue List_b70c8bda =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_ae1aefbc]);

    public static readonly Pine.Core.PineValue List_365438ec =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_ef611d67]);

    public static readonly Pine.Core.PineValue List_a4ea2f3b =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_2c5eb8d4]);

    public static readonly Pine.Core.PineValue List_2449c52e =
        Pine.Core.PineValue.List(
            [List_768cc61e, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_1480b39e =
        Pine.Core.PineValue.List(
            [List_e4c8bd61, List_6ee5ba57]);

    public static readonly Pine.Core.PineValue List_Single_List_b70c8bda =
        Pine.Core.PineValue.List(
            [List_b70c8bda]);

    public static readonly Pine.Core.PineValue List_Single_List_365438ec =
        Pine.Core.PineValue.List(
            [List_365438ec]);

    public static readonly Pine.Core.PineValue List_Single_List_a4ea2f3b =
        Pine.Core.PineValue.List(
            [List_a4ea2f3b]);

    public static readonly Pine.Core.PineValue List_Single_List_2449c52e =
        Pine.Core.PineValue.List(
            [List_2449c52e]);

    public static readonly Pine.Core.PineValue List_Single_List_1480b39e =
        Pine.Core.PineValue.List(
            [List_1480b39e]);

    public static readonly Pine.Core.PineValue List_b5a0693f =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_cdd6200c]);

    public static readonly Pine.Core.PineValue List_5b58eb8b =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_72e5e6b2]);

    public static readonly Pine.Core.PineValue List_Single_List_b5a0693f =
        Pine.Core.PineValue.List(
            [List_b5a0693f]);

    public static readonly Pine.Core.PineValue List_Single_List_5b58eb8b =
        Pine.Core.PineValue.List(
            [List_5b58eb8b]);

    public static readonly Pine.Core.PineValue List_0f44d232 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f1224b7e]);

    public static readonly Pine.Core.PineValue List_e95cc7a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_833c8967]);

    public static readonly Pine.Core.PineValue List_c6f71870 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2a04cc12]);

    public static readonly Pine.Core.PineValue List_6364c5aa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5825420a]);

    public static readonly Pine.Core.PineValue List_3f254c0f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d68325d7]);

    public static readonly Pine.Core.PineValue List_c7bf96d6 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_befbd539]);

    public static readonly Pine.Core.PineValue List_4d2d313a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7bc32dc1]);

    public static readonly Pine.Core.PineValue List_0831a090 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_cd8dc28c]);

    public static readonly Pine.Core.PineValue List_ec7103b8 =
        Pine.Core.PineValue.List(
            [List_f7e47dc9, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_ec7103b8 =
        Pine.Core.PineValue.List(
            [List_ec7103b8]);

    public static readonly Pine.Core.PineValue List_08042d00 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_74d4a5fa]);

    public static readonly Pine.Core.PineValue List_565e9945 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_Single_List_565e9945 =
        Pine.Core.PineValue.List(
            [List_565e9945]);

    public static readonly Pine.Core.PineValue List_970791ee =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_7aae6b0c]);

    public static readonly Pine.Core.PineValue List_05929510 =
        Pine.Core.PineValue.List(
            [List_7d0d2ed9, List_96b83b24]);

    public static readonly Pine.Core.PineValue List_Single_List_05929510 =
        Pine.Core.PineValue.List(
            [List_05929510]);

    public static readonly Pine.Core.PineValue List_ef00dcd2 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_335abcaf]);

    public static readonly Pine.Core.PineValue List_a83e1b3d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b70c8bda]);

    public static readonly Pine.Core.PineValue List_bbeb2904 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_365438ec]);

    public static readonly Pine.Core.PineValue List_b1e0ac34 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a4ea2f3b]);

    public static readonly Pine.Core.PineValue List_d8c1129d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2449c52e]);

    public static readonly Pine.Core.PineValue List_4fabe8d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1480b39e]);

    public static readonly Pine.Core.PineValue List_4ae30e83 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_4bde3051]);

    public static readonly Pine.Core.PineValue List_f3528297 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b5a0693f]);

    public static readonly Pine.Core.PineValue List_6fa2e8a6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5b58eb8b]);

    public static readonly Pine.Core.PineValue List_8838f772 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_e95cc7a3]);

    public static readonly Pine.Core.PineValue List_5812fc09 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c6f71870]);

    public static readonly Pine.Core.PineValue List_cad155f8 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_6364c5aa]);

    public static readonly Pine.Core.PineValue List_327413ec =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_8e4979de]);

    public static readonly Pine.Core.PineValue List_Single_List_327413ec =
        Pine.Core.PineValue.List(
            [List_327413ec]);

    public static readonly Pine.Core.PineValue List_655b9a6b =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3f254c0f]);

    public static readonly Pine.Core.PineValue List_85e61d97 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ec7103b8]);

    public static readonly Pine.Core.PineValue List_00e06002 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_565e9945]);

    public static readonly Pine.Core.PineValue List_f76ae3fd =
        Pine.Core.PineValue.List(
            [List_9f80ab63, List_ffb3657e]);

    public static readonly Pine.Core.PineValue List_Single_List_f76ae3fd =
        Pine.Core.PineValue.List(
            [List_f76ae3fd]);

    public static readonly Pine.Core.PineValue List_8bd0132d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_05929510]);

    public static readonly Pine.Core.PineValue List_ed23348b =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_d8c1129d]);

    public static readonly Pine.Core.PineValue List_35c22b0b =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_a83e1b3d]);

    public static readonly Pine.Core.PineValue List_95df418b =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_bbeb2904]);

    public static readonly Pine.Core.PineValue List_11be84f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_b1e0ac34]);

    public static readonly Pine.Core.PineValue List_63aed801 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_902e12bd]);

    public static readonly Pine.Core.PineValue List_b13cafb8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3b4ed2c8]);

    public static readonly Pine.Core.PineValue List_26874315 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5ee6ce30]);

    public static readonly Pine.Core.PineValue List_0a74ee6c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_80423c0e]);

    public static readonly Pine.Core.PineValue List_6f23c897 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1ca7d868]);

    public static readonly Pine.Core.PineValue List_1c88eba5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_327413ec]);

    public static readonly Pine.Core.PineValue List_a1010ee7 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_f3528297]);

    public static readonly Pine.Core.PineValue List_2f5dc62f =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_6fa2e8a6]);

    public static readonly Pine.Core.PineValue List_c27c7f4f =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_49fd4802 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_bec006ed =
        Pine.Core.PineValue.List(
            [List_43b95777, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_c21e4f61 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_9d34c3d5 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_3ccca30d =
        Pine.Core.PineValue.List(
            [List_c1b27e6e, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_3f11762c =
        Pine.Core.PineValue.List(
            [List_282dee3a, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_b748b0dc =
        Pine.Core.PineValue.List(
            [List_9f1e38f9, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_e8c90f25 =
        Pine.Core.PineValue.List(
            [List_14a0ba72, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_321a5571 =
        Pine.Core.PineValue.List(
            [List_a710c27f, List_b43468c9, List_40007240]);

    public static readonly Pine.Core.PineValue List_Single_List_c27c7f4f =
        Pine.Core.PineValue.List(
            [List_c27c7f4f]);

    public static readonly Pine.Core.PineValue List_Single_List_49fd4802 =
        Pine.Core.PineValue.List(
            [List_49fd4802]);

    public static readonly Pine.Core.PineValue List_Single_List_bec006ed =
        Pine.Core.PineValue.List(
            [List_bec006ed]);

    public static readonly Pine.Core.PineValue List_Single_List_c21e4f61 =
        Pine.Core.PineValue.List(
            [List_c21e4f61]);

    public static readonly Pine.Core.PineValue List_Single_List_9d34c3d5 =
        Pine.Core.PineValue.List(
            [List_9d34c3d5]);

    public static readonly Pine.Core.PineValue List_Single_List_3ccca30d =
        Pine.Core.PineValue.List(
            [List_3ccca30d]);

    public static readonly Pine.Core.PineValue List_Single_List_3f11762c =
        Pine.Core.PineValue.List(
            [List_3f11762c]);

    public static readonly Pine.Core.PineValue List_Single_List_b748b0dc =
        Pine.Core.PineValue.List(
            [List_b748b0dc]);

    public static readonly Pine.Core.PineValue List_Single_List_e8c90f25 =
        Pine.Core.PineValue.List(
            [List_e8c90f25]);

    public static readonly Pine.Core.PineValue List_Single_List_321a5571 =
        Pine.Core.PineValue.List(
            [List_321a5571]);

    public static readonly Pine.Core.PineValue List_7287c695 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_85e61d97]);

    public static readonly Pine.Core.PineValue List_c5540061 =
        Pine.Core.PineValue.List(
            [List_87c481f1, List_80491b1d]);

    public static readonly Pine.Core.PineValue List_Single_List_c5540061 =
        Pine.Core.PineValue.List(
            [List_c5540061]);

    public static readonly Pine.Core.PineValue List_bc5e6625 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f76ae3fd]);

    public static readonly Pine.Core.PineValue List_ce0b123c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8f6303d1]);

    public static readonly Pine.Core.PineValue List_a76941ad =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9b9eb504]);

    public static readonly Pine.Core.PineValue List_c28a17e2 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5ac710ad]);

    public static readonly Pine.Core.PineValue List_43a924cf =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_0a74ee6c]);

    public static readonly Pine.Core.PineValue List_e96a130d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_47c8000c]);

    public static readonly Pine.Core.PineValue List_934fca3a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c27c7f4f]);

    public static readonly Pine.Core.PineValue List_c32f8d23 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_49fd4802]);

    public static readonly Pine.Core.PineValue List_a2c8f94f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bec006ed]);

    public static readonly Pine.Core.PineValue List_6227bc04 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c21e4f61]);

    public static readonly Pine.Core.PineValue List_8594c0bd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9d34c3d5]);

    public static readonly Pine.Core.PineValue List_11925635 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3ccca30d]);

    public static readonly Pine.Core.PineValue List_bdf4568f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3f11762c]);

    public static readonly Pine.Core.PineValue List_afc020d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b748b0dc]);

    public static readonly Pine.Core.PineValue List_1a65ed37 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e8c90f25]);

    public static readonly Pine.Core.PineValue List_358ebecf =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_321a5571]);

    public static readonly Pine.Core.PineValue List_ec2ca287 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c5540061]);

    public static readonly Pine.Core.PineValue List_30adc1fd =
        Pine.Core.PineValue.List(
            [List_52d1ddaa, List_26563753]);

    public static readonly Pine.Core.PineValue List_Single_List_30adc1fd =
        Pine.Core.PineValue.List(
            [List_30adc1fd]);

    public static readonly Pine.Core.PineValue List_f52610b7 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_0a74ee6c]);

    public static readonly Pine.Core.PineValue List_66a71bb6 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_6f23c897]);

    public static readonly Pine.Core.PineValue List_66deb17c =
        Pine.Core.PineValue.List(
            [List_43b95777, List_0a74ee6c]);

    public static readonly Pine.Core.PineValue List_2ae4cb57 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_6f23c897]);

    public static readonly Pine.Core.PineValue List_5d12c553 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_0a74ee6c]);

    public static readonly Pine.Core.PineValue List_7b4fe1bf =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_6f23c897]);

    public static readonly Pine.Core.PineValue List_bd530e41 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_0a74ee6c]);

    public static readonly Pine.Core.PineValue List_94136808 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_6f23c897]);

    public static readonly Pine.Core.PineValue List_Single_List_f52610b7 =
        Pine.Core.PineValue.List(
            [List_f52610b7]);

    public static readonly Pine.Core.PineValue List_Single_List_66a71bb6 =
        Pine.Core.PineValue.List(
            [List_66a71bb6]);

    public static readonly Pine.Core.PineValue List_Single_List_66deb17c =
        Pine.Core.PineValue.List(
            [List_66deb17c]);

    public static readonly Pine.Core.PineValue List_Single_List_2ae4cb57 =
        Pine.Core.PineValue.List(
            [List_2ae4cb57]);

    public static readonly Pine.Core.PineValue List_Single_List_5d12c553 =
        Pine.Core.PineValue.List(
            [List_5d12c553]);

    public static readonly Pine.Core.PineValue List_Single_List_7b4fe1bf =
        Pine.Core.PineValue.List(
            [List_7b4fe1bf]);

    public static readonly Pine.Core.PineValue List_Single_List_bd530e41 =
        Pine.Core.PineValue.List(
            [List_bd530e41]);

    public static readonly Pine.Core.PineValue List_Single_List_94136808 =
        Pine.Core.PineValue.List(
            [List_94136808]);

    public static readonly Pine.Core.PineValue List_9d10e21e =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d08202cd, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_Single_List_9d10e21e =
        Pine.Core.PineValue.List(
            [List_9d10e21e]);

    public static readonly Pine.Core.PineValue List_f4ab299a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_970791ee]);

    public static readonly Pine.Core.PineValue List_Single_List_f4ab299a =
        Pine.Core.PineValue.List(
            [List_f4ab299a]);

    public static readonly Pine.Core.PineValue List_0d10aa6d =
        Pine.Core.PineValue.List(
            [List_82113c5f, List_00efda36]);

    public static readonly Pine.Core.PineValue List_Single_List_0d10aa6d =
        Pine.Core.PineValue.List(
            [List_0d10aa6d]);

    public static readonly Pine.Core.PineValue List_fdc3830c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4ae30e83]);

    public static readonly Pine.Core.PineValue List_6eaea3fb =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_ec2ca287]);

    public static readonly Pine.Core.PineValue List_46bdd88b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_30adc1fd]);

    public static readonly Pine.Core.PineValue List_0e71892b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f52610b7]);

    public static readonly Pine.Core.PineValue List_a976a1fd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_66a71bb6]);

    public static readonly Pine.Core.PineValue List_4d4b57ec =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_66deb17c]);

    public static readonly Pine.Core.PineValue List_e42e6301 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2ae4cb57]);

    public static readonly Pine.Core.PineValue List_aef690f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5d12c553]);

    public static readonly Pine.Core.PineValue List_4d0d8c1a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7b4fe1bf]);

    public static readonly Pine.Core.PineValue List_41e85cae =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bd530e41]);

    public static readonly Pine.Core.PineValue List_8fd94eb3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_94136808]);

    public static readonly Pine.Core.PineValue List_cb529f86 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8838f772]);

    public static readonly Pine.Core.PineValue List_25fb4342 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5812fc09]);

    public static readonly Pine.Core.PineValue List_e42b5d35 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cad155f8]);

    public static readonly Pine.Core.PineValue List_2557831f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_655b9a6b]);

    public static readonly Pine.Core.PineValue List_a29fb86d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9d10e21e]);

    public static readonly Pine.Core.PineValue List_94033c74 =
        Pine.Core.PineValue.List(
            [List_ef00dcd2, List_2f59fd7a, List_cd5e9e27]);

    public static readonly Pine.Core.PineValue List_f2f15532 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_is_sorted_asc, List_8bd0132d]);

    public static readonly Pine.Core.PineValue List_7349334d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0d10aa6d]);

    public static readonly Pine.Core.PineValue List_84e5f176 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ed23348b]);

    public static readonly Pine.Core.PineValue List_24d7b608 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_35c22b0b]);

    public static readonly Pine.Core.PineValue List_be68a4da =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_95df418b]);

    public static readonly Pine.Core.PineValue List_60939d9c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_11be84f7]);

    public static readonly Pine.Core.PineValue List_75de6aa1 =
        Pine.Core.PineValue.List(
            [List_1c80da68, List_009614b4]);

    public static readonly Pine.Core.PineValue List_Single_List_75de6aa1 =
        Pine.Core.PineValue.List(
            [List_75de6aa1]);

    public static readonly Pine.Core.PineValue List_a0265999 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_cb529f86]);

    public static readonly Pine.Core.PineValue List_5b279e5c =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_25fb4342]);

    public static readonly Pine.Core.PineValue List_69ef60e0 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_e42b5d35]);

    public static readonly Pine.Core.PineValue List_5c725181 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_0e71892b]);

    public static readonly Pine.Core.PineValue List_34028bde =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a976a1fd]);

    public static readonly Pine.Core.PineValue List_7d432acb =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_4d4b57ec]);

    public static readonly Pine.Core.PineValue List_2c29a920 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_e42e6301]);

    public static readonly Pine.Core.PineValue List_79611552 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_aef690f3]);

    public static readonly Pine.Core.PineValue List_932de6fb =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_4d0d8c1a]);

    public static readonly Pine.Core.PineValue List_f4a3e24a =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_41e85cae]);

    public static readonly Pine.Core.PineValue List_2d0c8647 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_8fd94eb3]);

    public static readonly Pine.Core.PineValue List_b2b822a8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a1010ee7]);

    public static readonly Pine.Core.PineValue List_59cad394 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2f5dc62f]);

    public static readonly Pine.Core.PineValue List_837976dd =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_f4ab299a]);

    public static readonly Pine.Core.PineValue List_4eeb72ae =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7287c695]);

    public static readonly Pine.Core.PineValue List_7ca56a88 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_b43468c9, List_4af1f0ec, List_27311de8, List_27311de8]);

    public static readonly Pine.Core.PineValue List_Single_List_7ca56a88 =
        Pine.Core.PineValue.List(
            [List_7ca56a88]);

    public static readonly Pine.Core.PineValue List_d4a89214 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_75de6aa1]);

    public static readonly Pine.Core.PineValue List_f0cd7f7f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_43a924cf]);

    public static readonly Pine.Core.PineValue List_b6280e61 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_3dc9c9d1]);

    public static readonly Pine.Core.PineValue List_5d745015 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_84e5f176]);

    public static readonly Pine.Core.PineValue List_d5e74c6c =
        Pine.Core.PineValue.List(
            [List_e7e7947e, List_c88b942a]);

    public static readonly Pine.Core.PineValue List_Single_List_5d745015 =
        Pine.Core.PineValue.List(
            [List_5d745015]);

    public static readonly Pine.Core.PineValue List_Single_List_d5e74c6c =
        Pine.Core.PineValue.List(
            [List_d5e74c6c]);

    public static readonly Pine.Core.PineValue List_d4d4aa0a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7ca56a88]);

    public static readonly Pine.Core.PineValue List_60ada136 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_4d2d313a]);

    public static readonly Pine.Core.PineValue List_Single_List_60ada136 =
        Pine.Core.PineValue.List(
            [List_60ada136]);

    public static readonly Pine.Core.PineValue List_e0a86b82 =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_4c2609c3]);

    public static readonly Pine.Core.PineValue List_8d351a9e =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_c3b08663]);

    public static readonly Pine.Core.PineValue List_7521852b =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_e844984b]);

    public static readonly Pine.Core.PineValue List_831ec1fd =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_a9196577]);

    public static readonly Pine.Core.PineValue List_4278c9fa =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_9728f698]);

    public static readonly Pine.Core.PineValue List_a1606e60 =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_86fad7dd]);

    public static readonly Pine.Core.PineValue List_a2644dd5 =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_c005c994]);

    public static readonly Pine.Core.PineValue List_90335742 =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_33c6f4ad]);

    public static readonly Pine.Core.PineValue List_fd9460de =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_1a0b8610]);

    public static readonly Pine.Core.PineValue List_8ed941ee =
        Pine.Core.PineValue.List(
            [List_60939d9c, List_ecf5f39d]);

    public static readonly Pine.Core.PineValue List_Single_List_e0a86b82 =
        Pine.Core.PineValue.List(
            [List_e0a86b82]);

    public static readonly Pine.Core.PineValue List_Single_List_8d351a9e =
        Pine.Core.PineValue.List(
            [List_8d351a9e]);

    public static readonly Pine.Core.PineValue List_Single_List_7521852b =
        Pine.Core.PineValue.List(
            [List_7521852b]);

    public static readonly Pine.Core.PineValue List_Single_List_831ec1fd =
        Pine.Core.PineValue.List(
            [List_831ec1fd]);

    public static readonly Pine.Core.PineValue List_Single_List_4278c9fa =
        Pine.Core.PineValue.List(
            [List_4278c9fa]);

    public static readonly Pine.Core.PineValue List_Single_List_a1606e60 =
        Pine.Core.PineValue.List(
            [List_a1606e60]);

    public static readonly Pine.Core.PineValue List_Single_List_a2644dd5 =
        Pine.Core.PineValue.List(
            [List_a2644dd5]);

    public static readonly Pine.Core.PineValue List_Single_List_90335742 =
        Pine.Core.PineValue.List(
            [List_90335742]);

    public static readonly Pine.Core.PineValue List_Single_List_fd9460de =
        Pine.Core.PineValue.List(
            [List_fd9460de]);

    public static readonly Pine.Core.PineValue List_Single_List_8ed941ee =
        Pine.Core.PineValue.List(
            [List_8ed941ee]);

    public static readonly Pine.Core.PineValue List_88cf4ec0 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_63aed801]);

    public static readonly Pine.Core.PineValue List_89704d45 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_b13cafb8]);

    public static readonly Pine.Core.PineValue List_74679402 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_26874315]);

    public static readonly Pine.Core.PineValue List_Single_List_88cf4ec0 =
        Pine.Core.PineValue.List(
            [List_88cf4ec0]);

    public static readonly Pine.Core.PineValue List_Single_List_89704d45 =
        Pine.Core.PineValue.List(
            [List_89704d45]);

    public static readonly Pine.Core.PineValue List_Single_List_74679402 =
        Pine.Core.PineValue.List(
            [List_74679402]);

    public static readonly Pine.Core.PineValue List_26b054cd =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_f0cd7f7f]);

    public static readonly Pine.Core.PineValue List_0e024eb4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_94033c74]);

    public static readonly Pine.Core.PineValue List_18b61b69 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_62698512]);

    public static readonly Pine.Core.PineValue List_2ca70e4b =
        Pine.Core.PineValue.List(
            [List_f751324e, List_26874315]);

    public static readonly Pine.Core.PineValue List_Single_List_2ca70e4b =
        Pine.Core.PineValue.List(
            [List_2ca70e4b]);

    public static readonly Pine.Core.PineValue List_14382e40 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_d4a89214]);

    public static readonly Pine.Core.PineValue List_06f7b975 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_2207f032]);

    public static readonly Pine.Core.PineValue List_437bf806 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_4eeb72ae]);

    public static readonly Pine.Core.PineValue List_Single_List_437bf806 =
        Pine.Core.PineValue.List(
            [List_437bf806]);

    public static readonly Pine.Core.PineValue List_5748c6ea =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_4fabe8d7]);

    public static readonly Pine.Core.PineValue List_Single_List_5748c6ea =
        Pine.Core.PineValue.List(
            [List_5748c6ea]);

    public static readonly Pine.Core.PineValue List_248b6c06 =
        Pine.Core.PineValue.List(
            [List_4ac3f89e, List_402fa2b4, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_da5eb341 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5d745015]);

    public static readonly Pine.Core.PineValue List_f6e85409 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d5e74c6c]);

    public static readonly Pine.Core.PineValue List_dafb5db3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6eaea3fb]);

    public static readonly Pine.Core.PineValue List_738a33a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_60ada136]);

    public static readonly Pine.Core.PineValue List_dd1a37bb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e0a86b82]);

    public static readonly Pine.Core.PineValue List_2b6482ae =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8d351a9e]);

    public static readonly Pine.Core.PineValue List_8b2f7377 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7521852b]);

    public static readonly Pine.Core.PineValue List_e6036e4f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_831ec1fd]);

    public static readonly Pine.Core.PineValue List_d0ea62b2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4278c9fa]);

    public static readonly Pine.Core.PineValue List_65c1509a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a1606e60]);

    public static readonly Pine.Core.PineValue List_91dafb6f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a2644dd5]);

    public static readonly Pine.Core.PineValue List_a8b39634 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_90335742]);

    public static readonly Pine.Core.PineValue List_14fcccba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fd9460de]);

    public static readonly Pine.Core.PineValue List_57766905 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8ed941ee]);

    public static readonly Pine.Core.PineValue List_df1880b2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_88cf4ec0]);

    public static readonly Pine.Core.PineValue List_0e23975f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_89704d45]);

    public static readonly Pine.Core.PineValue List_439cbe32 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_74679402]);

    public static readonly Pine.Core.PineValue List_8330a061 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_85e61d97]);

    public static readonly Pine.Core.PineValue List_Single_List_8330a061 =
        Pine.Core.PineValue.List(
            [List_8330a061]);

    public static readonly Pine.Core.PineValue List_507a0de5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2ca70e4b]);

    public static readonly Pine.Core.PineValue List_df61b1cc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_437bf806]);

    public static readonly Pine.Core.PineValue List_f4ae3a57 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5748c6ea]);

    public static readonly Pine.Core.PineValue List_f4fceed0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f2f15532]);

    public static readonly Pine.Core.PineValue List_dbe73d4b =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_929c9d51]);

    public static readonly Pine.Core.PineValue List_b4e4f4d9 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_097a386d]);

    public static readonly Pine.Core.PineValue List_1659e244 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_908ec70a]);

    public static readonly Pine.Core.PineValue List_bb03f007 =
        Pine.Core.PineValue.List(
            [List_8799f419, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_1659e244 =
        Pine.Core.PineValue.List(
            [List_1659e244]);

    public static readonly Pine.Core.PineValue List_Single_List_bb03f007 =
        Pine.Core.PineValue.List(
            [List_bb03f007]);

    public static readonly Pine.Core.PineValue List_d7ca573f =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_da5eb341]);

    public static readonly Pine.Core.PineValue List_7533c013 =
        Pine.Core.PineValue.List(
            [List_2ca5e701, List_4af1f0ec, List_e1230cbe]);

    public static readonly Pine.Core.PineValue List_d1a65156 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a0265999]);

    public static readonly Pine.Core.PineValue List_ffd1a020 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5b279e5c]);

    public static readonly Pine.Core.PineValue List_2bcb6544 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_69ef60e0]);

    public static readonly Pine.Core.PineValue List_9f737642 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5c725181]);

    public static readonly Pine.Core.PineValue List_ac509b1f =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_34028bde]);

    public static readonly Pine.Core.PineValue List_90678f40 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7d432acb]);

    public static readonly Pine.Core.PineValue List_a8b266c7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2c29a920]);

    public static readonly Pine.Core.PineValue List_a080fd42 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_79611552]);

    public static readonly Pine.Core.PineValue List_c3df4f10 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_932de6fb]);

    public static readonly Pine.Core.PineValue List_28338036 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f4a3e24a]);

    public static readonly Pine.Core.PineValue List_242b1acf =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2d0c8647]);

    public static readonly Pine.Core.PineValue List_af10111d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_dd1a37bb]);

    public static readonly Pine.Core.PineValue List_75b309a4 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2b6482ae]);

    public static readonly Pine.Core.PineValue List_ddbb8f6b =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_8b2f7377]);

    public static readonly Pine.Core.PineValue List_a1ae6ce3 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_e6036e4f]);

    public static readonly Pine.Core.PineValue List_36481480 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_d0ea62b2]);

    public static readonly Pine.Core.PineValue List_95079eff =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_65c1509a]);

    public static readonly Pine.Core.PineValue List_1c67486d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_91dafb6f]);

    public static readonly Pine.Core.PineValue List_4696a1ae =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a8b39634]);

    public static readonly Pine.Core.PineValue List_637dd30c =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_14fcccba]);

    public static readonly Pine.Core.PineValue List_d4e3e57f =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_57766905]);

    public static readonly Pine.Core.PineValue List_ddd7bbf2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8330a061]);

    public static readonly Pine.Core.PineValue List_63f0d05e =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_df1880b2]);

    public static readonly Pine.Core.PineValue List_60be9f64 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_0e23975f]);

    public static readonly Pine.Core.PineValue List_9a32789e =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_439cbe32]);

    public static readonly Pine.Core.PineValue List_620b96dc =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_bc5e6625]);

    public static readonly Pine.Core.PineValue List_Single_List_620b96dc =
        Pine.Core.PineValue.List(
            [List_620b96dc]);

    public static readonly Pine.Core.PineValue List_6889225a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_507a0de5]);

    public static readonly Pine.Core.PineValue List_984ddc61 =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_df61b1cc]);

    public static readonly Pine.Core.PineValue List_d611c42e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_b6280e61]);

    public static readonly Pine.Core.PineValue List_92e1bf14 =
        Pine.Core.PineValue.List(
            [List_af278ce0, List_fe2319f6]);

    public static readonly Pine.Core.PineValue List_Single_List_92e1bf14 =
        Pine.Core.PineValue.List(
            [List_92e1bf14]);

    public static readonly Pine.Core.PineValue List_c011e805 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1659e244]);

    public static readonly Pine.Core.PineValue List_64c9eb37 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bb03f007]);

    public static readonly Pine.Core.PineValue List_bb1301d2 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_18b61b69]);

    public static readonly Pine.Core.PineValue List_da0705ba =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_d1a65156]);

    public static readonly Pine.Core.PineValue List_30f27b9b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ffd1a020]);

    public static readonly Pine.Core.PineValue List_44fb153b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2bcb6544]);

    public static readonly Pine.Core.PineValue List_ab98db00 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_9f737642]);

    public static readonly Pine.Core.PineValue List_56ee075c =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ac509b1f]);

    public static readonly Pine.Core.PineValue List_6f20c88d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_90678f40]);

    public static readonly Pine.Core.PineValue List_9933d2a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a8b266c7]);

    public static readonly Pine.Core.PineValue List_02f17673 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a080fd42]);

    public static readonly Pine.Core.PineValue List_2dff1dbf =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c3df4f10]);

    public static readonly Pine.Core.PineValue List_55d35206 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_28338036]);

    public static readonly Pine.Core.PineValue List_55cf19ec =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_242b1acf]);

    public static readonly Pine.Core.PineValue List_ed62fa4c =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_934fca3a]);

    public static readonly Pine.Core.PineValue List_4070bf0f =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_c32f8d23]);

    public static readonly Pine.Core.PineValue List_eda76c75 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a2c8f94f]);

    public static readonly Pine.Core.PineValue List_bbd0c3ab =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_6227bc04]);

    public static readonly Pine.Core.PineValue List_e7f5e57b =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_8594c0bd]);

    public static readonly Pine.Core.PineValue List_23ddbfa3 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_11925635]);

    public static readonly Pine.Core.PineValue List_06869e90 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_bdf4568f]);

    public static readonly Pine.Core.PineValue List_f039433a =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_afc020d7]);

    public static readonly Pine.Core.PineValue List_83ba3f98 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_1a65ed37]);

    public static readonly Pine.Core.PineValue List_f3fe2344 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_358ebecf]);

    public static readonly Pine.Core.PineValue List_Single_List_ed62fa4c =
        Pine.Core.PineValue.List(
            [List_ed62fa4c]);

    public static readonly Pine.Core.PineValue List_Single_List_4070bf0f =
        Pine.Core.PineValue.List(
            [List_4070bf0f]);

    public static readonly Pine.Core.PineValue List_Single_List_eda76c75 =
        Pine.Core.PineValue.List(
            [List_eda76c75]);

    public static readonly Pine.Core.PineValue List_Single_List_bbd0c3ab =
        Pine.Core.PineValue.List(
            [List_bbd0c3ab]);

    public static readonly Pine.Core.PineValue List_Single_List_e7f5e57b =
        Pine.Core.PineValue.List(
            [List_e7f5e57b]);

    public static readonly Pine.Core.PineValue List_Single_List_23ddbfa3 =
        Pine.Core.PineValue.List(
            [List_23ddbfa3]);

    public static readonly Pine.Core.PineValue List_Single_List_06869e90 =
        Pine.Core.PineValue.List(
            [List_06869e90]);

    public static readonly Pine.Core.PineValue List_Single_List_f039433a =
        Pine.Core.PineValue.List(
            [List_f039433a]);

    public static readonly Pine.Core.PineValue List_Single_List_83ba3f98 =
        Pine.Core.PineValue.List(
            [List_83ba3f98]);

    public static readonly Pine.Core.PineValue List_Single_List_f3fe2344 =
        Pine.Core.PineValue.List(
            [List_f3fe2344]);

    public static readonly Pine.Core.PineValue List_a957f465 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_06f7b975]);

    public static readonly Pine.Core.PineValue List_edaed8fa =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_248b6c06]);

    public static readonly Pine.Core.PineValue List_9b16ca67 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_620b96dc]);

    public static readonly Pine.Core.PineValue List_68adb539 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_4bba8540]);

    public static readonly Pine.Core.PineValue List_9eeb7447 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_2c5ed6a9]);

    public static readonly Pine.Core.PineValue List_8d64b0d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_92e1bf14]);

    public static readonly Pine.Core.PineValue List_cd8a869e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_26b054cd]);

    public static readonly Pine.Core.PineValue List_32d4f349 =
        Pine.Core.PineValue.List(
            [List_52d1ddaa, List_79ad41ac]);

    public static readonly Pine.Core.PineValue List_Single_List_32d4f349 =
        Pine.Core.PineValue.List(
            [List_32d4f349]);

    public static readonly Pine.Core.PineValue List_2f741df9 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_c011e805]);

    public static readonly Pine.Core.PineValue List_22461243 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_64c9eb37]);

    public static readonly Pine.Core.PineValue List_fd57272d =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_ffd1a020]);

    public static readonly Pine.Core.PineValue List_662d7de5 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_ffd1a020]);

    public static readonly Pine.Core.PineValue List_0903a778 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_d1a65156]);

    public static readonly Pine.Core.PineValue List_a0a67f77 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_ffd1a020]);

    public static readonly Pine.Core.PineValue List_bba0f1fd =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_ffd1a020]);

    public static readonly Pine.Core.PineValue List_Single_List_fd57272d =
        Pine.Core.PineValue.List(
            [List_fd57272d]);

    public static readonly Pine.Core.PineValue List_Single_List_662d7de5 =
        Pine.Core.PineValue.List(
            [List_662d7de5]);

    public static readonly Pine.Core.PineValue List_Single_List_0903a778 =
        Pine.Core.PineValue.List(
            [List_0903a778]);

    public static readonly Pine.Core.PineValue List_Single_List_a0a67f77 =
        Pine.Core.PineValue.List(
            [List_a0a67f77]);

    public static readonly Pine.Core.PineValue List_Single_List_bba0f1fd =
        Pine.Core.PineValue.List(
            [List_bba0f1fd]);

    public static readonly Pine.Core.PineValue List_83b381f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ed62fa4c]);

    public static readonly Pine.Core.PineValue List_54c4b604 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4070bf0f]);

    public static readonly Pine.Core.PineValue List_3ccd01f9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_eda76c75]);

    public static readonly Pine.Core.PineValue List_65f31d12 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bbd0c3ab]);

    public static readonly Pine.Core.PineValue List_dfbab881 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e7f5e57b]);

    public static readonly Pine.Core.PineValue List_b7ef3b06 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_23ddbfa3]);

    public static readonly Pine.Core.PineValue List_d21cda04 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_06869e90]);

    public static readonly Pine.Core.PineValue List_4a790866 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f039433a]);

    public static readonly Pine.Core.PineValue List_ccad033e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_83ba3f98]);

    public static readonly Pine.Core.PineValue List_7fc982d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f3fe2344]);

    public static readonly Pine.Core.PineValue List_d1125cdd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_14382e40]);

    public static readonly Pine.Core.PineValue List_22122af7 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_dbe73d4b]);

    public static readonly Pine.Core.PineValue List_285af2ab =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_b4e4f4d9]);

    public static readonly Pine.Core.PineValue List_Single_List_285af2ab =
        Pine.Core.PineValue.List(
            [List_285af2ab]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_285af2ab =
        Pine.Core.PineValue.List(
            [List_Single_List_285af2ab]);

    public static readonly Pine.Core.PineValue List_3966a3c3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7533c013]);

    public static readonly Pine.Core.PineValue List_379afe98 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_32d4f349]);

    public static readonly Pine.Core.PineValue List_4357613e =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_7b45cce4]);

    public static readonly Pine.Core.PineValue List_0b3bec30 =
        Pine.Core.PineValue.List(
            [List_e20932bd, List_d08202cd, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_Single_List_4357613e =
        Pine.Core.PineValue.List(
            [List_4357613e]);

    public static readonly Pine.Core.PineValue List_Single_List_0b3bec30 =
        Pine.Core.PineValue.List(
            [List_0b3bec30]);

    public static readonly Pine.Core.PineValue List_8e35a28b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fd57272d]);

    public static readonly Pine.Core.PineValue List_e7fd7fa3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_662d7de5]);

    public static readonly Pine.Core.PineValue List_b546f9d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0903a778]);

    public static readonly Pine.Core.PineValue List_8d144467 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a0a67f77]);

    public static readonly Pine.Core.PineValue List_7724d9ba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bba0f1fd]);

    public static readonly Pine.Core.PineValue List_aea8af18 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_8d64b0d3]);

    public static readonly Pine.Core.PineValue List_78ab6cac =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_285af2ab]);

    public static readonly Pine.Core.PineValue List_d89ad4f3 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_d4d4aa0a]);

    public static readonly Pine.Core.PineValue List_Single_List_d89ad4f3 =
        Pine.Core.PineValue.List(
            [List_d89ad4f3]);

    public static readonly Pine.Core.PineValue List_9e9a0cdc =
        Pine.Core.PineValue.List(
            [Blob_Str_length, List_d1125cdd]);

    public static readonly Pine.Core.PineValue List_147fffd6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d7ca573f]);

    public static readonly Pine.Core.PineValue List_5b2fd16d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4357613e]);

    public static readonly Pine.Core.PineValue List_a5697e72 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0b3bec30]);

    public static readonly Pine.Core.PineValue List_19e637ba =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_8e35a28b]);

    public static readonly Pine.Core.PineValue List_bf149e10 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_e7fd7fa3]);

    public static readonly Pine.Core.PineValue List_c26f6dcb =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_b546f9d8]);

    public static readonly Pine.Core.PineValue List_039b5009 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_8d144467]);

    public static readonly Pine.Core.PineValue List_6c76ae1c =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_7724d9ba]);

    public static readonly Pine.Core.PineValue List_df6df33c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_af10111d]);

    public static readonly Pine.Core.PineValue List_3cab333c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_75b309a4]);

    public static readonly Pine.Core.PineValue List_653f3279 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ddbb8f6b]);

    public static readonly Pine.Core.PineValue List_5f85ed23 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a1ae6ce3]);

    public static readonly Pine.Core.PineValue List_1b2d1a32 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_36481480]);

    public static readonly Pine.Core.PineValue List_93b72dec =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_95079eff]);

    public static readonly Pine.Core.PineValue List_da97fbb4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1c67486d]);

    public static readonly Pine.Core.PineValue List_c2c0d1a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4696a1ae]);

    public static readonly Pine.Core.PineValue List_8ebf4631 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_637dd30c]);

    public static readonly Pine.Core.PineValue List_58c0de4c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d4e3e57f]);

    public static readonly Pine.Core.PineValue List_827bfab6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_63f0d05e]);

    public static readonly Pine.Core.PineValue List_376a060a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_60be9f64]);

    public static readonly Pine.Core.PineValue List_2289fa98 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9a32789e]);

    public static readonly Pine.Core.PineValue List_f6da112b =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_68adb539]);

    public static readonly Pine.Core.PineValue List_575bb1c3 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_9eeb7447]);

    public static readonly Pine.Core.PineValue List_e9c9882a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6889225a]);

    public static readonly Pine.Core.PineValue List_d00846d4 =
        Pine.Core.PineValue.List(
            [List_f4fceed0, List_2f59fd7a, List_cd5e9e27]);

    public static readonly Pine.Core.PineValue List_f0b63ca0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_984ddc61]);

    public static readonly Pine.Core.PineValue List_Single_List_f0b63ca0 =
        Pine.Core.PineValue.List(
            [List_f0b63ca0]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_f0b63ca0 =
        Pine.Core.PineValue.List(
            [List_Single_List_f0b63ca0]);

    public static readonly Pine.Core.PineValue List_e2ac7ae9 =
        Pine.Core.PineValue.List(
            [List_52d1ddaa, List_a511c140]);

    public static readonly Pine.Core.PineValue List_Single_List_e2ac7ae9 =
        Pine.Core.PineValue.List(
            [List_e2ac7ae9]);

    public static readonly Pine.Core.PineValue List_aa527ebf =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d89ad4f3]);

    public static readonly Pine.Core.PineValue List_394852f2 =
        Pine.Core.PineValue.List(
            [List_887c794a, List_cd8a869e]);

    public static readonly Pine.Core.PineValue List_Single_List_394852f2 =
        Pine.Core.PineValue.List(
            [List_394852f2]);

    public static readonly Pine.Core.PineValue List_1072af56 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_da0705ba]);

    public static readonly Pine.Core.PineValue List_2a54a82c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_30f27b9b]);

    public static readonly Pine.Core.PineValue List_ceaa2db1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_44fb153b]);

    public static readonly Pine.Core.PineValue List_af6ab14c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ab98db00]);

    public static readonly Pine.Core.PineValue List_4404e85b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_56ee075c]);

    public static readonly Pine.Core.PineValue List_4e5ae7e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6f20c88d]);

    public static readonly Pine.Core.PineValue List_9b7cc2a7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9933d2a5]);

    public static readonly Pine.Core.PineValue List_accc4c20 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_02f17673]);

    public static readonly Pine.Core.PineValue List_6c9605d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2dff1dbf]);

    public static readonly Pine.Core.PineValue List_7d570eb6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_55d35206]);

    public static readonly Pine.Core.PineValue List_b0257228 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_55cf19ec]);

    public static readonly Pine.Core.PineValue List_31ef7aed =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_f0b63ca0]);

    public static readonly Pine.Core.PineValue List_f23f2caa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e2ac7ae9]);

    public static readonly Pine.Core.PineValue List_ca472dee =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_0147dd5b]);

    public static readonly Pine.Core.PineValue List_78ca0de2 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_5b2fd16d]);

    public static readonly Pine.Core.PineValue List_ae6077ae =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2f741df9]);

    public static readonly Pine.Core.PineValue List_88ffdbcf =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_22461243]);

    public static readonly Pine.Core.PineValue List_a0106171 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_394852f2]);

    public static readonly Pine.Core.PineValue List_d1a07f10 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_1072af56]);

    public static readonly Pine.Core.PineValue List_151adb1a =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2a54a82c]);

    public static readonly Pine.Core.PineValue List_4e678a0b =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ceaa2db1]);

    public static readonly Pine.Core.PineValue List_95edf2a7 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_accc4c20]);

    public static readonly Pine.Core.PineValue List_7b8f69df =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6c9605d4]);

    public static readonly Pine.Core.PineValue List_7269a31a =
        Pine.Core.PineValue.List(
            [List_1a4e9839, List_73ef2378, List_53090eac]);

    public static readonly Pine.Core.PineValue List_8f0cbd4f =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_f6e85409]);

    public static readonly Pine.Core.PineValue List_Single_List_8f0cbd4f =
        Pine.Core.PineValue.List(
            [List_8f0cbd4f]);

    public static readonly Pine.Core.PineValue List_a2816336 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_d08202cd, List_35cf017c, List_6dbb5f29]);

    public static readonly Pine.Core.PineValue List_348a3c04 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_34849c45, List_d181119a, List_96cfcb00]);

    public static readonly Pine.Core.PineValue List_2f4ecaa5 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d08202cd, List_976730e9, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_Single_List_a2816336 =
        Pine.Core.PineValue.List(
            [List_a2816336]);

    public static readonly Pine.Core.PineValue List_Single_List_348a3c04 =
        Pine.Core.PineValue.List(
            [List_348a3c04]);

    public static readonly Pine.Core.PineValue List_Single_List_2f4ecaa5 =
        Pine.Core.PineValue.List(
            [List_2f4ecaa5]);

    public static readonly Pine.Core.PineValue List_450455a2 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_accc4c20]);

    public static readonly Pine.Core.PineValue List_e8ace097 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_6c9605d4]);

    public static readonly Pine.Core.PineValue List_Single_List_450455a2 =
        Pine.Core.PineValue.List(
            [List_450455a2]);

    public static readonly Pine.Core.PineValue List_Single_List_e8ace097 =
        Pine.Core.PineValue.List(
            [List_e8ace097]);

    public static readonly Pine.Core.PineValue List_50efe0f8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d00846d4]);

    public static readonly Pine.Core.PineValue List_abf30417 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_a0106171]);

    public static readonly Pine.Core.PineValue List_c4d2d1eb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_aea8af18]);

    public static readonly Pine.Core.PineValue List_Single_List_c4d2d1eb =
        Pine.Core.PineValue.List(
            [List_c4d2d1eb]);

    public static readonly Pine.Core.PineValue List_d73dd2f4 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_31ef7aed]);

    public static readonly Pine.Core.PineValue List_Single_List_d73dd2f4 =
        Pine.Core.PineValue.List(
            [List_d73dd2f4]);

    public static readonly Pine.Core.PineValue List_1ea6eb3f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f0cbd4f]);

    public static readonly Pine.Core.PineValue List_08be85e0 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_910e92c3]);

    public static readonly Pine.Core.PineValue List_fd7467e9 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_fd7e3c44]);

    public static readonly Pine.Core.PineValue List_d837d618 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_859a991a]);

    public static readonly Pine.Core.PineValue List_3e284b6e =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_982167ce]);

    public static readonly Pine.Core.PineValue List_a225ea17 =
        Pine.Core.PineValue.List(
            [List_fe634606, List_4af1f0ec]);

    public static readonly Pine.Core.PineValue List_Single_List_08be85e0 =
        Pine.Core.PineValue.List(
            [List_08be85e0]);

    public static readonly Pine.Core.PineValue List_Single_List_fd7467e9 =
        Pine.Core.PineValue.List(
            [List_fd7467e9]);

    public static readonly Pine.Core.PineValue List_Single_List_d837d618 =
        Pine.Core.PineValue.List(
            [List_d837d618]);

    public static readonly Pine.Core.PineValue List_Single_List_3e284b6e =
        Pine.Core.PineValue.List(
            [List_3e284b6e]);

    public static readonly Pine.Core.PineValue List_Single_List_a225ea17 =
        Pine.Core.PineValue.List(
            [List_a225ea17]);

    public static readonly Pine.Core.PineValue List_2c6083ca =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9e9a0cdc]);

    public static readonly Pine.Core.PineValue List_3dbd846b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a2816336]);

    public static readonly Pine.Core.PineValue List_690b75ce =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_348a3c04]);

    public static readonly Pine.Core.PineValue List_c8267de8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2f4ecaa5]);

    public static readonly Pine.Core.PineValue List_d5be917f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_450455a2]);

    public static readonly Pine.Core.PineValue List_78623efc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e8ace097]);

    public static readonly Pine.Core.PineValue List_fa1354b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_19e637ba]);

    public static readonly Pine.Core.PineValue List_fcf65c89 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bf149e10]);

    public static readonly Pine.Core.PineValue List_9a613596 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c26f6dcb]);

    public static readonly Pine.Core.PineValue List_85513288 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_039b5009]);

    public static readonly Pine.Core.PineValue List_add0e01a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6c76ae1c]);

    public static readonly Pine.Core.PineValue List_8930bc8e =
        Pine.Core.PineValue.List(
            [List_d766d462, List_b7351701]);

    public static readonly Pine.Core.PineValue List_Single_List_8930bc8e =
        Pine.Core.PineValue.List(
            [List_8930bc8e]);

    public static readonly Pine.Core.PineValue List_a57974b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d73dd2f4]);

    public static readonly Pine.Core.PineValue List_de54c194 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_ca472dee]);

    public static readonly Pine.Core.PineValue List_ce1640f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_08be85e0]);

    public static readonly Pine.Core.PineValue List_c26a1677 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fd7467e9]);

    public static readonly Pine.Core.PineValue List_1918a25a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d837d618]);

    public static readonly Pine.Core.PineValue List_901f3000 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3e284b6e]);

    public static readonly Pine.Core.PineValue List_e6f3f3a4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a225ea17]);

    public static readonly Pine.Core.PineValue List_8263e85a =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7269a31a]);

    public static readonly Pine.Core.PineValue List_54b9d667 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_fa1354b9]);

    public static readonly Pine.Core.PineValue List_a54a4003 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_fcf65c89]);

    public static readonly Pine.Core.PineValue List_832b0660 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_9a613596]);

    public static readonly Pine.Core.PineValue List_4f5935cb =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_85513288]);

    public static readonly Pine.Core.PineValue List_ac8c7e08 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_add0e01a]);

    public static readonly Pine.Core.PineValue List_bf4f9892 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_d5be917f]);

    public static readonly Pine.Core.PineValue List_8971a23b =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_78623efc]);

    public static readonly Pine.Core.PineValue List_5c94f165 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_c4d2d1eb]);

    public static readonly Pine.Core.PineValue List_8243e7a4 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_d30942e3]);

    public static readonly Pine.Core.PineValue List_Single_List_8243e7a4 =
        Pine.Core.PineValue.List(
            [List_8243e7a4]);

    public static readonly Pine.Core.PineValue List_a00e91bb =
        Pine.Core.PineValue.List(
            [List_e0f436ab, List_ff977232, List_ecf5f39d]);

    public static readonly Pine.Core.PineValue List_71bd74cc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8930bc8e]);

    public static readonly Pine.Core.PineValue List_05a1e04b =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_4bba8540]);

    public static readonly Pine.Core.PineValue List_8b10bec8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_78ca0de2]);

    public static readonly Pine.Core.PineValue List_Single_List_8b10bec8 =
        Pine.Core.PineValue.List(
            [List_8b10bec8]);

    public static readonly Pine.Core.PineValue List_5286fdec =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d1a07f10]);

    public static readonly Pine.Core.PineValue List_d4773219 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_151adb1a]);

    public static readonly Pine.Core.PineValue List_426db48a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4e678a0b]);

    public static readonly Pine.Core.PineValue List_3c814059 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_95edf2a7]);

    public static readonly Pine.Core.PineValue List_818afcf1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_7b8f69df]);

    public static readonly Pine.Core.PineValue List_ae8ad797 =
        Pine.Core.PineValue.List(
            [List_ae2bb31e, List_eee0ebd2]);

    public static readonly Pine.Core.PineValue List_Single_List_ae8ad797 =
        Pine.Core.PineValue.List(
            [List_ae8ad797]);

    public static readonly Pine.Core.PineValue List_3d2fe13e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8243e7a4]);

    public static readonly Pine.Core.PineValue List_c61a1811 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_Single_List_c61a1811 =
        Pine.Core.PineValue.List(
            [List_c61a1811]);

    public static readonly Pine.Core.PineValue List_27e3f888 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_ce1640f4]);

    public static readonly Pine.Core.PineValue List_c5843b66 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_e6f3f3a4]);

    public static readonly Pine.Core.PineValue List_898a1477 =
        Pine.Core.PineValue.List(
            [List_b6459452, List_45d6e69b]);

    public static readonly Pine.Core.PineValue List_Single_List_898a1477 =
        Pine.Core.PineValue.List(
            [List_898a1477]);

    public static readonly Pine.Core.PineValue List_9c6e5910 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ae8ad797]);

    public static readonly Pine.Core.PineValue List_7ad8a429 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_abf30417]);

    public static readonly Pine.Core.PineValue List_59b3ae74 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_78ab6cac]);

    public static readonly Pine.Core.PineValue List_Single_List_59b3ae74 =
        Pine.Core.PineValue.List(
            [List_59b3ae74]);

    public static readonly Pine.Core.PineValue List_7ab03670 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c61a1811]);

    public static readonly Pine.Core.PineValue List_14e626b6 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_8b10bec8]);

    public static readonly Pine.Core.PineValue List_256d7d08 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_738a33a5]);

    public static readonly Pine.Core.PineValue List_4b358ea3 =
        Pine.Core.PineValue.List(
            [List_b65b91d7, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_2882acde =
        Pine.Core.PineValue.List(
            [List_f87f6843, List_73ef2378, List_27311de8]);

    public static readonly Pine.Core.PineValue List_Single_List_4b358ea3 =
        Pine.Core.PineValue.List(
            [List_4b358ea3]);

    public static readonly Pine.Core.PineValue List_adffcf24 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a5697e72]);

    public static readonly Pine.Core.PineValue List_Single_List_adffcf24 =
        Pine.Core.PineValue.List(
            [List_adffcf24]);

    public static readonly Pine.Core.PineValue List_1ad2ee97 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a00e91bb]);

    public static readonly Pine.Core.PineValue List_6d83c098 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_898a1477]);

    public static readonly Pine.Core.PineValue List_54dce27b =
        Pine.Core.PineValue.List(
            [List_52d1ddaa, List_0831a090]);

    public static readonly Pine.Core.PineValue List_Single_List_54dce27b =
        Pine.Core.PineValue.List(
            [List_54dce27b]);

    public static readonly Pine.Core.PineValue List_e2de71f6 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_00e06002]);

    public static readonly Pine.Core.PineValue List_a6e36c93 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_00e06002]);

    public static readonly Pine.Core.PineValue List_5d6e779e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_59b3ae74]);

    public static readonly Pine.Core.PineValue List_95297c22 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_05a1e04b]);

    public static readonly Pine.Core.PineValue List_8f52508a =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_d4773219]);

    public static readonly Pine.Core.PineValue List_eb40ad19 =
        Pine.Core.PineValue.List(
            [List_f81f258c, List_bb14d771, List_e53e9917]);

    public static readonly Pine.Core.PineValue List_Single_List_8f52508a =
        Pine.Core.PineValue.List(
            [List_8f52508a]);

    public static readonly Pine.Core.PineValue List_699247d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4b358ea3]);

    public static readonly Pine.Core.PineValue List_475c68bb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_adffcf24]);

    public static readonly Pine.Core.PineValue List_1974d1f4 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_1c88eba5]);

    public static readonly Pine.Core.PineValue List_316a7376 =
        Pine.Core.PineValue.List(
            [List_887c794a, List_5286fdec]);

    public static readonly Pine.Core.PineValue List_6ce7e330 =
        Pine.Core.PineValue.List(
            [List_887c794a, List_426db48a]);

    public static readonly Pine.Core.PineValue List_Single_List_316a7376 =
        Pine.Core.PineValue.List(
            [List_316a7376]);

    public static readonly Pine.Core.PineValue List_Single_List_6ce7e330 =
        Pine.Core.PineValue.List(
            [List_6ce7e330]);

    public static readonly Pine.Core.PineValue List_532bbcd3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_54b9d667]);

    public static readonly Pine.Core.PineValue List_d18da9cc =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a54a4003]);

    public static readonly Pine.Core.PineValue List_c20a0cbb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_832b0660]);

    public static readonly Pine.Core.PineValue List_9c12cdf2 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4f5935cb]);

    public static readonly Pine.Core.PineValue List_3c2b6c59 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ac8c7e08]);

    public static readonly Pine.Core.PineValue List_3e88a1fd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bf4f9892]);

    public static readonly Pine.Core.PineValue List_990f156d =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8971a23b]);

    public static readonly Pine.Core.PineValue List_5f71beeb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_54dce27b]);

    public static readonly Pine.Core.PineValue List_aa1bafa3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8f52508a]);

    public static readonly Pine.Core.PineValue List_b5006d16 =
        Pine.Core.PineValue.List(
            [List_11e84499, List_bb14d771, List_ba30935e]);

    public static readonly Pine.Core.PineValue List_ec07024d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_316a7376]);

    public static readonly Pine.Core.PineValue List_383aed6a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6ce7e330]);

    public static readonly Pine.Core.PineValue List_3b14cdc6 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c20a0cbb]);

    public static readonly Pine.Core.PineValue List_e787af56 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_3e88a1fd]);

    public static readonly Pine.Core.PineValue List_8779bf8f =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_990f156d]);

    public static readonly Pine.Core.PineValue List_a56696f0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2882acde]);

    public static readonly Pine.Core.PineValue List_ec48c01b =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_256d7d08]);

    public static readonly Pine.Core.PineValue List_Single_List_ec48c01b =
        Pine.Core.PineValue.List(
            [List_ec48c01b]);

    public static readonly Pine.Core.PineValue List_502d34d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_27e3f888]);

    public static readonly Pine.Core.PineValue List_c3510f99 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_c5843b66]);

    public static readonly Pine.Core.PineValue List_f12c7f8b =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_aa1bafa3]);

    public static readonly Pine.Core.PineValue List_7015128c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_83b381f3]);

    public static readonly Pine.Core.PineValue List_481ba5c9 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_54c4b604]);

    public static readonly Pine.Core.PineValue List_ea4abdf1 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_3ccd01f9]);

    public static readonly Pine.Core.PineValue List_c24147bf =
        Pine.Core.PineValue.List(
            [List_976730e9, List_65f31d12]);

    public static readonly Pine.Core.PineValue List_8252c7c7 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_dfbab881]);

    public static readonly Pine.Core.PineValue List_75e495bf =
        Pine.Core.PineValue.List(
            [List_976730e9, List_b7ef3b06]);

    public static readonly Pine.Core.PineValue List_46711533 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_d21cda04]);

    public static readonly Pine.Core.PineValue List_c496aa10 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_4a790866]);

    public static readonly Pine.Core.PineValue List_d5dab593 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_ccad033e]);

    public static readonly Pine.Core.PineValue List_fe4df18e =
        Pine.Core.PineValue.List(
            [List_976730e9, List_7fc982d7]);

    public static readonly Pine.Core.PineValue List_88ce9fef =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d08202cd, List_35cf017c, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_Single_List_88ce9fef =
        Pine.Core.PineValue.List(
            [List_88ce9fef]);

    public static readonly Pine.Core.PineValue List_3bbdedb5 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_c20a0cbb]);

    public static readonly Pine.Core.PineValue List_Single_List_3bbdedb5 =
        Pine.Core.PineValue.List(
            [List_3bbdedb5]);

    public static readonly Pine.Core.PineValue List_048a1be1 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_e2de71f6]);

    public static readonly Pine.Core.PineValue List_09bcc09f =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a6e36c93]);

    public static readonly Pine.Core.PineValue List_266447a9 =
        Pine.Core.PineValue.List(
            [List_134d2bc4, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_266447a9 =
        Pine.Core.PineValue.List(
            [List_266447a9]);

    public static readonly Pine.Core.PineValue List_82da83de =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_eb40ad19]);

    public static readonly Pine.Core.PineValue List_2da0133b =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_ec07024d]);

    public static readonly Pine.Core.PineValue List_eed852e8 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_383aed6a]);

    public static readonly Pine.Core.PineValue List_14069d77 =
        Pine.Core.PineValue.List(
            [List_d181119a, List_fdc3830c]);

    public static readonly Pine.Core.PineValue List_Single_List_14069d77 =
        Pine.Core.PineValue.List(
            [List_14069d77]);

    public static readonly Pine.Core.PineValue List_862b56c0 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_46bdd88b]);

    public static readonly Pine.Core.PineValue List_4edb9ffe =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_1974d1f4]);

    public static readonly Pine.Core.PineValue List_53b42f5f =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_3c814059]);

    public static readonly Pine.Core.PineValue List_fd63605f =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_818afcf1]);

    public static readonly Pine.Core.PineValue List_Single_List_53b42f5f =
        Pine.Core.PineValue.List(
            [List_53b42f5f]);

    public static readonly Pine.Core.PineValue List_Single_List_fd63605f =
        Pine.Core.PineValue.List(
            [List_fd63605f]);

    public static readonly Pine.Core.PineValue List_b4306b44 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_88ce9fef]);

    public static readonly Pine.Core.PineValue List_c1b50da5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3bbdedb5]);

    public static readonly Pine.Core.PineValue List_2b405904 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_266447a9]);

    public static readonly Pine.Core.PineValue List_9de4765d =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_ec48c01b]);

    public static readonly Pine.Core.PineValue List_dff21a29 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_b5006d16]);

    public static readonly Pine.Core.PineValue List_80d1e7a2 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_1918a25a]);

    public static readonly Pine.Core.PineValue List_c30d3cac =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_901f3000]);

    public static readonly Pine.Core.PineValue List_Single_List_80d1e7a2 =
        Pine.Core.PineValue.List(
            [List_80d1e7a2]);

    public static readonly Pine.Core.PineValue List_Single_List_c30d3cac =
        Pine.Core.PineValue.List(
            [List_c30d3cac]);

    public static readonly Pine.Core.PineValue List_f2fd581c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_14069d77]);

    public static readonly Pine.Core.PineValue List_5e058b40 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_53b42f5f]);

    public static readonly Pine.Core.PineValue List_2c1c81b1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fd63605f]);

    public static readonly Pine.Core.PineValue List_f39f81d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c1b50da5]);

    public static readonly Pine.Core.PineValue List_2fc8dc99 =
        Pine.Core.PineValue.List(
            [List_a29fb86d, List_c0abcf7c]);

    public static readonly Pine.Core.PineValue List_Single_List_2fc8dc99 =
        Pine.Core.PineValue.List(
            [List_2fc8dc99]);

    public static readonly Pine.Core.PineValue List_78c00b43 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_80d1e7a2]);

    public static readonly Pine.Core.PineValue List_2a486760 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c30d3cac]);

    public static readonly Pine.Core.PineValue List_128a91eb =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_7015128c]);

    public static readonly Pine.Core.PineValue List_b5221b1b =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_481ba5c9]);

    public static readonly Pine.Core.PineValue List_10ee6dd0 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_ea4abdf1]);

    public static readonly Pine.Core.PineValue List_a691016a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c24147bf]);

    public static readonly Pine.Core.PineValue List_b8b71b30 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_8252c7c7]);

    public static readonly Pine.Core.PineValue List_c86be949 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_75e495bf]);

    public static readonly Pine.Core.PineValue List_6906b28f =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_46711533]);

    public static readonly Pine.Core.PineValue List_4c8b632e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c496aa10]);

    public static readonly Pine.Core.PineValue List_c7ba562f =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_d5dab593]);

    public static readonly Pine.Core.PineValue List_644d6208 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_fe4df18e]);

    public static readonly Pine.Core.PineValue List_4a8e6287 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3b14cdc6]);

    public static readonly Pine.Core.PineValue List_7777977c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e787af56]);

    public static readonly Pine.Core.PineValue List_a457124a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8779bf8f]);

    public static readonly Pine.Core.PineValue List_57e3ca8b =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_3d2fe13e]);

    public static readonly Pine.Core.PineValue List_Single_List_57e3ca8b =
        Pine.Core.PineValue.List(
            [List_57e3ca8b]);

    public static readonly Pine.Core.PineValue List_73d3e16a =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_5e058b40]);

    public static readonly Pine.Core.PineValue List_1ad7dd6f =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_2c1c81b1]);

    public static readonly Pine.Core.PineValue List_d7451e5d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2fc8dc99]);

    public static readonly Pine.Core.PineValue List_3cb1c868 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_f23f2caa]);

    public static readonly Pine.Core.PineValue List_c7765369 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_862b56c0]);

    public static readonly Pine.Core.PineValue List_2aee1e7b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f12c7f8b]);

    public static readonly Pine.Core.PineValue List_445d811c =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_7777977c]);

    public static readonly Pine.Core.PineValue List_896490d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a457124a]);

    public static readonly Pine.Core.PineValue List_56efbe7a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_57e3ca8b]);

    public static readonly Pine.Core.PineValue List_ef50b02a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_2da0133b]);

    public static readonly Pine.Core.PineValue List_882114d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_eed852e8]);

    public static readonly Pine.Core.PineValue List_5bd7a740 =
        Pine.Core.PineValue.List(
            [List_b5d02807, List_8799f419, List_908ec70a]);

    public static readonly Pine.Core.PineValue List_Single_List_5bd7a740 =
        Pine.Core.PineValue.List(
            [List_5bd7a740]);

    public static readonly Pine.Core.PineValue List_518c5790 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_7777977c]);

    public static readonly Pine.Core.PineValue List_cc973075 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_a457124a]);

    public static readonly Pine.Core.PineValue List_31c4029f =
        Pine.Core.PineValue.List(
            [List_43b95777, List_7777977c]);

    public static readonly Pine.Core.PineValue List_298d2735 =
        Pine.Core.PineValue.List(
            [List_43b95777, List_a457124a]);

    public static readonly Pine.Core.PineValue List_dbf8c2e1 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_7777977c]);

    public static readonly Pine.Core.PineValue List_e5f133b3 =
        Pine.Core.PineValue.List(
            [List_450c12a0, List_a457124a]);

    public static readonly Pine.Core.PineValue List_0dcc94b1 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_7777977c]);

    public static readonly Pine.Core.PineValue List_ef649a31 =
        Pine.Core.PineValue.List(
            [List_0c82888c, List_a457124a]);

    public static readonly Pine.Core.PineValue List_8e7447f8 =
        Pine.Core.PineValue.List(
            [List_23afeea9, List_45aab610, List_1f27fb25]);

    public static readonly Pine.Core.PineValue List_17675c6d =
        Pine.Core.PineValue.List(
            [List_7e774b12, List_0da2d82f, List_23bb8f95]);

    public static readonly Pine.Core.PineValue List_0fcda3c8 =
        Pine.Core.PineValue.List(
            [List_a39c07a7, List_8a25cb53, List_69f0dbcb]);

    public static readonly Pine.Core.PineValue List_Single_List_518c5790 =
        Pine.Core.PineValue.List(
            [List_518c5790]);

    public static readonly Pine.Core.PineValue List_Single_List_cc973075 =
        Pine.Core.PineValue.List(
            [List_cc973075]);

    public static readonly Pine.Core.PineValue List_Single_List_31c4029f =
        Pine.Core.PineValue.List(
            [List_31c4029f]);

    public static readonly Pine.Core.PineValue List_Single_List_298d2735 =
        Pine.Core.PineValue.List(
            [List_298d2735]);

    public static readonly Pine.Core.PineValue List_Single_List_dbf8c2e1 =
        Pine.Core.PineValue.List(
            [List_dbf8c2e1]);

    public static readonly Pine.Core.PineValue List_Single_List_e5f133b3 =
        Pine.Core.PineValue.List(
            [List_e5f133b3]);

    public static readonly Pine.Core.PineValue List_Single_List_0dcc94b1 =
        Pine.Core.PineValue.List(
            [List_0dcc94b1]);

    public static readonly Pine.Core.PineValue List_Single_List_ef649a31 =
        Pine.Core.PineValue.List(
            [List_ef649a31]);

    public static readonly Pine.Core.PineValue List_acc1e45d =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_f4ae3a57]);

    public static readonly Pine.Core.PineValue List_4635377f =
        Pine.Core.PineValue.List(
            [List_9aed9073, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_6672399d =
        Pine.Core.PineValue.List(
            [List_49eff0fb, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_c9eed7e1 =
        Pine.Core.PineValue.List(
            [List_0218d8fb, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_ab26e841 =
        Pine.Core.PineValue.List(
            [List_a872793e, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_63aa53a6 =
        Pine.Core.PineValue.List(
            [List_5df552c8, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_031f66a4 =
        Pine.Core.PineValue.List(
            [List_d219d6b8, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_6878fbae =
        Pine.Core.PineValue.List(
            [List_3e03e978, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_0b458b1a =
        Pine.Core.PineValue.List(
            [List_a9acb40e, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_ad8a74fa =
        Pine.Core.PineValue.List(
            [List_31f795f9, List_d08202cd, List_c18dedfa]);

    public static readonly Pine.Core.PineValue List_Single_List_4635377f =
        Pine.Core.PineValue.List(
            [List_4635377f]);

    public static readonly Pine.Core.PineValue List_Single_List_6672399d =
        Pine.Core.PineValue.List(
            [List_6672399d]);

    public static readonly Pine.Core.PineValue List_Single_List_c9eed7e1 =
        Pine.Core.PineValue.List(
            [List_c9eed7e1]);

    public static readonly Pine.Core.PineValue List_Single_List_ab26e841 =
        Pine.Core.PineValue.List(
            [List_ab26e841]);

    public static readonly Pine.Core.PineValue List_Single_List_63aa53a6 =
        Pine.Core.PineValue.List(
            [List_63aa53a6]);

    public static readonly Pine.Core.PineValue List_Single_List_031f66a4 =
        Pine.Core.PineValue.List(
            [List_031f66a4]);

    public static readonly Pine.Core.PineValue List_Single_List_6878fbae =
        Pine.Core.PineValue.List(
            [List_6878fbae]);

    public static readonly Pine.Core.PineValue List_Single_List_0b458b1a =
        Pine.Core.PineValue.List(
            [List_0b458b1a]);

    public static readonly Pine.Core.PineValue List_Single_List_ad8a74fa =
        Pine.Core.PineValue.List(
            [List_ad8a74fa]);

    public static readonly Pine.Core.PineValue List_ca265c68 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_699247d4]);

    public static readonly Pine.Core.PineValue List_Single_List_ca265c68 =
        Pine.Core.PineValue.List(
            [List_ca265c68]);

    public static readonly Pine.Core.PineValue List_877861fd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5bd7a740]);

    public static readonly Pine.Core.PineValue List_41d0d5d0 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_ddd7bbf2]);

    public static readonly Pine.Core.PineValue List_e9d61e9b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_518c5790]);

    public static readonly Pine.Core.PineValue List_2264d07e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cc973075]);

    public static readonly Pine.Core.PineValue List_cb3d7f63 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_31c4029f]);

    public static readonly Pine.Core.PineValue List_08e5b863 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_298d2735]);

    public static readonly Pine.Core.PineValue List_9986bc7b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_dbf8c2e1]);

    public static readonly Pine.Core.PineValue List_4585571c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e5f133b3]);

    public static readonly Pine.Core.PineValue List_fa3ca106 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0dcc94b1]);

    public static readonly Pine.Core.PineValue List_2e636589 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ef649a31]);

    public static readonly Pine.Core.PineValue List_d1771104 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f39f81d4]);

    public static readonly Pine.Core.PineValue List_bf0ab349 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_3cb1c868]);

    public static readonly Pine.Core.PineValue List_788881c1 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_a57974b9]);

    public static readonly Pine.Core.PineValue List_cc8f7824 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4635377f]);

    public static readonly Pine.Core.PineValue List_011f407c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6672399d]);

    public static readonly Pine.Core.PineValue List_667c9363 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c9eed7e1]);

    public static readonly Pine.Core.PineValue List_21b74b8b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ab26e841]);

    public static readonly Pine.Core.PineValue List_27875f84 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_63aa53a6]);

    public static readonly Pine.Core.PineValue List_adbbe5a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_031f66a4]);

    public static readonly Pine.Core.PineValue List_a34d5014 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6878fbae]);

    public static readonly Pine.Core.PineValue List_b0af1246 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0b458b1a]);

    public static readonly Pine.Core.PineValue List_79b71d01 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ad8a74fa]);

    public static readonly Pine.Core.PineValue List_bde657f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ca265c68]);

    public static readonly Pine.Core.PineValue List_49ac5480 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_d1771104]);

    public static readonly Pine.Core.PineValue List_ee4f6b8c =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_e9d61e9b]);

    public static readonly Pine.Core.PineValue List_5861c7bf =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_2264d07e]);

    public static readonly Pine.Core.PineValue List_925af064 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_cb3d7f63]);

    public static readonly Pine.Core.PineValue List_dfcfbcb6 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_08e5b863]);

    public static readonly Pine.Core.PineValue List_6be83bfe =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_9986bc7b]);

    public static readonly Pine.Core.PineValue List_e99410be =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_4585571c]);

    public static readonly Pine.Core.PineValue List_a76e903e =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_fa3ca106]);

    public static readonly Pine.Core.PineValue List_bec4b872 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_2e636589]);

    public static readonly Pine.Core.PineValue List_b4d515a0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_73d3e16a]);

    public static readonly Pine.Core.PineValue List_ad67682c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1ad7dd6f]);

    public static readonly Pine.Core.PineValue List_eaaa836e =
        Pine.Core.PineValue.List(
            [List_976730e9, List_71bd74cc]);

    public static readonly Pine.Core.PineValue List_27dcaaeb =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_9b16ca67]);

    public static readonly Pine.Core.PineValue List_c5775cc4 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_9b16ca67]);

    public static readonly Pine.Core.PineValue List_de67f37d =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8e7447f8]);

    public static readonly Pine.Core.PineValue List_b2424253 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_17675c6d]);

    public static readonly Pine.Core.PineValue List_2fc55208 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0fcda3c8]);

    public static readonly Pine.Core.PineValue List_d84a076a =
        Pine.Core.PineValue.List(
            [List_a29fb86d, List_c845a04b]);

    public static readonly Pine.Core.PineValue List_Single_List_d84a076a =
        Pine.Core.PineValue.List(
            [List_d84a076a]);

    public static readonly Pine.Core.PineValue List_c32e7ca5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_445d811c]);

    public static readonly Pine.Core.PineValue List_9290d400 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_896490d8]);

    public static readonly Pine.Core.PineValue List_4a516ff5 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_acc1e45d]);

    public static readonly Pine.Core.PineValue List_191d6742 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_b2424253]);

    public static readonly Pine.Core.PineValue List_355577ca =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_2fc55208]);

    public static readonly Pine.Core.PineValue List_15d2d3fa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d84a076a]);

    public static readonly Pine.Core.PineValue List_393be4f5 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_379afe98]);

    public static readonly Pine.Core.PineValue List_10cf9594 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_41d0d5d0]);

    public static readonly Pine.Core.PineValue List_b5624a27 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_4a8e6287]);

    public static readonly Pine.Core.PineValue List_Single_List_b5624a27 =
        Pine.Core.PineValue.List(
            [List_b5624a27]);

    public static readonly Pine.Core.PineValue List_81b0d7df =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c32e7ca5]);

    public static readonly Pine.Core.PineValue List_5504e145 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_9290d400]);

    public static readonly Pine.Core.PineValue List_03bd1ef9 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_788881c1]);

    public static readonly Pine.Core.PineValue List_8a104c81 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_f2fd581c]);

    public static readonly Pine.Core.PineValue List_Single_List_8a104c81 =
        Pine.Core.PineValue.List(
            [List_8a104c81]);

    public static readonly Pine.Core.PineValue List_b8411543 =
        Pine.Core.PineValue.List(
            [List_2ebf8fc7, List_bb14d771, List_9eca7ab0]);

    public static readonly Pine.Core.PineValue List_0245b2cf =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_de67f37d]);

    public static readonly Pine.Core.PineValue List_Single_List_0245b2cf =
        Pine.Core.PineValue.List(
            [List_0245b2cf]);

    public static readonly Pine.Core.PineValue List_0096e3c5 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6d83c098]);

    public static readonly Pine.Core.PineValue List_9cbdbf53 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b5624a27]);

    public static readonly Pine.Core.PineValue List_60088c4e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_eaaa836e]);

    public static readonly Pine.Core.PineValue List_260d6b0f =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_27dcaaeb]);

    public static readonly Pine.Core.PineValue List_fee632d1 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c5775cc4]);

    public static readonly Pine.Core.PineValue List_bb9c9ce5 =
        Pine.Core.PineValue.List(
            [List_393b2916, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_Single_List_bb9c9ce5 =
        Pine.Core.PineValue.List(
            [List_bb9c9ce5]);

    public static readonly Pine.Core.PineValue List_027d590a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8a104c81]);

    public static readonly Pine.Core.PineValue List_862e6f97 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_475c68bb]);

    public static readonly Pine.Core.PineValue List_454e3b62 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0245b2cf]);

    public static readonly Pine.Core.PineValue List_9942ba82 =
        Pine.Core.PineValue.List(
            [List_8799f419, List_910e92c3]);

    public static readonly Pine.Core.PineValue List_f19eb87e =
        Pine.Core.PineValue.List(
            [List_908ec70a, List_fe634606]);

    public static readonly Pine.Core.PineValue List_a7fdea10 =
        Pine.Core.PineValue.List(
            [List_fe634606, List_8e784b64]);

    public static readonly Pine.Core.PineValue List_Single_List_9942ba82 =
        Pine.Core.PineValue.List(
            [List_9942ba82]);

    public static readonly Pine.Core.PineValue List_Single_List_f19eb87e =
        Pine.Core.PineValue.List(
            [List_f19eb87e]);

    public static readonly Pine.Core.PineValue List_Single_List_a7fdea10 =
        Pine.Core.PineValue.List(
            [List_a7fdea10]);

    public static readonly Pine.Core.PineValue List_3895a2d2 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_49ac5480]);

    public static readonly Pine.Core.PineValue List_344daacb =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ee4f6b8c]);

    public static readonly Pine.Core.PineValue List_ee4003dd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5861c7bf]);

    public static readonly Pine.Core.PineValue List_c7b26fe5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_925af064]);

    public static readonly Pine.Core.PineValue List_eca174a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_dfcfbcb6]);

    public static readonly Pine.Core.PineValue List_a8bb8f89 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6be83bfe]);

    public static readonly Pine.Core.PineValue List_497dc76e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_e99410be]);

    public static readonly Pine.Core.PineValue List_b1e78cd1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a76e903e]);

    public static readonly Pine.Core.PineValue List_ce472c25 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_bec4b872]);

    public static readonly Pine.Core.PineValue List_477bf78d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_9cbdbf53]);

    public static readonly Pine.Core.PineValue List_8ee35845 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bb9c9ce5]);

    public static readonly Pine.Core.PineValue List_2c640702 =
        Pine.Core.PineValue.List(
            [List_932561b8, List_7349334d]);

    public static readonly Pine.Core.PineValue List_16da9886 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_393be4f5]);

    public static readonly Pine.Core.PineValue List_1d181cbb =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_454e3b62]);

    public static readonly Pine.Core.PineValue List_e06e7aab =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9942ba82]);

    public static readonly Pine.Core.PineValue List_22eac237 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f19eb87e]);

    public static readonly Pine.Core.PineValue List_2ef79331 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a7fdea10]);

    public static readonly Pine.Core.PineValue List_Single_List_2ef79331 =
        Pine.Core.PineValue.List(
            [List_2ef79331]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_2ef79331 =
        Pine.Core.PineValue.List(
            [List_Single_List_2ef79331]);

    public static readonly Pine.Core.PineValue List_ba90507d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_3895a2d2]);

    public static readonly Pine.Core.PineValue List_368a14a6 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_344daacb]);

    public static readonly Pine.Core.PineValue List_3fe65da2 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ee4003dd]);

    public static readonly Pine.Core.PineValue List_f9d77642 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c7b26fe5]);

    public static readonly Pine.Core.PineValue List_53c5c763 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_eca174a5]);

    public static readonly Pine.Core.PineValue List_20438c3d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_a8bb8f89]);

    public static readonly Pine.Core.PineValue List_edb12ee4 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_497dc76e]);

    public static readonly Pine.Core.PineValue List_ce88c16e =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_b1e78cd1]);

    public static readonly Pine.Core.PineValue List_4e45ec90 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_ce472c25]);

    public static readonly Pine.Core.PineValue List_7d363e54 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_b8411543]);

    public static readonly Pine.Core.PineValue List_12af8dcc =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_0096e3c5]);

    public static readonly Pine.Core.PineValue List_0e5d5f28 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_191d6742]);

    public static readonly Pine.Core.PineValue List_4338879c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_355577ca]);

    public static readonly Pine.Core.PineValue List_ff23b3ab =
        Pine.Core.PineValue.List(
            [List_754ca20c, List_7efafede, List_27311de8]);

    public static readonly Pine.Core.PineValue List_4a590cf0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_2ef79331]);

    public static readonly Pine.Core.PineValue List_651c04b6 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_81b0d7df]);

    public static readonly Pine.Core.PineValue List_3e468e0c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_5504e145]);

    public static readonly Pine.Core.PineValue List_a38faf18 =
        Pine.Core.PineValue.List(
            [List_86d38b8d, List_1ea6eb3f]);

    public static readonly Pine.Core.PineValue List_2d613de1 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_862e6f97]);

    public static readonly Pine.Core.PineValue List_666160ed =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_e06e7aab]);

    public static readonly Pine.Core.PineValue List_9e69b6f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_22eac237]);

    public static readonly Pine.Core.PineValue List_43fb4833 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_cc8f7824]);

    public static readonly Pine.Core.PineValue List_0f0702ce =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_011f407c]);

    public static readonly Pine.Core.PineValue List_2f08ed58 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_667c9363]);

    public static readonly Pine.Core.PineValue List_df92330a =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_21b74b8b]);

    public static readonly Pine.Core.PineValue List_0c548927 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_27875f84]);

    public static readonly Pine.Core.PineValue List_2b12a359 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_adbbe5a9]);

    public static readonly Pine.Core.PineValue List_9f81b992 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a34d5014]);

    public static readonly Pine.Core.PineValue List_11761275 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_b0af1246]);

    public static readonly Pine.Core.PineValue List_90679fbd =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_79b71d01]);

    public static readonly Pine.Core.PineValue List_Single_List_43fb4833 =
        Pine.Core.PineValue.List(
            [List_43fb4833]);

    public static readonly Pine.Core.PineValue List_Single_List_0f0702ce =
        Pine.Core.PineValue.List(
            [List_0f0702ce]);

    public static readonly Pine.Core.PineValue List_Single_List_2f08ed58 =
        Pine.Core.PineValue.List(
            [List_2f08ed58]);

    public static readonly Pine.Core.PineValue List_Single_List_df92330a =
        Pine.Core.PineValue.List(
            [List_df92330a]);

    public static readonly Pine.Core.PineValue List_Single_List_0c548927 =
        Pine.Core.PineValue.List(
            [List_0c548927]);

    public static readonly Pine.Core.PineValue List_Single_List_2b12a359 =
        Pine.Core.PineValue.List(
            [List_2b12a359]);

    public static readonly Pine.Core.PineValue List_Single_List_9f81b992 =
        Pine.Core.PineValue.List(
            [List_9f81b992]);

    public static readonly Pine.Core.PineValue List_Single_List_11761275 =
        Pine.Core.PineValue.List(
            [List_11761275]);

    public static readonly Pine.Core.PineValue List_Single_List_90679fbd =
        Pine.Core.PineValue.List(
            [List_90679fbd]);

    public static readonly Pine.Core.PineValue List_12546944 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_2c640702]);

    public static readonly Pine.Core.PineValue List_dd072c3a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_477bf78d]);

    public static readonly Pine.Core.PineValue List_6069af9b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_43fb4833]);

    public static readonly Pine.Core.PineValue List_7573e949 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0f0702ce]);

    public static readonly Pine.Core.PineValue List_8fa9fa01 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2f08ed58]);

    public static readonly Pine.Core.PineValue List_63ac5bf4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_df92330a]);

    public static readonly Pine.Core.PineValue List_00906c35 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0c548927]);

    public static readonly Pine.Core.PineValue List_1f3437ea =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2b12a359]);

    public static readonly Pine.Core.PineValue List_58e62aa3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9f81b992]);

    public static readonly Pine.Core.PineValue List_5419f445 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_11761275]);

    public static readonly Pine.Core.PineValue List_0e571eb6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_90679fbd]);

    public static readonly Pine.Core.PineValue List_6538d979 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_ff23b3ab]);

    public static readonly Pine.Core.PineValue List_dc9135bc =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_651c04b6]);

    public static readonly Pine.Core.PineValue List_7343aaf1 =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_3e468e0c]);

    public static readonly Pine.Core.PineValue List_Single_List_dc9135bc =
        Pine.Core.PineValue.List(
            [List_dc9135bc]);

    public static readonly Pine.Core.PineValue List_Single_List_7343aaf1 =
        Pine.Core.PineValue.List(
            [List_7343aaf1]);

    public static readonly Pine.Core.PineValue List_c6fbbbde =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1d181cbb]);

    public static readonly Pine.Core.PineValue List_a3a6096a =
        Pine.Core.PineValue.List(
            [List_976730e9, List_d7451e5d]);

    public static readonly Pine.Core.PineValue List_869bd022 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ba90507d]);

    public static readonly Pine.Core.PineValue List_a2ee8d46 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_368a14a6]);

    public static readonly Pine.Core.PineValue List_21e2e78c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3fe65da2]);

    public static readonly Pine.Core.PineValue List_a33211c9 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f9d77642]);

    public static readonly Pine.Core.PineValue List_feff2aab =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_53c5c763]);

    public static readonly Pine.Core.PineValue List_8594e303 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_20438c3d]);

    public static readonly Pine.Core.PineValue List_a7dbe08c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_edb12ee4]);

    public static readonly Pine.Core.PineValue List_16950cca =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_ce88c16e]);

    public static readonly Pine.Core.PineValue List_02b9e69e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_4e45ec90]);

    public static readonly Pine.Core.PineValue List_358f0447 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a38faf18]);

    public static readonly Pine.Core.PineValue List_1c25c321 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_dc9135bc]);

    public static readonly Pine.Core.PineValue List_3e04813b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7343aaf1]);

    public static readonly Pine.Core.PineValue List_09a8370d =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_c6fbbbde]);

    public static readonly Pine.Core.PineValue List_c1c7ff87 =
        Pine.Core.PineValue.List(
            [List_d1b1c293, List_9c6e5910]);

    public static readonly Pine.Core.PineValue List_838322f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_869bd022]);

    public static readonly Pine.Core.PineValue List_dd702340 =
        Pine.Core.PineValue.List(
            [List_87e4f8c6, List_edaed8fa, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_42d3646e =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_666160ed]);

    public static readonly Pine.Core.PineValue List_43468879 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9e69b6f7]);

    public static readonly Pine.Core.PineValue List_2e56d528 =
        Pine.Core.PineValue.List(
            [List_e6a1f4f0, List_9d653d49, List_34849c45]);

    public static readonly Pine.Core.PineValue List_8739deb3 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_1c25c321]);

    public static readonly Pine.Core.PineValue List_d740fa22 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3e04813b]);

    public static readonly Pine.Core.PineValue List_b655de02 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a3a6096a]);

    public static readonly Pine.Core.PineValue List_8b4a1ffc =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_5f71beeb]);

    public static readonly Pine.Core.PineValue List_578ab12b =
        Pine.Core.PineValue.List(
            [List_976730e9, List_bde657f3]);

    public static readonly Pine.Core.PineValue List_603fb901 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c1c7ff87]);

    public static readonly Pine.Core.PineValue List_ccee9d53 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_dd702340]);

    public static readonly Pine.Core.PineValue List_3df81874 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2e56d528]);

    public static readonly Pine.Core.PineValue List_Single_List_3df81874 =
        Pine.Core.PineValue.List(
            [List_3df81874]);

    public static readonly Pine.Core.PineValue List_ce5b6f29 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_09a8370d]);

    public static readonly Pine.Core.PineValue List_f66d1c20 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_d08202cd, List_b43468c9, List_edbaaf20]);

    public static readonly Pine.Core.PineValue List_Single_List_f66d1c20 =
        Pine.Core.PineValue.List(
            [List_f66d1c20]);

    public static readonly Pine.Core.PineValue List_1baf882a =
        Pine.Core.PineValue.List(
            [List_b2b822a8, List_bb14d771, List_9eca7ab0]);

    public static readonly Pine.Core.PineValue List_6d4c8c87 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_838322f4]);

    public static readonly Pine.Core.PineValue List_0d21a07f =
        Pine.Core.PineValue.List(
            [List_976730e9, List_15d2d3fa]);

    public static readonly Pine.Core.PineValue List_4f6d8d0c =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_fa47e3e4]);

    public static readonly Pine.Core.PineValue List_55b77daa =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_f8ddc64b]);

    public static readonly Pine.Core.PineValue List_Single_List_4f6d8d0c =
        Pine.Core.PineValue.List(
            [List_4f6d8d0c]);

    public static readonly Pine.Core.PineValue List_Single_List_55b77daa =
        Pine.Core.PineValue.List(
            [List_55b77daa]);

    public static readonly Pine.Core.PineValue List_df7af572 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f66d1c20]);

    public static readonly Pine.Core.PineValue List_61c0303c =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_8b4a1ffc]);

    public static readonly Pine.Core.PineValue List_Single_List_61c0303c =
        Pine.Core.PineValue.List(
            [List_61c0303c]);

    public static readonly Pine.Core.PineValue List_d635b8fa =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_8739deb3]);

    public static readonly Pine.Core.PineValue List_555ff973 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d740fa22]);

    public static readonly Pine.Core.PineValue List_74840517 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_3df81874]);

    public static readonly Pine.Core.PineValue List_b9327097 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_578ab12b]);

    public static readonly Pine.Core.PineValue List_aaf5038a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4f6d8d0c]);

    public static readonly Pine.Core.PineValue List_88d3968d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_55b77daa]);

    public static readonly Pine.Core.PineValue List_5c15b6df =
        Pine.Core.PineValue.List(
            [List_b4306b44, List_c0abcf7c]);

    public static readonly Pine.Core.PineValue List_Single_List_5c15b6df =
        Pine.Core.PineValue.List(
            [List_5c15b6df]);

    public static readonly Pine.Core.PineValue List_4f90835d =
        Pine.Core.PineValue.List(
            [List_f8d1f5d9, List_78c00b43]);

    public static readonly Pine.Core.PineValue List_baacda1e =
        Pine.Core.PineValue.List(
            [List_f8d1f5d9, List_2a486760]);

    public static readonly Pine.Core.PineValue List_97b8d591 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_61c0303c]);

    public static readonly Pine.Core.PineValue List_def87e98 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_1baf882a]);

    public static readonly Pine.Core.PineValue List_a01b4421 =
        Pine.Core.PineValue.List(
            [List_d07a7cd8, List_6d4c8c87]);

    public static readonly Pine.Core.PineValue List_af893397 =
        Pine.Core.PineValue.List(
            [List_df7af572, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_a01b4421 =
        Pine.Core.PineValue.List(
            [List_a01b4421]);

    public static readonly Pine.Core.PineValue List_Single_List_af893397 =
        Pine.Core.PineValue.List(
            [List_af893397]);

    public static readonly Pine.Core.PineValue List_fe27b8e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5c15b6df]);

    public static readonly Pine.Core.PineValue List_f2f2b6da =
        Pine.Core.PineValue.List(
            [List_976730e9, List_8ee35845]);

    public static readonly Pine.Core.PineValue List_57e6d4a8 =
        Pine.Core.PineValue.List(
            [List_6d171847, List_d08202cd, List_13c1b98b]);

    public static readonly Pine.Core.PineValue List_Single_List_57e6d4a8 =
        Pine.Core.PineValue.List(
            [List_57e6d4a8]);

    public static readonly Pine.Core.PineValue List_9156ad01 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_0d21a07f]);

    public static readonly Pine.Core.PineValue List_fd1f748b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a01b4421]);

    public static readonly Pine.Core.PineValue List_3739323d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_af893397]);

    public static readonly Pine.Core.PineValue List_b848898d =
        Pine.Core.PineValue.List(
            [List_2820c509, List_c7bf96d6, List_45564a6a]);

    public static readonly Pine.Core.PineValue List_ea35af13 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_57e6d4a8]);

    public static readonly Pine.Core.PineValue List_8a9ea724 =
        Pine.Core.PineValue.List(
            [List_ce0b123c, List_bb14d771, List_40975626]);

    public static readonly Pine.Core.PineValue List_2e339403 =
        Pine.Core.PineValue.List(
            [List_a76941ad, List_bb14d771, List_0331bb71]);

    public static readonly Pine.Core.PineValue List_2b202add =
        Pine.Core.PineValue.List(
            [List_c28a17e2, List_bb14d771, List_bbd76f00]);

    public static readonly Pine.Core.PineValue List_a69ac946 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_fd1f748b]);

    public static readonly Pine.Core.PineValue List_869e9154 =
        Pine.Core.PineValue.List(
            [List_e96a130d, List_bb14d771, List_65f3484c]);

    public static readonly Pine.Core.PineValue List_3b4c17af =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_4f90835d]);

    public static readonly Pine.Core.PineValue List_bb8042f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_baacda1e]);

    public static readonly Pine.Core.PineValue List_25e98d74 =
        Pine.Core.PineValue.List(
            [List_f9782095, List_9156ad01]);

    public static readonly Pine.Core.PineValue List_Single_List_25e98d74 =
        Pine.Core.PineValue.List(
            [List_25e98d74]);

    public static readonly Pine.Core.PineValue List_88a3d478 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_f2f2b6da]);

    public static readonly Pine.Core.PineValue List_b73fc98f =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_bf0ab349]);

    public static readonly Pine.Core.PineValue List_Single_List_b73fc98f =
        Pine.Core.PineValue.List(
            [List_b73fc98f]);

    public static readonly Pine.Core.PineValue List_c477043b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_25e98d74]);

    public static readonly Pine.Core.PineValue List_0b5a4567 =
        Pine.Core.PineValue.List(
            [List_52d1ddaa, List_877861fd]);

    public static readonly Pine.Core.PineValue List_Single_List_0b5a4567 =
        Pine.Core.PineValue.List(
            [List_0b5a4567]);

    public static readonly Pine.Core.PineValue List_b6a1eb7c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_b848898d]);

    public static readonly Pine.Core.PineValue List_Single_List_b6a1eb7c =
        Pine.Core.PineValue.List(
            [List_b6a1eb7c]);

    public static readonly Pine.Core.PineValue List_32e96a90 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b73fc98f]);

    public static readonly Pine.Core.PineValue List_57b14bc1 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6069af9b]);

    public static readonly Pine.Core.PineValue List_25c0c611 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_7573e949]);

    public static readonly Pine.Core.PineValue List_c389ba8c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_8fa9fa01]);

    public static readonly Pine.Core.PineValue List_a16c65eb =
        Pine.Core.PineValue.List(
            [List_976730e9, List_63ac5bf4]);

    public static readonly Pine.Core.PineValue List_dd1857ea =
        Pine.Core.PineValue.List(
            [List_976730e9, List_00906c35]);

    public static readonly Pine.Core.PineValue List_acd1303f =
        Pine.Core.PineValue.List(
            [List_976730e9, List_1f3437ea]);

    public static readonly Pine.Core.PineValue List_ab85f46e =
        Pine.Core.PineValue.List(
            [List_976730e9, List_58e62aa3]);

    public static readonly Pine.Core.PineValue List_cd6eb093 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_5419f445]);

    public static readonly Pine.Core.PineValue List_9d6a367d =
        Pine.Core.PineValue.List(
            [List_976730e9, List_0e571eb6]);

    public static readonly Pine.Core.PineValue List_f6e93da1 =
        Pine.Core.PineValue.List(
            [List_d2e3da11, List_1ad2ee97, List_1a0b8610]);

    public static readonly Pine.Core.PineValue List_a79c14f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8a9ea724]);

    public static readonly Pine.Core.PineValue List_35e000d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2e339403]);

    public static readonly Pine.Core.PineValue List_963aea9c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2b202add]);

    public static readonly Pine.Core.PineValue List_d0ef44d0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0b5a4567]);

    public static readonly Pine.Core.PineValue List_113848b7 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_869e9154]);

    public static readonly Pine.Core.PineValue List_71a5974d =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_c477043b]);

    public static readonly Pine.Core.PineValue List_21f29a75 =
        Pine.Core.PineValue.List(
            [List_6cab91e9, List_d1125cdd]);

    public static readonly Pine.Core.PineValue List_dd76f543 =
        Pine.Core.PineValue.List(
            [List_c42737be, List_d003d670, List_6386e244]);

    public static readonly Pine.Core.PineValue List_Single_List_21f29a75 =
        Pine.Core.PineValue.List(
            [List_21f29a75]);

    public static readonly Pine.Core.PineValue List_80650b69 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_b6a1eb7c]);

    public static readonly Pine.Core.PineValue List_b217e5fc =
        Pine.Core.PineValue.List(
            [Blob_Str_int_mul, List_32e96a90]);

    public static readonly Pine.Core.PineValue List_9f5c9fad =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_a69ac946]);

    public static readonly Pine.Core.PineValue List_8f24da42 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_21f29a75]);

    public static readonly Pine.Core.PineValue List_da3e1308 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_aaf5038a]);

    public static readonly Pine.Core.PineValue List_fa583eec =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_88d3968d]);

    public static readonly Pine.Core.PineValue List_Single_List_da3e1308 =
        Pine.Core.PineValue.List(
            [List_da3e1308]);

    public static readonly Pine.Core.PineValue List_Single_List_fa583eec =
        Pine.Core.PineValue.List(
            [List_fa583eec]);

    public static readonly Pine.Core.PineValue List_86c6c691 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f6e93da1]);

    public static readonly Pine.Core.PineValue List_287a2adc =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_57b14bc1]);

    public static readonly Pine.Core.PineValue List_34c68982 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_25c0c611]);

    public static readonly Pine.Core.PineValue List_cff1b75c =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c389ba8c]);

    public static readonly Pine.Core.PineValue List_49f51a1b =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a16c65eb]);

    public static readonly Pine.Core.PineValue List_76001a59 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_dd1857ea]);

    public static readonly Pine.Core.PineValue List_531d1306 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_acd1303f]);

    public static readonly Pine.Core.PineValue List_9a5c3716 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_ab85f46e]);

    public static readonly Pine.Core.PineValue List_b6f66fe2 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_cd6eb093]);

    public static readonly Pine.Core.PineValue List_b521036e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_9d6a367d]);

    public static readonly Pine.Core.PineValue List_12c3dbb4 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_027d590a]);

    public static readonly Pine.Core.PineValue List_15187dc7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_da3e1308]);

    public static readonly Pine.Core.PineValue List_c9b5a117 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_fa583eec]);

    public static readonly Pine.Core.PineValue List_07385e0e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_dd76f543]);

    public static readonly Pine.Core.PineValue List_04f36792 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_71a5974d]);

    public static readonly Pine.Core.PineValue List_721028b9 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_ea35af13]);

    public static readonly Pine.Core.PineValue List_Single_List_721028b9 =
        Pine.Core.PineValue.List(
            [List_721028b9]);

    public static readonly Pine.Core.PineValue List_52f8edbd =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b217e5fc]);

    public static readonly Pine.Core.PineValue List_a060ab93 =
        Pine.Core.PineValue.List(
            [List_0dcd86c0, List_07385e0e]);

    public static readonly Pine.Core.PineValue List_Single_List_a060ab93 =
        Pine.Core.PineValue.List(
            [List_a060ab93]);

    public static readonly Pine.Core.PineValue List_26eed01a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_12c3dbb4]);

    public static readonly Pine.Core.PineValue List_Single_List_26eed01a =
        Pine.Core.PineValue.List(
            [List_26eed01a]);

    public static readonly Pine.Core.PineValue List_7f207ea8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_721028b9]);

    public static readonly Pine.Core.PineValue List_107d83e1 =
        Pine.Core.PineValue.List(
            [List_2c6083ca, List_1da3871f]);

    public static readonly Pine.Core.PineValue List_Single_List_107d83e1 =
        Pine.Core.PineValue.List(
            [List_107d83e1]);

    public static readonly Pine.Core.PineValue List_a6fd9c1f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a060ab93]);

    public static readonly Pine.Core.PineValue List_3d704819 =
        Pine.Core.PineValue.List(
            [Blob_Str_negate, List_52f8edbd]);

    public static readonly Pine.Core.PineValue List_00e3a1ad =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_107d83e1]);

    public static readonly Pine.Core.PineValue List_567b0fae =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_26eed01a]);

    public static readonly Pine.Core.PineValue List_18fae7c2 =
        Pine.Core.PineValue.List(
            [List_d766d462, List_2b405904]);

    public static readonly Pine.Core.PineValue List_Single_List_18fae7c2 =
        Pine.Core.PineValue.List(
            [List_18fae7c2]);

    public static readonly Pine.Core.PineValue List_b1cc18a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_a6fd9c1f]);

    public static readonly Pine.Core.PineValue List_452ca71c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_fe27b8e4]);

    public static readonly Pine.Core.PineValue List_73216fb1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_18fae7c2]);

    public static readonly Pine.Core.PineValue List_6f3e5f31 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_00e3a1ad]);

    public static readonly Pine.Core.PineValue List_51e62e8a =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3d704819]);

    public static readonly Pine.Core.PineValue List_d3605d1a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_452ca71c]);

    public static readonly Pine.Core.PineValue List_6129cd4b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b1cc18a9]);

    public static readonly Pine.Core.PineValue List_0b974085 =
        Pine.Core.PineValue.List(
            [List_be509776, List_ce1640f4]);

    public static readonly Pine.Core.PineValue List_22c0f4df =
        Pine.Core.PineValue.List(
            [List_be509776, List_c26a1677]);

    public static readonly Pine.Core.PineValue List_f69a0ab7 =
        Pine.Core.PineValue.List(
            [List_2f1cd3eb, List_ce1640f4]);

    public static readonly Pine.Core.PineValue List_Single_List_0b974085 =
        Pine.Core.PineValue.List(
            [List_0b974085]);

    public static readonly Pine.Core.PineValue List_Single_List_22c0f4df =
        Pine.Core.PineValue.List(
            [List_22c0f4df]);

    public static readonly Pine.Core.PineValue List_Single_List_f69a0ab7 =
        Pine.Core.PineValue.List(
            [List_f69a0ab7]);

    public static readonly Pine.Core.PineValue List_3540f806 =
        Pine.Core.PineValue.List(
            [Blob_Str_head, List_6129cd4b]);

    public static readonly Pine.Core.PineValue List_ef2f17f4 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6f3e5f31]);

    public static readonly Pine.Core.PineValue List_2d40109a =
        Pine.Core.PineValue.List(
            [List_690b75ce, List_2e378702]);

    public static readonly Pine.Core.PineValue List_Single_List_2d40109a =
        Pine.Core.PineValue.List(
            [List_2d40109a]);

    public static readonly Pine.Core.PineValue List_6fe2ac51 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_d3605d1a]);

    public static readonly Pine.Core.PineValue List_9c721f73 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0b974085]);

    public static readonly Pine.Core.PineValue List_6738306c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_22c0f4df]);

    public static readonly Pine.Core.PineValue List_97c20d48 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f69a0ab7]);

    public static readonly Pine.Core.PineValue List_8f3bc505 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2d40109a]);

    public static readonly Pine.Core.PineValue List_37ea0b2f =
        Pine.Core.PineValue.List(
            [List_c8267de8, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_Single_List_37ea0b2f =
        Pine.Core.PineValue.List(
            [List_37ea0b2f]);

    public static readonly Pine.Core.PineValue List_ffbc9542 =
        Pine.Core.PineValue.List(
            [List_393b2916, List_2b405904]);

    public static readonly Pine.Core.PineValue List_Single_List_ffbc9542 =
        Pine.Core.PineValue.List(
            [List_ffbc9542]);

    public static readonly Pine.Core.PineValue List_1d4c0299 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_37ea0b2f]);

    public static readonly Pine.Core.PineValue List_c053f6c1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ffbc9542]);

    public static readonly Pine.Core.PineValue List_c27949d0 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_3540f806]);

    public static readonly Pine.Core.PineValue List_e9b2af54 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_6fe2ac51]);

    public static readonly Pine.Core.PineValue List_Single_List_e9b2af54 =
        Pine.Core.PineValue.List(
            [List_e9b2af54]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_e9b2af54 =
        Pine.Core.PineValue.List(
            [List_Single_List_e9b2af54]);

    public static readonly Pine.Core.PineValue List_81d4d04c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_b43468c9, List_4af1f0ec, List_768cc61e, List_fc312819]);

    public static readonly Pine.Core.PineValue List_Single_List_81d4d04c =
        Pine.Core.PineValue.List(
            [List_81d4d04c]);

    public static readonly Pine.Core.PineValue List_6a341735 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_e9b2af54]);

    public static readonly Pine.Core.PineValue List_520e0c9b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_81d4d04c]);

    public static readonly Pine.Core.PineValue List_22024894 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_7f207ea8]);

    public static readonly Pine.Core.PineValue List_3a47e371 =
        Pine.Core.PineValue.List(
            [List_88ffdbcf, List_bb14d771, List_5bca49c8]);

    public static readonly Pine.Core.PineValue List_cbcb597c =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_603fb901]);

    public static readonly Pine.Core.PineValue List_b7793ca9 =
        Pine.Core.PineValue.List(
            [List_520e0c9b, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_cbcb597c =
        Pine.Core.PineValue.List(
            [List_cbcb597c]);

    public static readonly Pine.Core.PineValue List_Single_List_b7793ca9 =
        Pine.Core.PineValue.List(
            [List_b7793ca9]);

    public static readonly Pine.Core.PineValue List_306d0627 =
        Pine.Core.PineValue.List(
            [List_60088c4e, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_306d0627 =
        Pine.Core.PineValue.List(
            [List_306d0627]);

    public static readonly Pine.Core.PineValue List_5c2d8bd0 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_6a341735]);

    public static readonly Pine.Core.PineValue List_Single_List_5c2d8bd0 =
        Pine.Core.PineValue.List(
            [List_5c2d8bd0]);

    public static readonly Pine.Core.PineValue List_b36198e0 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_d0ef44d0]);

    public static readonly Pine.Core.PineValue List_c1cf32b5 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_73216fb1]);

    public static readonly Pine.Core.PineValue List_a4271d3f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cbcb597c]);

    public static readonly Pine.Core.PineValue List_8000b22e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b7793ca9]);

    public static readonly Pine.Core.PineValue List_5506574a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_22024894]);

    public static readonly Pine.Core.PineValue List_c0acf525 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_306d0627]);

    public static readonly Pine.Core.PineValue List_523cfc6b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5c2d8bd0]);

    public static readonly Pine.Core.PineValue List_37234ad4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_3a47e371]);

    public static readonly Pine.Core.PineValue List_ec6817b8 =
        Pine.Core.PineValue.List(
            [List_ef375b29, List_ccee9d53, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_fe737dcb =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_c0acf525]);

    public static readonly Pine.Core.PineValue List_0f88bf07 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_15187dc7]);

    public static readonly Pine.Core.PineValue List_e20f46c8 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_c9b5a117]);

    public static readonly Pine.Core.PineValue List_cc6c3cee =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_b36198e0]);

    public static readonly Pine.Core.PineValue List_8d444ffc =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c1cf32b5]);

    public static readonly Pine.Core.PineValue List_662a95bc =
        Pine.Core.PineValue.List(
            [List_a957f465, List_52fe4ebd, List_768cc61e]);

    public static readonly Pine.Core.PineValue List_Single_List_662a95bc =
        Pine.Core.PineValue.List(
            [List_662a95bc]);

    public static readonly Pine.Core.PineValue List_d447a83a =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_768cc61e, List_a71e519b, List_43d1faf6]);

    public static readonly Pine.Core.PineValue List_Single_List_d447a83a =
        Pine.Core.PineValue.List(
            [List_d447a83a]);

    public static readonly Pine.Core.PineValue List_03d75671 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_ec6817b8]);

    public static readonly Pine.Core.PineValue List_a3e9528e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_662a95bc]);

    public static readonly Pine.Core.PineValue List_320dd775 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d447a83a]);

    public static readonly Pine.Core.PineValue List_fa3248df =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_0f88bf07]);

    public static readonly Pine.Core.PineValue List_7c0248ac =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_e20f46c8]);

    public static readonly Pine.Core.PineValue List_eeda8f36 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fe737dcb]);

    public static readonly Pine.Core.PineValue List_Single_List_eeda8f36 =
        Pine.Core.PineValue.List(
            [List_eeda8f36]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_eeda8f36 =
        Pine.Core.PineValue.List(
            [List_Single_List_eeda8f36]);

    public static readonly Pine.Core.PineValue List_2e152bb1 =
        Pine.Core.PineValue.List(
            [List_ae6077ae, List_bb14d771, List_2557831f]);

    public static readonly Pine.Core.PineValue List_acc99fb2 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_eeda8f36]);

    public static readonly Pine.Core.PineValue List_6cb26058 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a4271d3f]);

    public static readonly Pine.Core.PineValue List_Single_List_6cb26058 =
        Pine.Core.PineValue.List(
            [List_6cb26058]);

    public static readonly Pine.Core.PineValue List_e27ee185 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_1d4c0299]);

    public static readonly Pine.Core.PineValue List_0a1550b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6cb26058]);

    public static readonly Pine.Core.PineValue List_0fbc6c50 =
        Pine.Core.PineValue.List(
            [List_2da1ee5d, List_d181119a, List_4a516ff5]);

    public static readonly Pine.Core.PineValue List_ec15df7b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2e152bb1]);

    public static readonly Pine.Core.PineValue List_ea2840b1 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_acc99fb2]);

    public static readonly Pine.Core.PineValue List_Single_List_ea2840b1 =
        Pine.Core.PineValue.List(
            [List_ea2840b1]);

    public static readonly Pine.Core.PineValue List_09546e31 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_320dd775]);

    public static readonly Pine.Core.PineValue List_Single_List_09546e31 =
        Pine.Core.PineValue.List(
            [List_09546e31]);

    public static readonly Pine.Core.PineValue List_525e86e6 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_e27ee185]);

    public static readonly Pine.Core.PineValue List_a5c995b4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ea2840b1]);

    public static readonly Pine.Core.PineValue List_833b887e =
        Pine.Core.PineValue.List(
            [List_121967d3, List_4af1f0ec, List_768cc61e, List_a71e519b, List_2c50f745]);

    public static readonly Pine.Core.PineValue List_14e2cf72 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_a71e519b, List_43d1faf6, List_04ad43ca, List_6a6a2dde]);

    public static readonly Pine.Core.PineValue List_Single_List_833b887e =
        Pine.Core.PineValue.List(
            [List_833b887e]);

    public static readonly Pine.Core.PineValue List_Single_List_14e2cf72 =
        Pine.Core.PineValue.List(
            [List_14e2cf72]);

    public static readonly Pine.Core.PineValue List_cb6cc733 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0fbc6c50]);

    public static readonly Pine.Core.PineValue List_Single_List_cb6cc733 =
        Pine.Core.PineValue.List(
            [List_cb6cc733]);

    public static readonly Pine.Core.PineValue List_e185e50e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_09546e31]);

    public static readonly Pine.Core.PineValue List_7e37a96f =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a3e9528e]);

    public static readonly Pine.Core.PineValue List_Single_List_7e37a96f =
        Pine.Core.PineValue.List(
            [List_7e37a96f]);

    public static readonly Pine.Core.PineValue List_d8a88654 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_4af1f0ec, List_768cc61e, List_7ae431de, List_43d1faf6]);

    public static readonly Pine.Core.PineValue List_Single_List_d8a88654 =
        Pine.Core.PineValue.List(
            [List_d8a88654]);

    public static readonly Pine.Core.PineValue List_c43739d9 =
        Pine.Core.PineValue.List(
            [List_78d72533, List_86c6c691, List_33c6f4ad]);

    public static readonly Pine.Core.PineValue List_c9857e83 =
        Pine.Core.PineValue.List(
            [List_0b37ace8, List_d08202cd, List_4edb9ffe]);

    public static readonly Pine.Core.PineValue List_1288f4a3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_833b887e]);

    public static readonly Pine.Core.PineValue List_4e9d2184 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_14e2cf72]);

    public static readonly Pine.Core.PineValue List_2d3e254a =
        Pine.Core.PineValue.List(
            [List_d611c42e, List_de54c194]);

    public static readonly Pine.Core.PineValue List_Single_List_2d3e254a =
        Pine.Core.PineValue.List(
            [List_2d3e254a]);

    public static readonly Pine.Core.PineValue List_50ac552b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7e37a96f]);

    public static readonly Pine.Core.PineValue List_aaa356eb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d8a88654]);

    public static readonly Pine.Core.PineValue List_2b21856c =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_cb6cc733]);

    public static readonly Pine.Core.PineValue List_0c4c977a =
        Pine.Core.PineValue.List(
            [List_525e86e6, List_cd5e9e27]);

    public static readonly Pine.Core.PineValue List_Single_List_0c4c977a =
        Pine.Core.PineValue.List(
            [List_0c4c977a]);

    public static readonly Pine.Core.PineValue List_a477d0cc =
        Pine.Core.PineValue.List(
            [List_96cfcb00, List_8f3bc505]);

    public static readonly Pine.Core.PineValue List_1907ef60 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2d3e254a]);

    public static readonly Pine.Core.PineValue List_37e7ffd2 =
        Pine.Core.PineValue.List(
            [List_9d026cc8, List_53090eac, List_b521036e]);

    public static readonly Pine.Core.PineValue List_e8f68242 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_b43468c9, List_4af1f0ec, List_24d7b608]);

    public static readonly Pine.Core.PineValue List_Single_List_e8f68242 =
        Pine.Core.PineValue.List(
            [List_e8f68242]);

    public static readonly Pine.Core.PineValue List_3e3bb73c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0c4c977a]);

    public static readonly Pine.Core.PineValue List_93d11250 =
        Pine.Core.PineValue.List(
            [List_ffb3657e, List_8f24da42]);

    public static readonly Pine.Core.PineValue List_289d480d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_1907ef60]);

    public static readonly Pine.Core.PineValue List_6ca63018 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c43739d9]);

    public static readonly Pine.Core.PineValue List_559a7021 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c9857e83]);

    public static readonly Pine.Core.PineValue List_5b00ef88 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e8f68242]);

    public static readonly Pine.Core.PineValue List_d71e2f1d =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_3e3bb73c]);

    public static readonly Pine.Core.PineValue List_0974fbc2 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_c053f6c1]);

    public static readonly Pine.Core.PineValue List_853cd68a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a477d0cc]);

    public static readonly Pine.Core.PineValue List_3d07ca80 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_37e7ffd2]);

    public static readonly Pine.Core.PineValue List_66f4c02d =
        Pine.Core.PineValue.List(
            [List_5b00ef88, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_66f4c02d =
        Pine.Core.PineValue.List(
            [List_66f4c02d]);

    public static readonly Pine.Core.PineValue List_220685f6 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_93d11250]);

    public static readonly Pine.Core.PineValue List_db101cdb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_66f4c02d]);

    public static readonly Pine.Core.PineValue List_638cdb22 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_1288f4a3]);

    public static readonly Pine.Core.PineValue List_0ee9b933 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_4e9d2184]);

    public static readonly Pine.Core.PineValue List_Single_List_638cdb22 =
        Pine.Core.PineValue.List(
            [List_638cdb22]);

    public static readonly Pine.Core.PineValue List_Single_List_0ee9b933 =
        Pine.Core.PineValue.List(
            [List_0ee9b933]);

    public static readonly Pine.Core.PineValue List_8e12e6b0 =
        Pine.Core.PineValue.List(
            [List_4af1f0ec, List_51e62e8a]);

    public static readonly Pine.Core.PineValue List_Single_List_8e12e6b0 =
        Pine.Core.PineValue.List(
            [List_8e12e6b0]);

    public static readonly Pine.Core.PineValue List_0c520c88 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_289d480d]);

    public static readonly Pine.Core.PineValue List_1cd45dc2 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_aaa356eb]);

    public static readonly Pine.Core.PineValue List_Single_List_1cd45dc2 =
        Pine.Core.PineValue.List(
            [List_1cd45dc2]);

    public static readonly Pine.Core.PineValue List_edc1715c =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_0974fbc2]);

    public static readonly Pine.Core.PineValue List_a88e2911 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_638cdb22]);

    public static readonly Pine.Core.PineValue List_a29aeeb1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0ee9b933]);

    public static readonly Pine.Core.PineValue List_f890355b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_d71e2f1d]);

    public static readonly Pine.Core.PineValue List_6c6fefe6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8e12e6b0]);

    public static readonly Pine.Core.PineValue List_05aa1319 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1cd45dc2]);

    public static readonly Pine.Core.PineValue List_fbd24c96 =
        Pine.Core.PineValue.List(
            [Blob_Str_int_add, List_6c6fefe6]);

    public static readonly Pine.Core.PineValue List_7bf5df2a =
        Pine.Core.PineValue.List(
            [List_3dbd846b, List_7ab03670]);

    public static readonly Pine.Core.PineValue List_Single_List_7bf5df2a =
        Pine.Core.PineValue.List(
            [List_7bf5df2a]);

    public static readonly Pine.Core.PineValue List_8500e4f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7bf5df2a]);

    public static readonly Pine.Core.PineValue List_3f5c9f68 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_fbd24c96]);

    public static readonly Pine.Core.PineValue List_73594113 =
        Pine.Core.PineValue.List(
            [List_58c0de4c, List_53090eac, List_644d6208]);

    public static readonly Pine.Core.PineValue List_88c9e884 =
        Pine.Core.PineValue.List(
            [List_ef50b02a, List_bb14d771, List_827bfab6]);

    public static readonly Pine.Core.PineValue List_35b69e32 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_b43468c9, List_4af1f0ec, List_768cc61e, List_147fffd6]);

    public static readonly Pine.Core.PineValue List_Single_List_35b69e32 =
        Pine.Core.PineValue.List(
            [List_35b69e32]);

    public static readonly Pine.Core.PineValue List_a37cafc6 =
        Pine.Core.PineValue.List(
            [List_85a158ff, List_9c721f73]);

    public static readonly Pine.Core.PineValue List_56c17420 =
        Pine.Core.PineValue.List(
            [List_85a158ff, List_6738306c]);

    public static readonly Pine.Core.PineValue List_14b5d4af =
        Pine.Core.PineValue.List(
            [List_925d8478, List_97c20d48]);

    public static readonly Pine.Core.PineValue List_51042947 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_35b69e32]);

    public static readonly Pine.Core.PineValue List_452ea1d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_73594113]);

    public static readonly Pine.Core.PineValue List_654bdd12 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_88c9e884]);

    public static readonly Pine.Core.PineValue List_0ec64a62 =
        Pine.Core.PineValue.List(
            [List_142a1a25, List_8263e85a, List_be2048c0]);

    public static readonly Pine.Core.PineValue List_156a7503 =
        Pine.Core.PineValue.List(
            [List_51042947, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_156a7503 =
        Pine.Core.PineValue.List(
            [List_156a7503]);

    public static readonly Pine.Core.PineValue List_9c7dfe0d =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_50ac552b]);

    public static readonly Pine.Core.PineValue List_7893301e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a37cafc6]);

    public static readonly Pine.Core.PineValue List_dd8a4914 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_56c17420]);

    public static readonly Pine.Core.PineValue List_4ea01748 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_14b5d4af]);

    public static readonly Pine.Core.PineValue List_5420d5e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_156a7503]);

    public static readonly Pine.Core.PineValue List_2c20063c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0ec64a62]);

    public static readonly Pine.Core.PineValue List_Single_List_2c20063c =
        Pine.Core.PineValue.List(
            [List_2c20063c]);

    public static readonly Pine.Core.PineValue List_6bc9132a =
        Pine.Core.PineValue.List(
            [List_809b3b53, List_03d75671, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_b0fff300 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_2c20063c]);

    public static readonly Pine.Core.PineValue List_120ac410 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_9c7dfe0d]);

    public static readonly Pine.Core.PineValue List_dcd694aa =
        Pine.Core.PineValue.List(
            [List_2f8121ff, List_22122af7, List_285af2ab]);

    public static readonly Pine.Core.PineValue List_d97a2014 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6bc9132a]);

    public static readonly Pine.Core.PineValue List_8e1cb5a2 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_c3510f99, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_8e1cb5a2 =
        Pine.Core.PineValue.List(
            [List_8e1cb5a2]);

    public static readonly Pine.Core.PineValue List_0f8e2c6f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8e1cb5a2]);

    public static readonly Pine.Core.PineValue List_83f303b1 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_dcd694aa]);

    public static readonly Pine.Core.PineValue List_429fde37 =
        Pine.Core.PineValue.List(
            [List_59cad394, List_bb14d771, List_def87e98]);

    public static readonly Pine.Core.PineValue List_7e53323f =
        Pine.Core.PineValue.List(
            [List_0f8e2c6f, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_7e53323f =
        Pine.Core.PineValue.List(
            [List_7e53323f]);

    public static readonly Pine.Core.PineValue List_4304596c =
        Pine.Core.PineValue.List(
            [List_8d444ffc, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_4304596c =
        Pine.Core.PineValue.List(
            [List_4304596c]);

    public static readonly Pine.Core.PineValue List_f91a5831 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7e53323f]);

    public static readonly Pine.Core.PineValue List_4f5b0db5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4304596c]);

    public static readonly Pine.Core.PineValue List_d1a85706 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_429fde37]);

    public static readonly Pine.Core.PineValue List_de861c04 =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_4f5b0db5]);

    public static readonly Pine.Core.PineValue List_d04a3784 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_8500e4f7]);

    public static readonly Pine.Core.PineValue List_2350c591 =
        Pine.Core.PineValue.List(
            [List_ad4f2fb3, List_6ca63018, List_c005c994]);

    public static readonly Pine.Core.PineValue List_1e2587a7 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_908ec70a, List_502d34d3]);

    public static readonly Pine.Core.PineValue List_Single_List_1e2587a7 =
        Pine.Core.PineValue.List(
            [List_1e2587a7]);

    public static readonly Pine.Core.PineValue List_ef31635d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1e2587a7]);

    public static readonly Pine.Core.PineValue List_2550597d =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_d04a3784]);

    public static readonly Pine.Core.PineValue List_Single_List_2550597d =
        Pine.Core.PineValue.List(
            [List_2550597d]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_2550597d =
        Pine.Core.PineValue.List(
            [List_Single_List_2550597d]);

    public static readonly Pine.Core.PineValue List_eb732f5b =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_de861c04]);

    public static readonly Pine.Core.PineValue List_Single_List_eb732f5b =
        Pine.Core.PineValue.List(
            [List_eb732f5b]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_eb732f5b =
        Pine.Core.PineValue.List(
            [List_Single_List_eb732f5b]);

    public static readonly Pine.Core.PineValue List_98dd2405 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2350c591]);

    public static readonly Pine.Core.PineValue List_5849f393 =
        Pine.Core.PineValue.List(
            [List_c7765369, List_16da9886]);

    public static readonly Pine.Core.PineValue List_Single_List_5849f393 =
        Pine.Core.PineValue.List(
            [List_5849f393]);

    public static readonly Pine.Core.PineValue List_7cc163fb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_2550597d]);

    public static readonly Pine.Core.PineValue List_12e74e47 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_eb732f5b]);

    public static readonly Pine.Core.PineValue List_782090b3 =
        Pine.Core.PineValue.List(
            [List_ef31635d, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_782090b3 =
        Pine.Core.PineValue.List(
            [List_782090b3]);

    public static readonly Pine.Core.PineValue List_8b5799ef =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5849f393]);

    public static readonly Pine.Core.PineValue List_71555a1c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_782090b3]);

    public static readonly Pine.Core.PineValue List_cd07b797 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_8b5799ef]);

    public static readonly Pine.Core.PineValue List_61b75f53 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_12e74e47]);

    public static readonly Pine.Core.PineValue List_Single_List_61b75f53 =
        Pine.Core.PineValue.List(
            [List_61b75f53]);

    public static readonly Pine.Core.PineValue List_a1e07f38 =
        Pine.Core.PineValue.List(
            [List_376a060a, List_bb14d771, List_a79c14f7]);

    public static readonly Pine.Core.PineValue List_36238402 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_61b75f53]);

    public static readonly Pine.Core.PineValue List_fefcaab4 =
        Pine.Core.PineValue.List(
            [List_2289fa98, List_bb14d771, List_113848b7]);

    public static readonly Pine.Core.PineValue List_fd2e333e =
        Pine.Core.PineValue.List(
            [List_e9c9882a, List_bb14d771, List_113848b7]);

    public static readonly Pine.Core.PineValue List_fb950424 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_cd07b797]);

    public static readonly Pine.Core.PineValue List_ca0978d3 =
        Pine.Core.PineValue.List(
            [List_ffb3657e, List_1da3871f, List_6cab91e9, List_d1125cdd]);

    public static readonly Pine.Core.PineValue List_Single_List_ca0978d3 =
        Pine.Core.PineValue.List(
            [List_ca0978d3]);

    public static readonly Pine.Core.PineValue List_07c19bf0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a1e07f38]);

    public static readonly Pine.Core.PineValue List_5b55f971 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_fefcaab4]);

    public static readonly Pine.Core.PineValue List_ba1e6ff2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_fd2e333e]);

    public static readonly Pine.Core.PineValue List_4303578c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ca0978d3]);

    public static readonly Pine.Core.PineValue List_64d3c592 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_7cc163fb]);

    public static readonly Pine.Core.PineValue List_Single_List_64d3c592 =
        Pine.Core.PineValue.List(
            [List_64d3c592]);

    public static readonly Pine.Core.PineValue List_1809445e =
        Pine.Core.PineValue.List(
            [List_8068f6f4, List_0e024eb4, List_048a1be1]);

    public static readonly Pine.Core.PineValue List_104c3618 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_64d3c592]);

    public static readonly Pine.Core.PineValue List_ec89df6a =
        Pine.Core.PineValue.List(
            [List_edc1715c, List_8799f419]);

    public static readonly Pine.Core.PineValue List_Single_List_ec89df6a =
        Pine.Core.PineValue.List(
            [List_ec89df6a]);

    public static readonly Pine.Core.PineValue List_ae902293 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_fe634606, List_8e784b64, List_918ce5b6, List_7e084b53]);

    public static readonly Pine.Core.PineValue List_Single_List_ae902293 =
        Pine.Core.PineValue.List(
            [List_ae902293]);

    public static readonly Pine.Core.PineValue List_a1c1583d =
        Pine.Core.PineValue.List(
            [List_0e5d5f28, List_4338879c]);

    public static readonly Pine.Core.PineValue List_Single_List_a1c1583d =
        Pine.Core.PineValue.List(
            [List_a1c1583d]);

    public static readonly Pine.Core.PineValue List_e291f638 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ec89df6a]);

    public static readonly Pine.Core.PineValue List_0a143e09 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ae902293]);

    public static readonly Pine.Core.PineValue List_ee3b7c22 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_1809445e]);

    public static readonly Pine.Core.PineValue List_5d80bbdc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a1c1583d]);

    public static readonly Pine.Core.PineValue List_aee2c9cc =
        Pine.Core.PineValue.List(
            [Blob_Str_take, List_e291f638]);

    public static readonly Pine.Core.PineValue List_a87f525f =
        Pine.Core.PineValue.List(
            [List_2f1c6993, List_4303578c]);

    public static readonly Pine.Core.PineValue List_Single_List_a87f525f =
        Pine.Core.PineValue.List(
            [List_a87f525f]);

    public static readonly Pine.Core.PineValue List_c442fbc6 =
        Pine.Core.PineValue.List(
            [List_f6da112b, List_9cc43055, List_575bb1c3]);

    public static readonly Pine.Core.PineValue List_Single_List_c442fbc6 =
        Pine.Core.PineValue.List(
            [List_c442fbc6]);

    public static readonly Pine.Core.PineValue List_1badf006 =
        Pine.Core.PineValue.List(
            [Blob_Str_equal, List_5d80bbdc]);

    public static readonly Pine.Core.PineValue List_d5786383 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_a87f525f]);

    public static readonly Pine.Core.PineValue List_f01bc7c5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c442fbc6]);

    public static readonly Pine.Core.PineValue List_b5608503 =
        Pine.Core.PineValue.List(
            [List_fee632d1, List_bb14d771, List_358f0447]);

    public static readonly Pine.Core.PineValue List_b9491fb0 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_f01bc7c5]);

    public static readonly Pine.Core.PineValue List_aab9c770 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_aee2c9cc]);

    public static readonly Pine.Core.PineValue List_7c241612 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_b5608503]);

    public static readonly Pine.Core.PineValue List_f401a0e4 =
        Pine.Core.PineValue.List(
            [List_d635b8fa, List_bb14d771, List_b4d515a0]);

    public static readonly Pine.Core.PineValue List_65d1e7d9 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_0a143e09]);

    public static readonly Pine.Core.PineValue List_Single_List_65d1e7d9 =
        Pine.Core.PineValue.List(
            [List_65d1e7d9]);

    public static readonly Pine.Core.PineValue List_3bcf95d7 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_1badf006]);

    public static readonly Pine.Core.PineValue List_91411c8e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_65d1e7d9]);

    public static readonly Pine.Core.PineValue List_2c38f0a8 =
        Pine.Core.PineValue.List(
            [List_b4d515a0, List_bb14d771, List_def87e98]);

    public static readonly Pine.Core.PineValue List_700e1276 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_b9491fb0]);

    public static readonly Pine.Core.PineValue List_066f830b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f401a0e4]);

    public static readonly Pine.Core.PineValue List_e85e668d =
        Pine.Core.PineValue.List(
            [List_def87e98, List_b43468c9, List_f6da112b]);

    public static readonly Pine.Core.PineValue List_5908440e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2c38f0a8]);

    public static readonly Pine.Core.PineValue List_f164dec2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_e85e668d]);

    public static readonly Pine.Core.PineValue List_c4c088a4 =
        Pine.Core.PineValue.List(
            [List_0ff05915, List_559a7021, List_d08202cd]);

    public static readonly Pine.Core.PineValue List_46753c9d =
        Pine.Core.PineValue.List(
            [List_feef8adf, List_35cf017c, List_5506574a]);

    public static readonly Pine.Core.PineValue List_f16f7982 =
        Pine.Core.PineValue.List(
            [List_03bd1ef9, List_b43468c9, List_10cf9594]);

    public static readonly Pine.Core.PineValue List_691eeb8e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c4c088a4]);

    public static readonly Pine.Core.PineValue List_Single_List_691eeb8e =
        Pine.Core.PineValue.List(
            [List_691eeb8e]);

    public static readonly Pine.Core.PineValue List_eaa5a196 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_46753c9d]);

    public static readonly Pine.Core.PineValue List_f8a62934 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_691eeb8e]);

    public static readonly Pine.Core.PineValue List_96a1d8b7 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f16f7982]);

    public static readonly Pine.Core.PineValue List_454f0db5 =
        Pine.Core.PineValue.List(
            [List_f87b80d6, List_98dd2405, List_86fad7dd]);

    public static readonly Pine.Core.PineValue List_9b93a85f =
        Pine.Core.PineValue.List(
            [List_9f5c9fad, List_bb14d771, List_dd072c3a]);

    public static readonly Pine.Core.PineValue List_10a414a9 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_d08202cd, List_b43468c9, List_4af1f0ec, List_88a3d478]);

    public static readonly Pine.Core.PineValue List_Single_List_10a414a9 =
        Pine.Core.PineValue.List(
            [List_10a414a9]);

    public static readonly Pine.Core.PineValue List_498cc43b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_10a414a9]);

    public static readonly Pine.Core.PineValue List_5bc0e984 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_454f0db5]);

    public static readonly Pine.Core.PineValue List_6303b687 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_9b93a85f]);

    public static readonly Pine.Core.PineValue List_d320120f =
        Pine.Core.PineValue.List(
            [List_498cc43b, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_d320120f =
        Pine.Core.PineValue.List(
            [List_d320120f]);

    public static readonly Pine.Core.PineValue List_9ff5058b =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_d08202cd, List_35cf017c, List_b43468c9, List_4af1f0ec, List_260d6b0f]);

    public static readonly Pine.Core.PineValue List_Single_List_9ff5058b =
        Pine.Core.PineValue.List(
            [List_9ff5058b]);

    public static readonly Pine.Core.PineValue List_8a3c48f7 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d320120f]);

    public static readonly Pine.Core.PineValue List_93b8e223 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_b43468c9, List_4af1f0ec, List_768cc61e, List_be68a4da, List_24d7b608]);

    public static readonly Pine.Core.PineValue List_Single_List_93b8e223 =
        Pine.Core.PineValue.List(
            [List_93b8e223]);

    public static readonly Pine.Core.PineValue List_c9899a7c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9ff5058b]);

    public static readonly Pine.Core.PineValue List_6c4d05e3 =
        Pine.Core.PineValue.List(
            [List_fec26d68, List_50efe0f8, List_2d613de1]);

    public static readonly Pine.Core.PineValue List_ff418cfa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_93b8e223]);

    public static readonly Pine.Core.PineValue List_03b2e64c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_d08202cd, List_35cf017c, List_86d38b8d, List_34849c45, List_d181119a, List_96cfcb00, List_d1b1c293, List_f8d1f5d9, List_6dbb5f29, List_a165bdad]);

    public static readonly Pine.Core.PineValue List_Single_List_03b2e64c =
        Pine.Core.PineValue.List(
            [List_03b2e64c]);

    public static readonly Pine.Core.PineValue List_b6951b65 =
        Pine.Core.PineValue.List(
            [List_c9899a7c, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_b6951b65 =
        Pine.Core.PineValue.List(
            [List_b6951b65]);

    public static readonly Pine.Core.PineValue List_c28c1af9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_03b2e64c]);

    public static readonly Pine.Core.PineValue List_e1c6b37d =
        Pine.Core.PineValue.List(
            [List_ff418cfa, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_e1c6b37d =
        Pine.Core.PineValue.List(
            [List_e1c6b37d]);

    public static readonly Pine.Core.PineValue List_8eee7759 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b6951b65]);

    public static readonly Pine.Core.PineValue List_ee339208 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6c4d05e3]);

    public static readonly Pine.Core.PineValue List_97972e50 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e1c6b37d]);

    public static readonly Pine.Core.PineValue List_ec31fc41 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_10015539, List_eae9cc4c, List_973a2c91, List_7ae431de]);

    public static readonly Pine.Core.PineValue List_14739b20 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_9ecbdaf8, List_f9cba928, List_2c50f745, List_d8c73140]);

    public static readonly Pine.Core.PineValue List_Single_List_ec31fc41 =
        Pine.Core.PineValue.List(
            [List_ec31fc41]);

    public static readonly Pine.Core.PineValue List_Single_List_14739b20 =
        Pine.Core.PineValue.List(
            [List_14739b20]);

    public static readonly Pine.Core.PineValue List_d6a49e40 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ec31fc41]);

    public static readonly Pine.Core.PineValue List_17fcb574 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_14739b20]);

    public static readonly Pine.Core.PineValue List_7560b1f6 =
        Pine.Core.PineValue.List(
            [List_c9797743, List_7c241612, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_fffc1eea =
        Pine.Core.PineValue.List(
            [List_046b8932, List_120ac410, List_b43468c9]);

    public static readonly Pine.Core.PineValue List_37a656bb =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_d6a49e40]);

    public static readonly Pine.Core.PineValue List_afa3315e =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_17fcb574]);

    public static readonly Pine.Core.PineValue List_Single_List_37a656bb =
        Pine.Core.PineValue.List(
            [List_37a656bb]);

    public static readonly Pine.Core.PineValue List_Single_List_afa3315e =
        Pine.Core.PineValue.List(
            [List_afa3315e]);

    public static readonly Pine.Core.PineValue List_dd880f82 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7560b1f6]);

    public static readonly Pine.Core.PineValue List_bc79942a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_37a656bb]);

    public static readonly Pine.Core.PineValue List_ecc07ead =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_afa3315e]);

    public static readonly Pine.Core.PineValue List_610ee3fc =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_fffc1eea]);

    public static readonly Pine.Core.PineValue List_Single_List_610ee3fc =
        Pine.Core.PineValue.List(
            [List_610ee3fc]);

    public static readonly Pine.Core.PineValue List_55091f63 =
        Pine.Core.PineValue.List(
            [List_ce5b6f29, List_c27949d0, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_Single_List_55091f63 =
        Pine.Core.PineValue.List(
            [List_55091f63]);

    public static readonly Pine.Core.PineValue List_be583f1d =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_610ee3fc]);

    public static readonly Pine.Core.PineValue List_95935e34 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_55091f63]);

    public static readonly Pine.Core.PineValue List_7a2eb8a7 =
        Pine.Core.PineValue.List(
            [List_86533e31, List_96a1d8b7, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_5e63fe41 =
        Pine.Core.PineValue.List(
            [List_1e3edf76, List_fd7e3c44, List_4af1f0ec, List_fa47e3e4, List_f8ddc64b]);

    public static readonly Pine.Core.PineValue List_Single_List_5e63fe41 =
        Pine.Core.PineValue.List(
            [List_5e63fe41]);

    public static readonly Pine.Core.PineValue List_635bc1cc =
        Pine.Core.PineValue.List(
            [List_f6da112b, List_4a590cf0, List_575bb1c3]);

    public static readonly Pine.Core.PineValue List_Single_List_635bc1cc =
        Pine.Core.PineValue.List(
            [List_635bc1cc]);

    public static readonly Pine.Core.PineValue List_627f403e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7a2eb8a7]);

    public static readonly Pine.Core.PineValue List_f5707274 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5e63fe41]);

    public static readonly Pine.Core.PineValue List_be60d834 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_635bc1cc]);

    public static readonly Pine.Core.PineValue List_4e4cd185 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_95935e34]);

    public static readonly Pine.Core.PineValue List_Single_List_4e4cd185 =
        Pine.Core.PineValue.List(
            [List_4e4cd185]);

    public static readonly Pine.Core.PineValue List_9c168ab0 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_be60d834]);

    public static readonly Pine.Core.PineValue List_3f9515cb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4e4cd185]);

    public static readonly Pine.Core.PineValue List_99c3b9ee =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_768cc61e, List_dd8a4914]);

    public static readonly Pine.Core.PineValue List_Single_List_99c3b9ee =
        Pine.Core.PineValue.List(
            [List_99c3b9ee]);

    public static readonly Pine.Core.PineValue List_858660c4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_99c3b9ee]);

    public static readonly Pine.Core.PineValue List_f4dd1734 =
        Pine.Core.PineValue.List(
            [List_fc9faf1d, List_5bc0e984, List_9728f698]);

    public static readonly Pine.Core.PineValue List_7df96ce1 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_9c168ab0]);

    public static readonly Pine.Core.PineValue List_96ea9956 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_f5707274]);

    public static readonly Pine.Core.PineValue List_Single_List_96ea9956 =
        Pine.Core.PineValue.List(
            [List_96ea9956]);

    public static readonly Pine.Core.PineValue List_bf404c82 =
        Pine.Core.PineValue.List(
            [List_3bcf95d7, List_aa0efd15, List_35cf017c]);

    public static readonly Pine.Core.PineValue List_403e01e8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_96ea9956]);

    public static readonly Pine.Core.PineValue List_32fd4f52 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f4dd1734]);

    public static readonly Pine.Core.PineValue List_80a51f6b =
        Pine.Core.PineValue.List(
            [List_b0fff300, List_5d6e779e]);

    public static readonly Pine.Core.PineValue List_75f896e5 =
        Pine.Core.PineValue.List(
            [List_23afeea9, List_04f36792, List_b655de02]);

    public static readonly Pine.Core.PineValue List_71c0f142 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_bf404c82]);

    public static readonly Pine.Core.PineValue List_Single_List_71c0f142 =
        Pine.Core.PineValue.List(
            [List_71c0f142]);

    public static readonly Pine.Core.PineValue List_941ccbab =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_43468879, List_42d3646e]);

    public static readonly Pine.Core.PineValue List_Single_List_941ccbab =
        Pine.Core.PineValue.List(
            [List_941ccbab]);

    public static readonly Pine.Core.PineValue List_1eb46eb9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_941ccbab]);

    public static readonly Pine.Core.PineValue List_97381154 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_80a51f6b]);

    public static readonly Pine.Core.PineValue List_602d25fc =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_71c0f142]);

    public static readonly Pine.Core.PineValue List_0f6e756a =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_75f896e5]);

    public static readonly Pine.Core.PineValue List_51f9ae9e =
        Pine.Core.PineValue.List(
            [List_1eb46eb9, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_51f9ae9e =
        Pine.Core.PineValue.List(
            [List_51f9ae9e]);

    public static readonly Pine.Core.PineValue List_eb3cfbd5 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_858660c4]);

    public static readonly Pine.Core.PineValue List_Single_List_eb3cfbd5 =
        Pine.Core.PineValue.List(
            [List_eb3cfbd5]);

    public static readonly Pine.Core.PineValue List_e689c4de =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_51f9ae9e]);

    public static readonly Pine.Core.PineValue List_9d4bb5f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_eb3cfbd5]);

    public static readonly Pine.Core.PineValue List_dc598f43 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_3f9515cb]);

    public static readonly Pine.Core.PineValue List_cee78c8e =
        Pine.Core.PineValue.List(
            [List_0ff05915, List_ee339208, List_2f59fd7a]);

    public static readonly Pine.Core.PineValue List_2a07a877 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_dc598f43]);

    public static readonly Pine.Core.PineValue List_4bad182b =
        Pine.Core.PineValue.List(
            [List_8799f419, List_fe634606, List_8e784b64, List_95297c22, List_7e084b53]);

    public static readonly Pine.Core.PineValue List_Single_List_4bad182b =
        Pine.Core.PineValue.List(
            [List_4bad182b]);

    public static readonly Pine.Core.PineValue List_449e7b59 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4bad182b]);

    public static readonly Pine.Core.PineValue List_1b6ca27f =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_cee78c8e]);

    public static readonly Pine.Core.PineValue List_b2870b6a =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_449e7b59]);

    public static readonly Pine.Core.PineValue List_Single_List_b2870b6a =
        Pine.Core.PineValue.List(
            [List_b2870b6a]);

    public static readonly Pine.Core.PineValue List_62800cfc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b2870b6a]);

    public static readonly Pine.Core.PineValue List_2488654c =
        Pine.Core.PineValue.List(
            [List_ba1e6ff2, List_4af1f0ec, List_bb55e443]);

    public static readonly Pine.Core.PineValue List_0d9c8d8e =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_449e7b59]);

    public static readonly Pine.Core.PineValue List_Single_List_0d9c8d8e =
        Pine.Core.PineValue.List(
            [List_0d9c8d8e]);

    public static readonly Pine.Core.PineValue List_dfe4e7be =
        Pine.Core.PineValue.List(
            [List_ad67682c, List_bb14d771, List_d1a85706]);

    public static readonly Pine.Core.PineValue List_4b2d910f =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0d9c8d8e]);

    public static readonly Pine.Core.PineValue List_4e893899 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2488654c]);

    public static readonly Pine.Core.PineValue List_720a16f2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_dfe4e7be]);

    public static readonly Pine.Core.PineValue List_b0187ddb =
        Pine.Core.PineValue.List(
            [List_c28c1af9, List_d9dcda92]);

    public static readonly Pine.Core.PineValue List_Single_List_b0187ddb =
        Pine.Core.PineValue.List(
            [List_b0187ddb]);

    public static readonly Pine.Core.PineValue List_cdffe3e0 =
        Pine.Core.PineValue.List(
            [List_9eca7ab0, List_73ef2378, List_700e1276]);

    public static readonly Pine.Core.PineValue List_05fcbe9d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_b0187ddb]);

    public static readonly Pine.Core.PineValue List_cb43990e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_cdffe3e0]);

    public static readonly Pine.Core.PineValue List_96c7df9e =
        Pine.Core.PineValue.List(
            [List_2aee1e7b, List_bb14d771, List_07c19bf0]);

    public static readonly Pine.Core.PineValue List_a4893e71 =
        Pine.Core.PineValue.List(
            [List_882114d8, List_bb14d771, List_5b55f971]);

    public static readonly Pine.Core.PineValue List_467ef177 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_96c7df9e]);

    public static readonly Pine.Core.PineValue List_34f1a678 =
        Pine.Core.PineValue.List(
            [List_964ab9eb, List_32fd4f52, List_a9196577]);

    public static readonly Pine.Core.PineValue List_ddaa48df =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a4893e71]);

    public static readonly Pine.Core.PineValue List_b41cfe22 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_34f1a678]);

    public static readonly Pine.Core.PineValue List_c9990405 =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_62800cfc]);

    public static readonly Pine.Core.PineValue List_c0beea6b =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c9990405]);

    public static readonly Pine.Core.PineValue List_f677fbee =
        Pine.Core.PineValue.List(
            [List_80650b69, List_f91a5831]);

    public static readonly Pine.Core.PineValue List_30b24223 =
        Pine.Core.PineValue.List(
            [List_462b85bd, List_610ee3fc]);

    public static readonly Pine.Core.PineValue List_1947d230 =
        Pine.Core.PineValue.List(
            [List_60088c4e, List_aab9c770]);

    public static readonly Pine.Core.PineValue List_Single_List_30b24223 =
        Pine.Core.PineValue.List(
            [List_30b24223]);

    public static readonly Pine.Core.PineValue List_Single_List_1947d230 =
        Pine.Core.PineValue.List(
            [List_1947d230]);

    public static readonly Pine.Core.PineValue List_aca6cda0 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_f677fbee]);

    public static readonly Pine.Core.PineValue List_40268022 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1947d230]);

    public static readonly Pine.Core.PineValue List_f8c7cae2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_30b24223]);

    public static readonly Pine.Core.PineValue List_8890cc29 =
        Pine.Core.PineValue.List(
            [List_23e8d21e, List_837976dd, List_b43468c9, List_4af1f0ec, List_768cc61e, List_1e3edf76, List_b437d778]);

    public static readonly Pine.Core.PineValue List_Single_List_8890cc29 =
        Pine.Core.PineValue.List(
            [List_8890cc29]);

    public static readonly Pine.Core.PineValue List_aa22f113 =
        Pine.Core.PineValue.List(
            [Blob_Str_skip, List_40268022]);

    public static readonly Pine.Core.PineValue List_9757e17e =
        Pine.Core.PineValue.List(
            [List_8e2f37cd, List_3d07ca80, List_b6f66fe2]);

    public static readonly Pine.Core.PineValue List_cc9b6ce4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8890cc29]);

    public static readonly Pine.Core.PineValue List_1dcf46fb =
        Pine.Core.PineValue.List(
            [List_6dbb5f29, List_05fcbe9d]);

    public static readonly Pine.Core.PineValue List_ee7cd2ac =
        Pine.Core.PineValue.List(
            [List_cc9b6ce4, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_ee7cd2ac =
        Pine.Core.PineValue.List(
            [List_ee7cd2ac]);

    public static readonly Pine.Core.PineValue List_adcdb117 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_af6ab14c, List_4e5ae7e4, List_accc4c20, List_7d570eb6]);

    public static readonly Pine.Core.PineValue List_02f661f2 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_4404e85b, List_9b7cc2a7, List_6c9605d4, List_b0257228]);

    public static readonly Pine.Core.PineValue List_Single_List_adcdb117 =
        Pine.Core.PineValue.List(
            [List_adcdb117]);

    public static readonly Pine.Core.PineValue List_Single_List_02f661f2 =
        Pine.Core.PineValue.List(
            [List_02f661f2]);

    public static readonly Pine.Core.PineValue List_1b934957 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_9757e17e]);

    public static readonly Pine.Core.PineValue List_e4261fbb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ee7cd2ac]);

    public static readonly Pine.Core.PineValue List_8c72f096 =
        Pine.Core.PineValue.List(
            [List_80650b69, List_71555a1c]);

    public static readonly Pine.Core.PineValue List_189372d4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_adcdb117]);

    public static readonly Pine.Core.PineValue List_8cd31c20 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_02f661f2]);

    public static readonly Pine.Core.PineValue List_f669c609 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_aa22f113]);

    public static readonly Pine.Core.PineValue List_Single_List_f669c609 =
        Pine.Core.PineValue.List(
            [List_f669c609]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_f669c609 =
        Pine.Core.PineValue.List(
            [List_Single_List_f669c609]);

    public static readonly Pine.Core.PineValue List_0c56c6fa =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_1dcf46fb]);

    public static readonly Pine.Core.PineValue List_Single_List_0c56c6fa =
        Pine.Core.PineValue.List(
            [List_0c56c6fa]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_0c56c6fa =
        Pine.Core.PineValue.List(
            [List_Single_List_0c56c6fa]);

    public static readonly Pine.Core.PineValue List_72c81c1e =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_f669c609]);

    public static readonly Pine.Core.PineValue List_97ba8af5 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_0c56c6fa]);

    public static readonly Pine.Core.PineValue List_b6043604 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_8c72f096]);

    public static readonly Pine.Core.PineValue List_cd95cf68 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_72c81c1e]);

    public static readonly Pine.Core.PineValue List_Single_List_cd95cf68 =
        Pine.Core.PineValue.List(
            [List_cd95cf68]);

    public static readonly Pine.Core.PineValue List_88e1499a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_cd95cf68]);

    public static readonly Pine.Core.PineValue List_bba09f68 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_189372d4]);

    public static readonly Pine.Core.PineValue List_3dc91e15 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_8cd31c20]);

    public static readonly Pine.Core.PineValue List_Single_List_bba09f68 =
        Pine.Core.PineValue.List(
            [List_bba09f68]);

    public static readonly Pine.Core.PineValue List_Single_List_3dc91e15 =
        Pine.Core.PineValue.List(
            [List_3dc91e15]);

    public static readonly Pine.Core.PineValue List_4af2c4d8 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bba09f68]);

    public static readonly Pine.Core.PineValue List_799abeba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3dc91e15]);

    public static readonly Pine.Core.PineValue List_7e556ae1 =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_97ba8af5]);

    public static readonly Pine.Core.PineValue List_Single_List_7e556ae1 =
        Pine.Core.PineValue.List(
            [List_7e556ae1]);

    public static readonly Pine.Core.PineValue List_6c6e11ca =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7e556ae1]);

    public static readonly Pine.Core.PineValue List_ba315a2c =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_d08202cd, List_97b8d591, List_b43468c9, List_4af1f0ec, List_12546944]);

    public static readonly Pine.Core.PineValue List_Single_List_ba315a2c =
        Pine.Core.PineValue.List(
            [List_ba315a2c]);

    public static readonly Pine.Core.PineValue List_560b1b9e =
        Pine.Core.PineValue.List(
            [List_7b6856d8, List_09bcc09f, List_fb950424]);

    public static readonly Pine.Core.PineValue List_321ea735 =
        Pine.Core.PineValue.List(
            [List_d635b8fa, List_bb14d771, List_5908440e]);

    public static readonly Pine.Core.PineValue List_6feeb117 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_ba315a2c]);

    public static readonly Pine.Core.PineValue List_d8be6c3c =
        Pine.Core.PineValue.List(
            [List_6feeb117, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_d8be6c3c =
        Pine.Core.PineValue.List(
            [List_d8be6c3c]);

    public static readonly Pine.Core.PineValue List_6d566ce5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_560b1b9e]);

    public static readonly Pine.Core.PineValue List_cbfffee0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_321ea735]);

    public static readonly Pine.Core.PineValue List_e3cd3dca =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d8be6c3c]);

    public static readonly Pine.Core.PineValue List_f39541b1 =
        Pine.Core.PineValue.List(
            [List_d221b4a8, List_b41cfe22, List_e844984b]);

    public static readonly Pine.Core.PineValue List_07f23448 =
        Pine.Core.PineValue.List(
            [List_7d363e54, List_b43468c9, List_91411c8e]);

    public static readonly Pine.Core.PineValue List_0b236a5d =
        Pine.Core.PineValue.List(
            [List_f87f6843, List_cb43990e, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_17393fd2 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f39541b1]);

    public static readonly Pine.Core.PineValue List_f01ae69f =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_4af1f0ec, List_908ec70a, List_910e92c3, List_52e7b97a, List_859a991a, List_982167ce]);

    public static readonly Pine.Core.PineValue List_Single_List_f01ae69f =
        Pine.Core.PineValue.List(
            [List_f01ae69f]);

    public static readonly Pine.Core.PineValue List_f0680d6b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f01ae69f]);

    public static readonly Pine.Core.PineValue List_b82a14c8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_07f23448]);

    public static readonly Pine.Core.PineValue List_Single_List_b82a14c8 =
        Pine.Core.PineValue.List(
            [List_b82a14c8]);

    public static readonly Pine.Core.PineValue List_abb59323 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0b236a5d]);

    public static readonly Pine.Core.PineValue List_73c70c47 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_b82a14c8]);

    public static readonly Pine.Core.PineValue List_9db3aa57 =
        Pine.Core.PineValue.List(
            [List_9eca7ab0, List_73ef2378, List_7df96ce1]);

    public static readonly Pine.Core.PineValue List_2685a4f8 =
        Pine.Core.PineValue.List(
            [List_908ec70a, List_910e92c3, List_52e7b97a, List_859a991a, List_bb8042f7]);

    public static readonly Pine.Core.PineValue List_f808be7b =
        Pine.Core.PineValue.List(
            [List_908ec70a, List_910e92c3, List_52e7b97a, List_3b4c17af, List_982167ce]);

    public static readonly Pine.Core.PineValue List_Single_List_2685a4f8 =
        Pine.Core.PineValue.List(
            [List_2685a4f8]);

    public static readonly Pine.Core.PineValue List_Single_List_f808be7b =
        Pine.Core.PineValue.List(
            [List_f808be7b]);

    public static readonly Pine.Core.PineValue List_e2b325cb =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_4404e85b, List_9b7cc2a7, List_02b9e69e, List_b0257228]);

    public static readonly Pine.Core.PineValue List_Single_List_e2b325cb =
        Pine.Core.PineValue.List(
            [List_e2b325cb]);

    public static readonly Pine.Core.PineValue List_f3328233 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_b43468c9, List_4af1f0ec, List_2a07a877]);

    public static readonly Pine.Core.PineValue List_Single_List_f3328233 =
        Pine.Core.PineValue.List(
            [List_f3328233]);

    public static readonly Pine.Core.PineValue List_ff5f5fd2 =
        Pine.Core.PineValue.List(
            [List_8ebf4631, List_452ea1d4, List_c7ba562f]);

    public static readonly Pine.Core.PineValue List_016e66aa =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_2685a4f8]);

    public static readonly Pine.Core.PineValue List_fd50f53c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f808be7b]);

    public static readonly Pine.Core.PineValue List_b34cc98c =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_e2b325cb]);

    public static readonly Pine.Core.PineValue List_bdc906ba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f3328233]);

    public static readonly Pine.Core.PineValue List_6278dc85 =
        Pine.Core.PineValue.List(
            [List_74840517, List_8a3c48f7]);

    public static readonly Pine.Core.PineValue List_47f9514b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_9db3aa57]);

    public static readonly Pine.Core.PineValue List_180acaaa =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_016e66aa]);

    public static readonly Pine.Core.PineValue List_08220a3e =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_fd50f53c]);

    public static readonly Pine.Core.PineValue List_Single_List_180acaaa =
        Pine.Core.PineValue.List(
            [List_180acaaa]);

    public static readonly Pine.Core.PineValue List_Single_List_08220a3e =
        Pine.Core.PineValue.List(
            [List_08220a3e]);

    public static readonly Pine.Core.PineValue List_5e888933 =
        Pine.Core.PineValue.List(
            [List_bdc906ba, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_5e888933 =
        Pine.Core.PineValue.List(
            [List_5e888933]);

    public static readonly Pine.Core.PineValue List_8fcb4e97 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_ff5f5fd2]);

    public static readonly Pine.Core.PineValue List_07bfb1d9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_180acaaa]);

    public static readonly Pine.Core.PineValue List_9c466847 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_08220a3e]);

    public static readonly Pine.Core.PineValue List_b89681ec =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5e888933]);

    public static readonly Pine.Core.PineValue List_5d5a0297 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_6278dc85]);

    public static readonly Pine.Core.PineValue List_5a371185 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_532bbcd3, List_d18da9cc, List_9c12cdf2, List_3c2b6c59]);

    public static readonly Pine.Core.PineValue List_Single_List_5a371185 =
        Pine.Core.PineValue.List(
            [List_5a371185]);

    public static readonly Pine.Core.PineValue List_db9b2e44 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_fd50f53c]);

    public static readonly Pine.Core.PineValue List_Single_List_db9b2e44 =
        Pine.Core.PineValue.List(
            [List_db9b2e44]);

    public static readonly Pine.Core.PineValue List_4a678cd7 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_b34cc98c]);

    public static readonly Pine.Core.PineValue List_Single_List_4a678cd7 =
        Pine.Core.PineValue.List(
            [List_4a678cd7]);

    public static readonly Pine.Core.PineValue List_7dea4538 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5a371185]);

    public static readonly Pine.Core.PineValue List_e31d68fc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_db9b2e44]);

    public static readonly Pine.Core.PineValue List_50eafeb9 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_4a678cd7]);

    public static readonly Pine.Core.PineValue List_10ff89ce =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_7dea4538]);

    public static readonly Pine.Core.PineValue List_Single_List_10ff89ce =
        Pine.Core.PineValue.List(
            [List_10ff89ce]);

    public static readonly Pine.Core.PineValue List_7d3cd824 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_10ff89ce]);

    public static readonly Pine.Core.PineValue List_3be88569 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_9ecbdaf8, List_f9cba928, List_a88e2911, List_d8c73140]);

    public static readonly Pine.Core.PineValue List_Single_List_3be88569 =
        Pine.Core.PineValue.List(
            [List_3be88569]);

    public static readonly Pine.Core.PineValue List_1bc5ba15 =
        Pine.Core.PineValue.List(
            [List_85d9e8e7, List_1b6ca27f, List_05bb98be]);

    public static readonly Pine.Core.PineValue List_c1782438 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_3be88569]);

    public static readonly Pine.Core.PineValue List_6c506447 =
        Pine.Core.PineValue.List(
            [List_976730e9, List_6dbb5f29, List_d08202cd, List_86d38b8d, List_5a003ee9, List_14e626b6, List_9de4765d, List_bb1301d2]);

    public static readonly Pine.Core.PineValue List_Single_List_6c506447 =
        Pine.Core.PineValue.List(
            [List_6c506447]);

    public static readonly Pine.Core.PineValue List_f5d24f62 =
        Pine.Core.PineValue.List(
            [List_3b72ff38, List_f0680d6b]);

    public static readonly Pine.Core.PineValue List_Single_List_f5d24f62 =
        Pine.Core.PineValue.List(
            [List_f5d24f62]);

    public static readonly Pine.Core.PineValue List_66367f5d =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_6c506447]);

    public static readonly Pine.Core.PineValue List_2444c9ba =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f5d24f62]);

    public static readonly Pine.Core.PineValue List_24328a39 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_1bc5ba15]);

    public static readonly Pine.Core.PineValue List_Single_List_24328a39 =
        Pine.Core.PineValue.List(
            [List_24328a39]);

    public static readonly Pine.Core.PineValue List_1b3e9bb9 =
        Pine.Core.PineValue.List(
            [List_66367f5d, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_Single_List_1b3e9bb9 =
        Pine.Core.PineValue.List(
            [List_1b3e9bb9]);

    public static readonly Pine.Core.PineValue List_e1ee4b18 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_24328a39]);

    public static readonly Pine.Core.PineValue List_262000c6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_1b3e9bb9]);

    public static readonly Pine.Core.PineValue List_9ad3d0e2 =
        Pine.Core.PineValue.List(
            [List_8799f419, List_910e92c3, List_52e7b97a, List_918ce5b6, List_853cd68a]);

    public static readonly Pine.Core.PineValue List_Single_List_9ad3d0e2 =
        Pine.Core.PineValue.List(
            [List_9ad3d0e2]);

    public static readonly Pine.Core.PineValue List_09829156 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_c1782438]);

    public static readonly Pine.Core.PineValue List_Single_List_09829156 =
        Pine.Core.PineValue.List(
            [List_09829156]);

    public static readonly Pine.Core.PineValue List_e172a889 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9ad3d0e2]);

    public static readonly Pine.Core.PineValue List_e376d104 =
        Pine.Core.PineValue.List(
            [List_34849c45, List_07bfb1d9]);

    public static readonly Pine.Core.PineValue List_da162641 =
        Pine.Core.PineValue.List(
            [List_34849c45, List_9c466847]);

    public static readonly Pine.Core.PineValue List_96b870b0 =
        Pine.Core.PineValue.List(
            [List_768cc61e, List_d02158f5, List_259077d1, List_68a4a753, List_a29aeeb1]);

    public static readonly Pine.Core.PineValue List_Single_List_96b870b0 =
        Pine.Core.PineValue.List(
            [List_96b870b0]);

    public static readonly Pine.Core.PineValue List_91c7a885 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_09829156]);

    public static readonly Pine.Core.PineValue List_ec85c61b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_96b870b0]);

    public static readonly Pine.Core.PineValue List_70416b07 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_e172a889]);

    public static readonly Pine.Core.PineValue List_a5e575d2 =
        Pine.Core.PineValue.List(
            [List_17822585, List_17393fd2, List_c3b08663]);

    public static readonly Pine.Core.PineValue List_Single_List_70416b07 =
        Pine.Core.PineValue.List(
            [List_70416b07]);

    public static readonly Pine.Core.PineValue List_b3aecfcc =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_70416b07]);

    public static readonly Pine.Core.PineValue List_7b784b48 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_e376d104]);

    public static readonly Pine.Core.PineValue List_5e7c7618 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_da162641]);

    public static readonly Pine.Core.PineValue List_f0ee8514 =
        Pine.Core.PineValue.List(
            [List_f8c7cae2, List_0f44d232]);

    public static readonly Pine.Core.PineValue List_Single_List_f0ee8514 =
        Pine.Core.PineValue.List(
            [List_f0ee8514]);

    public static readonly Pine.Core.PineValue List_8b58ddf6 =
        Pine.Core.PineValue.List(
            [List_1e3edf76, List_fd7e3c44, List_23c9f203, List_fa47e3e4, List_7c0248ac]);

    public static readonly Pine.Core.PineValue List_9affa818 =
        Pine.Core.PineValue.List(
            [List_1e3edf76, List_fd7e3c44, List_23c9f203, List_fa3248df, List_f8ddc64b]);

    public static readonly Pine.Core.PineValue List_Single_List_8b58ddf6 =
        Pine.Core.PineValue.List(
            [List_8b58ddf6]);

    public static readonly Pine.Core.PineValue List_Single_List_9affa818 =
        Pine.Core.PineValue.List(
            [List_9affa818]);

    public static readonly Pine.Core.PineValue List_e5d913d3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a5e575d2]);

    public static readonly Pine.Core.PineValue List_b8990725 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f0ee8514]);

    public static readonly Pine.Core.PineValue List_c6a2cf93 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_8b58ddf6]);

    public static readonly Pine.Core.PineValue List_94cd2f85 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_9affa818]);

    public static readonly Pine.Core.PineValue List_aeb52fe1 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_c6a2cf93]);

    public static readonly Pine.Core.PineValue List_edfcf450 =
        Pine.Core.PineValue.List(
            [List_e190d1f5, List_94cd2f85]);

    public static readonly Pine.Core.PineValue List_Single_List_aeb52fe1 =
        Pine.Core.PineValue.List(
            [List_aeb52fe1]);

    public static readonly Pine.Core.PineValue List_Single_List_edfcf450 =
        Pine.Core.PineValue.List(
            [List_edfcf450]);

    public static readonly Pine.Core.PineValue List_19e151d0 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_ec85c61b]);

    public static readonly Pine.Core.PineValue List_Single_List_19e151d0 =
        Pine.Core.PineValue.List(
            [List_19e151d0]);

    public static readonly Pine.Core.PineValue List_321d45a4 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_aeb52fe1]);

    public static readonly Pine.Core.PineValue List_8679f921 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_edfcf450]);

    public static readonly Pine.Core.PineValue List_2e7a505a =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_19e151d0]);

    public static readonly Pine.Core.PineValue List_ef33203e =
        Pine.Core.PineValue.List(
            [List_f8a62934, List_db101cdb]);

    public static readonly Pine.Core.PineValue List_449d95bc =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_ef33203e]);

    public static readonly Pine.Core.PineValue List_014f1863 =
        Pine.Core.PineValue.List(
            [List_35cf017c, List_2444c9ba]);

    public static readonly Pine.Core.PineValue List_22d4cd0b =
        Pine.Core.PineValue.List(
            [List_f87f6843, List_47f9514b, List_e190d1f5]);

    public static readonly Pine.Core.PineValue List_f8acb785 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_014f1863]);

    public static readonly Pine.Core.PineValue List_ef7a3e89 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_22d4cd0b]);

    public static readonly Pine.Core.PineValue List_bbd05f80 =
        Pine.Core.PineValue.List(
            [List_80650b69, List_e689c4de]);

    public static readonly Pine.Core.PineValue List_495dcc3b =
        Pine.Core.PineValue.List(
            [List_2b21856c, List_8eee7759]);

    public static readonly Pine.Core.PineValue List_d008fe4b =
        Pine.Core.PineValue.List(
            [List_34849c45, List_b3aecfcc]);

    public static readonly Pine.Core.PineValue List_4fbca2be =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_bbd05f80]);

    public static readonly Pine.Core.PineValue List_ded2f59a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_495dcc3b]);

    public static readonly Pine.Core.PineValue List_be7c2679 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_d008fe4b]);

    public static readonly Pine.Core.PineValue List_88ac6a50 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_321d45a4]);

    public static readonly Pine.Core.PineValue List_14054c74 =
        Pine.Core.PineValue.List(
            [List_d08202cd, List_8679f921]);

    public static readonly Pine.Core.PineValue List_cfba9e3b =
        Pine.Core.PineValue.List(
            [List_59cad394, List_bb14d771, List_cbfffee0]);

    public static readonly Pine.Core.PineValue List_a07a5381 =
        Pine.Core.PineValue.List(
            [List_555ff973, List_bb14d771, List_720a16f2]);

    public static readonly Pine.Core.PineValue List_65bb8f4d =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_88ac6a50]);

    public static readonly Pine.Core.PineValue List_05fa8a74 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_14054c74]);

    public static readonly Pine.Core.PineValue List_10dfa68f =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_cfba9e3b]);

    public static readonly Pine.Core.PineValue List_80b7cb18 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a07a5381]);

    public static readonly Pine.Core.PineValue List_8e2c0220 =
        Pine.Core.PineValue.List(
            [List_86533e31, List_e5d913d3, List_4c2609c3]);

    public static readonly Pine.Core.PineValue List_39fa68f8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8e2c0220]);

    public static readonly Pine.Core.PineValue List_f4ca8883 =
        Pine.Core.PineValue.List(
            [List_b43468c9, List_f8acb785]);

    public static readonly Pine.Core.PineValue List_Single_List_f4ca8883 =
        Pine.Core.PineValue.List(
            [List_f4ca8883]);

    public static readonly Pine.Core.PineValue List_3220a777 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f4ca8883]);

    public static readonly Pine.Core.PineValue List_79ee05ae =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_3220a777]);

    public static readonly Pine.Core.PineValue List_Single_List_79ee05ae =
        Pine.Core.PineValue.List(
            [List_79ee05ae]);

    public static readonly Pine.Core.PineValue List_0b9b6fdb =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_79ee05ae]);

    public static readonly Pine.Core.PineValue List_aa68b3f1 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_a2ee8d46, List_a33211c9, List_8594e303, List_16950cca]);

    public static readonly Pine.Core.PineValue List_Single_List_aa68b3f1 =
        Pine.Core.PineValue.List(
            [List_aa68b3f1]);

    public static readonly Pine.Core.PineValue List_c6fc7dde =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_aa68b3f1]);

    public static readonly Pine.Core.PineValue List_d0f844d7 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_c6fc7dde]);

    public static readonly Pine.Core.PineValue List_Single_List_d0f844d7 =
        Pine.Core.PineValue.List(
            [List_d0f844d7]);

    public static readonly Pine.Core.PineValue List_81e8c713 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d0f844d7]);

    public static readonly Pine.Core.PineValue List_a2af9e7e =
        Pine.Core.PineValue.List(
            [List_9eca7ab0, List_a56696f0, List_c0beea6b]);

    public static readonly Pine.Core.PineValue List_420d5c62 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_a2af9e7e]);

    public static readonly Pine.Core.PineValue List_Single_List_420d5c62 =
        Pine.Core.PineValue.List(
            [List_420d5c62]);

    public static readonly Pine.Core.PineValue List_99fd54f3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_420d5c62]);

    public static readonly Pine.Core.PineValue List_3ff42d6e =
        Pine.Core.PineValue.List(
            [List_a165bdad, List_0b9b6fdb]);

    public static readonly Pine.Core.PineValue List_26f30e27 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_3ff42d6e]);

    public static readonly Pine.Core.PineValue List_d0cfcf06 =
        Pine.Core.PineValue.List(
            [List_5c94f165, List_262000c6]);

    public static readonly Pine.Core.PineValue List_2722c69a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_d0cfcf06]);

    public static readonly Pine.Core.PineValue List_a8b1c4d1 =
        Pine.Core.PineValue.List(
            [List_567b0fae, List_e3cd3dca]);

    public static readonly Pine.Core.PineValue List_37aef233 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_a8b1c4d1]);

    public static readonly Pine.Core.PineValue List_7e9840d0 =
        Pine.Core.PineValue.List(
            [List_2f4aebd4, List_1b934957, List_9a5c3716]);

    public static readonly Pine.Core.PineValue List_b33556a5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7e9840d0]);

    public static readonly Pine.Core.PineValue List_6e33b350 =
        Pine.Core.PineValue.List(
            [List_cc7e0e58, List_83f303b1, List_97381154]);

    public static readonly Pine.Core.PineValue List_5e61dbd0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6e33b350]);

    public static readonly Pine.Core.PineValue List_Single_List_5e61dbd0 =
        Pine.Core.PineValue.List(
            [List_5e61dbd0]);

    public static readonly Pine.Core.PineValue List_c9ea88ff =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_5e61dbd0]);

    public static readonly Pine.Core.PineValue List_c75c3b4b =
        Pine.Core.PineValue.List(
            [List_2fecb8a3, List_7efafede, List_ded2f59a]);

    public static readonly Pine.Core.PineValue List_d99a436b =
        Pine.Core.PineValue.List(
            [List_deeafbf1, List_85bff313, List_65bb8f4d]);

    public static readonly Pine.Core.PineValue List_31240f12 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c75c3b4b]);

    public static readonly Pine.Core.PineValue List_8885cd8d =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d99a436b]);

    public static readonly Pine.Core.PineValue List_1c6b5224 =
        Pine.Core.PineValue.List(
            [List_ef2f17f4, List_d5786383, List_220685f6]);

    public static readonly Pine.Core.PineValue List_d6680f3e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_1c6b5224]);

    public static readonly Pine.Core.PineValue List_93a716bf =
        Pine.Core.PineValue.List(
            [List_99fd54f3, List_08042d00]);

    public static readonly Pine.Core.PineValue List_f4eaaf28 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_fe634606, List_8e784b64, List_7d570eb6, List_799abeba]);

    public static readonly Pine.Core.PineValue List_Single_List_f4eaaf28 =
        Pine.Core.PineValue.List(
            [List_f4eaaf28]);

    public static readonly Pine.Core.PineValue List_57a75c31 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_93a716bf]);

    public static readonly Pine.Core.PineValue List_a75a8f92 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f4eaaf28]);

    public static readonly Pine.Core.PineValue List_c493ee33 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_a75a8f92]);

    public static readonly Pine.Core.PineValue List_Single_List_c493ee33 =
        Pine.Core.PineValue.List(
            [List_c493ee33]);

    public static readonly Pine.Core.PineValue List_095f8307 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c493ee33]);

    public static readonly Pine.Core.PineValue List_f9580f72 =
        Pine.Core.PineValue.List(
            [List_c2c0d1a9, List_8fcb4e97, List_4c8b632e]);

    public static readonly Pine.Core.PineValue List_b223f41d =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f9580f72]);

    public static readonly Pine.Core.PineValue List_bc725b1a =
        Pine.Core.PineValue.List(
            [List_c0210a02, List_6538d979, List_5e7c7618]);

    public static readonly Pine.Core.PineValue List_b360f1b8 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_bc725b1a]);

    public static readonly Pine.Core.PineValue List_Single_List_b360f1b8 =
        Pine.Core.PineValue.List(
            [List_b360f1b8]);

    public static readonly Pine.Core.PineValue List_84ffd35b =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_b360f1b8]);

    public static readonly Pine.Core.PineValue List_5ced2422 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_fe634606, List_8e784b64, List_4af2c4d8, List_a7dbe08c]);

    public static readonly Pine.Core.PineValue List_Single_List_5ced2422 =
        Pine.Core.PineValue.List(
            [List_5ced2422]);

    public static readonly Pine.Core.PineValue List_f2f8e5a0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5ced2422]);

    public static readonly Pine.Core.PineValue List_8c231b4d =
        Pine.Core.PineValue.List(
            [List_9eca7ab0, List_6d566ce5, List_0c520c88]);

    public static readonly Pine.Core.PineValue List_982a8647 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8c231b4d]);

    public static readonly Pine.Core.PineValue List_d7f9157a =
        Pine.Core.PineValue.List(
            [List_2ca5e701, List_31240f12, List_2f59fd7a]);

    public static readonly Pine.Core.PineValue List_43411bbb =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_f2f8e5a0]);

    public static readonly Pine.Core.PineValue List_Single_List_43411bbb =
        Pine.Core.PineValue.List(
            [List_43411bbb]);

    public static readonly Pine.Core.PineValue List_b647a1bf =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d7f9157a]);

    public static readonly Pine.Core.PineValue List_390faaa1 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_43411bbb]);

    public static readonly Pine.Core.PineValue List_c3e08309 =
        Pine.Core.PineValue.List(
            [List_73c70c47, List_104c3618]);

    public static readonly Pine.Core.PineValue List_985c9717 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_c3e08309]);

    public static readonly Pine.Core.PineValue List_bbea32d7 =
        Pine.Core.PineValue.List(
            [List_c0210a02, List_6538d979, List_be7c2679]);

    public static readonly Pine.Core.PineValue List_7c490763 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_bbea32d7]);

    public static readonly Pine.Core.PineValue List_Single_List_7c490763 =
        Pine.Core.PineValue.List(
            [List_7c490763]);

    public static readonly Pine.Core.PineValue List_4932de99 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_7c490763]);

    public static readonly Pine.Core.PineValue List_bbb875f2 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_4af1f0ec, List_768cc61e, List_bc79942a, List_ecc07ead]);

    public static readonly Pine.Core.PineValue List_Single_List_bbb875f2 =
        Pine.Core.PineValue.List(
            [List_bbb875f2]);

    public static readonly Pine.Core.PineValue List_69eb22ce =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_bbb875f2]);

    public static readonly Pine.Core.PineValue List_f8fcdbb4 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_69eb22ce]);

    public static readonly Pine.Core.PineValue List_Single_List_f8fcdbb4 =
        Pine.Core.PineValue.List(
            [List_f8fcdbb4]);

    public static readonly Pine.Core.PineValue List_01bd811b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_f8fcdbb4]);

    public static readonly Pine.Core.PineValue List_d0a0f9fe =
        Pine.Core.PineValue.List(
            [List_11e84499, List_ee3b7c22, List_b6043604]);

    public static readonly Pine.Core.PineValue List_fc87e4ac =
        Pine.Core.PineValue.List(
            [List_32d71b95, List_37aef233, List_3966a3c3]);

    public static readonly Pine.Core.PineValue List_d2e19685 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d0a0f9fe]);

    public static readonly Pine.Core.PineValue List_632693ae =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_fc87e4ac]);

    public static readonly Pine.Core.PineValue List_63422246 =
        Pine.Core.PineValue.List(
            [List_e53e9917, List_982a8647, List_bb14d771]);

    public static readonly Pine.Core.PineValue List_d21ba4f0 =
        Pine.Core.PineValue.List(
            [List_04fe9790, List_7e881476, List_d6680f3e]);

    public static readonly Pine.Core.PineValue List_0813d1cc =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_63422246]);

    public static readonly Pine.Core.PineValue List_a410766d =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d21ba4f0]);

    public static readonly Pine.Core.PineValue List_4ef3e958 =
        Pine.Core.PineValue.List(
            [List_e1ee4b18, List_97972e50]);

    public static readonly Pine.Core.PineValue List_747eb787 =
        Pine.Core.PineValue.List(
            [List_c9ea88ff, List_3739323d]);

    public static readonly Pine.Core.PineValue List_6aadd8cd =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_4ef3e958]);

    public static readonly Pine.Core.PineValue List_53226cad =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_747eb787]);

    public static readonly Pine.Core.PineValue List_0a786f4b =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_a410766d, List_4de8c353]);

    public static readonly Pine.Core.PineValue List_Single_List_0a786f4b =
        Pine.Core.PineValue.List(
            [List_0a786f4b]);

    public static readonly Pine.Core.PineValue List_faa15f75 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_0a786f4b]);

    public static readonly Pine.Core.PineValue List_cc74513b =
        Pine.Core.PineValue.List(
            [List_602d25fc, List_b89681ec]);

    public static readonly Pine.Core.PineValue List_612de97a =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_cc74513b]);

    public static readonly Pine.Core.PineValue List_89042992 =
        Pine.Core.PineValue.List(
            [List_6467391b, List_73ef2378, List_b647a1bf]);

    public static readonly Pine.Core.PineValue List_48de095f =
        Pine.Core.PineValue.List(
            [List_a5cbaf18, List_faa15f75]);

    public static readonly Pine.Core.PineValue List_3a8c6277 =
        Pine.Core.PineValue.List(
            [List_753c87a5, List_b33556a5, List_531d1306]);

    public static readonly Pine.Core.PineValue List_0f2c2ffb =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_89042992]);

    public static readonly Pine.Core.PineValue List_40babf67 =
        Pine.Core.PineValue.List(
            [List_be583f1d, List_b8990725]);

    public static readonly Pine.Core.PineValue List_9f263735 =
        Pine.Core.PineValue.List(
            [List_84ffd35b, List_56efbe7a]);

    public static readonly Pine.Core.PineValue List_7190788e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_48de095f]);

    public static readonly Pine.Core.PineValue List_6d371533 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_3a8c6277]);

    public static readonly Pine.Core.PineValue List_f627c3e4 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_40babf67]);

    public static readonly Pine.Core.PineValue List_409f5309 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_9f263735]);

    public static readonly Pine.Core.PineValue List_21002a8c =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_f627c3e4]);

    public static readonly Pine.Core.PineValue List_94542b1c =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_21002a8c]);

    public static readonly Pine.Core.PineValue List_620e1215 =
        Pine.Core.PineValue.List(
            [List_ddaa48df, List_4e893899, List_bb55e443]);

    public static readonly Pine.Core.PineValue List_208a1fef =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_620e1215]);

    public static readonly Pine.Core.PineValue List_5f02d865 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_10015539, List_eae9cc4c, List_7d3cd824, List_05aa1319]);

    public static readonly Pine.Core.PineValue List_Single_List_5f02d865 =
        Pine.Core.PineValue.List(
            [List_5f02d865]);

    public static readonly Pine.Core.PineValue List_6b215654 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_5f02d865]);

    public static readonly Pine.Core.PineValue List_951aa6f1 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_6b215654]);

    public static readonly Pine.Core.PineValue List_Single_List_951aa6f1 =
        Pine.Core.PineValue.List(
            [List_951aa6f1]);

    public static readonly Pine.Core.PineValue List_5ae8fd3b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_951aa6f1]);

    public static readonly Pine.Core.PineValue List_f3f5830c =
        Pine.Core.PineValue.List(
            [List_dafb5db3, List_bb14d771, List_0813d1cc]);

    public static readonly Pine.Core.PineValue List_7db74054 =
        Pine.Core.PineValue.List(
            [List_94542b1c, List_34849c45]);

    public static readonly Pine.Core.PineValue List_Single_List_7db74054 =
        Pine.Core.PineValue.List(
            [List_7db74054]);

    public static readonly Pine.Core.PineValue List_852987d0 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f3f5830c]);

    public static readonly Pine.Core.PineValue List_e4bd205b =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7db74054]);

    public static readonly Pine.Core.PineValue List_f0c11624 =
        Pine.Core.PineValue.List(
            [Blob_Str_concat, List_e4bd205b]);

    public static readonly Pine.Core.PineValue List_8f389de6 =
        Pine.Core.PineValue.List(
            [List_f01ccf80, List_612de97a, List_b5d02807]);

    public static readonly Pine.Core.PineValue List_cd60f069 =
        Pine.Core.PineValue.List(
            [Blob_Str_KernelApplication, List_f0c11624]);

    public static readonly Pine.Core.PineValue List_Single_List_cd60f069 =
        Pine.Core.PineValue.List(
            [List_cd60f069]);

    public static readonly Pine.Core.PineValue List_Single_List_Single_List_cd60f069 =
        Pine.Core.PineValue.List(
            [List_Single_List_cd60f069]);

    public static readonly Pine.Core.PineValue List_6092d1dd =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_Single_List_cd60f069]);

    public static readonly Pine.Core.PineValue List_9a1e26cb =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8f389de6]);

    public static readonly Pine.Core.PineValue List_672e9982 =
        Pine.Core.PineValue.List(
            [List_95a1a4ad, List_6092d1dd]);

    public static readonly Pine.Core.PineValue List_Single_List_672e9982 =
        Pine.Core.PineValue.List(
            [List_672e9982]);

    public static readonly Pine.Core.PineValue List_c24cf806 =
        Pine.Core.PineValue.List(
            [List_ad2fad57, List_7190788e, List_f1126ab7]);

    public static readonly Pine.Core.PineValue List_2170dead =
        Pine.Core.PineValue.List(
            [List_73c70c47, List_6c6e11ca]);

    public static readonly Pine.Core.PineValue List_5620b2e6 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_672e9982]);

    public static readonly Pine.Core.PineValue List_dc8c7872 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c24cf806]);

    public static readonly Pine.Core.PineValue List_4437f6a9 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_2170dead]);

    public static readonly Pine.Core.PineValue List_e2befe2b =
        Pine.Core.PineValue.List(
            [List_da97fbb4, List_b223f41d, List_6906b28f]);

    public static readonly Pine.Core.PineValue List_e855f471 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_e2befe2b]);

    public static readonly Pine.Core.PineValue List_77d12fe5 =
        Pine.Core.PineValue.List(
            [List_8068f6f4, List_852987d0, List_bb14d771]);

    public static readonly Pine.Core.PineValue List_15b90792 =
        Pine.Core.PineValue.List(
            [List_c9797743, List_0f2c2ffb, List_be815d84]);

    public static readonly Pine.Core.PineValue List_228ecfec =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_77d12fe5]);

    public static readonly Pine.Core.PineValue List_bc4eb4fa =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_15b90792]);

    public static readonly Pine.Core.PineValue List_6550ac1f =
        Pine.Core.PineValue.List(
            [List_4932de99, List_0a1550b9]);

    public static readonly Pine.Core.PineValue List_37fa91bb =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_6550ac1f]);

    public static readonly Pine.Core.PineValue List_3789d1d7 =
        Pine.Core.PineValue.List(
            [List_f8bfc2d4, List_eaa5a196, List_2722c69a]);

    public static readonly Pine.Core.PineValue List_70b1755e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_3789d1d7]);

    public static readonly Pine.Core.PineValue List_Single_List_70b1755e =
        Pine.Core.PineValue.List(
            [List_70b1755e]);

    public static readonly Pine.Core.PineValue List_48533dbc =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_70b1755e]);

    public static readonly Pine.Core.PineValue List_ea0354f7 =
        Pine.Core.PineValue.List(
            [List_8f7015ea, List_5620b2e6, List_86d38b8d]);

    public static readonly Pine.Core.PineValue List_cb8c9ae9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_ea0354f7]);

    public static readonly Pine.Core.PineValue List_Single_List_cb8c9ae9 =
        Pine.Core.PineValue.List(
            [List_cb8c9ae9]);

    public static readonly Pine.Core.PineValue List_563750b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_cb8c9ae9]);

    public static readonly Pine.Core.PineValue List_7c8af5a0 =
        Pine.Core.PineValue.List(
            [List_38148fc9, List_fe634606, List_8e784b64, List_4af2c4d8, List_799abeba]);

    public static readonly Pine.Core.PineValue List_Single_List_7c8af5a0 =
        Pine.Core.PineValue.List(
            [List_7c8af5a0]);

    public static readonly Pine.Core.PineValue List_57a70a34 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_7c8af5a0]);

    public static readonly Pine.Core.PineValue List_c681c260 =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_57a70a34]);

    public static readonly Pine.Core.PineValue List_Single_List_c681c260 =
        Pine.Core.PineValue.List(
            [List_c681c260]);

    public static readonly Pine.Core.PineValue List_476a6575 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_c681c260]);

    public static readonly Pine.Core.PineValue List_b1de3d3b =
        Pine.Core.PineValue.List(
            [List_4923799e, List_6d371533, List_76001a59]);

    public static readonly Pine.Core.PineValue List_66335cb3 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_b1de3d3b]);

    public static readonly Pine.Core.PineValue List_2b408601 =
        Pine.Core.PineValue.List(
            [List_e79e127e, List_8885cd8d, List_403e01e8]);

    public static readonly Pine.Core.PineValue List_f63e619c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_2b408601]);

    public static readonly Pine.Core.PineValue List_bbfd4eb7 =
        Pine.Core.PineValue.List(
            [List_93b72dec, List_e855f471, List_c86be949]);

    public static readonly Pine.Core.PineValue List_7309bc5c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_bbfd4eb7]);

    public static readonly Pine.Core.PineValue List_d4260579 =
        Pine.Core.PineValue.List(
            [List_2ebf8fc7, List_590b0e3f, List_476a6575]);

    public static readonly Pine.Core.PineValue List_cc85d388 =
        Pine.Core.PineValue.List(
            [List_48533dbc, List_8000b22e]);

    public static readonly Pine.Core.PineValue List_8fe6550a =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_d4260579]);

    public static readonly Pine.Core.PineValue List_f8cc3fb0 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_cc85d388]);

    public static readonly Pine.Core.PineValue List_Single_List_f8cc3fb0 =
        Pine.Core.PineValue.List(
            [List_f8cc3fb0]);

    public static readonly Pine.Core.PineValue List_82af84ca =
        Pine.Core.PineValue.List(
            [List_11e84499, List_228ecfec, List_ec15df7b]);

    public static readonly Pine.Core.PineValue List_2111cf98 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_82af84ca]);

    public static readonly Pine.Core.PineValue List_593c044c =
        Pine.Core.PineValue.List(
            [List_ba30935e, List_d2e19685, List_aca6cda0]);

    public static readonly Pine.Core.PineValue List_76b77fd1 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_593c044c]);

    public static readonly Pine.Core.PineValue List_7ce6f39c =
        Pine.Core.PineValue.List(
            [List_d71bc0a6, List_66335cb3, List_49f51a1b]);

    public static readonly Pine.Core.PineValue List_6021f98b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7ce6f39c]);

    public static readonly Pine.Core.PineValue List_19a9b0e0 =
        Pine.Core.PineValue.List(
            [List_066f830b, List_57a75c31, List_4b2d910f]);

    public static readonly Pine.Core.PineValue List_f8151073 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_19a9b0e0]);

    public static readonly Pine.Core.PineValue List_126ab851 =
        Pine.Core.PineValue.List(
            [List_1b2d1a32, List_7309bc5c, List_b8b71b30]);

    public static readonly Pine.Core.PineValue List_1adec63e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_126ab851]);

    public static readonly Pine.Core.PineValue List_828e6acc =
        Pine.Core.PineValue.List(
            [List_a79c14f7, List_91c7a885, List_01bd811b]);

    public static readonly Pine.Core.PineValue List_1cd8ddd4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_828e6acc]);

    public static readonly Pine.Core.PineValue List_3913b8be =
        Pine.Core.PineValue.List(
            [List_563750b9, List_e4261fbb]);

    public static readonly Pine.Core.PineValue List_cfeded0e =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_3913b8be]);

    public static readonly Pine.Core.PineValue List_8046e9c6 =
        Pine.Core.PineValue.List(
            [List_ba30935e, List_2111cf98, List_37234ad4]);

    public static readonly Pine.Core.PineValue List_0f557aca =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_8046e9c6]);

    public static readonly Pine.Core.PineValue List_58ebce1d =
        Pine.Core.PineValue.List(
            [List_ac1b4431, List_6021f98b, List_cff1b75c]);

    public static readonly Pine.Core.PineValue List_7aeb8322 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_58ebce1d]);

    public static readonly Pine.Core.PineValue List_ec1228f0 =
        Pine.Core.PineValue.List(
            [List_467ef177, List_e185e50e, List_5ae8fd3b]);

    public static readonly Pine.Core.PineValue List_09676807 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_ec1228f0]);

    public static readonly Pine.Core.PineValue List_71dc25b6 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_af6ab14c, List_4e5ae7e4, List_81e8c713, List_095f8307]);

    public static readonly Pine.Core.PineValue List_58dfd014 =
        Pine.Core.PineValue.List(
            [List_121967d3, List_21e2e78c, List_feff2aab, List_390faaa1, List_50eafeb9]);

    public static readonly Pine.Core.PineValue List_Single_List_71dc25b6 =
        Pine.Core.PineValue.List(
            [List_71dc25b6]);

    public static readonly Pine.Core.PineValue List_Single_List_58dfd014 =
        Pine.Core.PineValue.List(
            [List_58dfd014]);

    public static readonly Pine.Core.PineValue List_3ed6e6ae =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_71dc25b6]);

    public static readonly Pine.Core.PineValue List_6afee1d0 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_58dfd014]);

    public static readonly Pine.Core.PineValue List_af4278bc =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_3ed6e6ae]);

    public static readonly Pine.Core.PineValue List_d13c2deb =
        Pine.Core.PineValue.List(
            [List_3c66e257, List_6afee1d0]);

    public static readonly Pine.Core.PineValue List_Single_List_af4278bc =
        Pine.Core.PineValue.List(
            [List_af4278bc]);

    public static readonly Pine.Core.PineValue List_Single_List_d13c2deb =
        Pine.Core.PineValue.List(
            [List_d13c2deb]);

    public static readonly Pine.Core.PineValue List_4571d9be =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_af4278bc]);

    public static readonly Pine.Core.PineValue List_18d4eb22 =
        Pine.Core.PineValue.List(
            [Blob_Str_List, List_Single_List_d13c2deb]);

    public static readonly Pine.Core.PineValue List_33a0f9d2 =
        Pine.Core.PineValue.List(
            [List_963aea9c, List_208a1fef, List_2e7a505a]);

    public static readonly Pine.Core.PineValue List_7dd973c9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_33a0f9d2]);

    public static readonly Pine.Core.PineValue List_3c01647a =
        Pine.Core.PineValue.List(
            [List_279fcf62, List_0f557aca, List_d0b6bef5]);

    public static readonly Pine.Core.PineValue List_f674d6c1 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_3c01647a]);

    public static readonly Pine.Core.PineValue List_79f66e3b =
        Pine.Core.PineValue.List(
            [List_5f85ed23, List_1adec63e, List_a691016a]);

    public static readonly Pine.Core.PineValue List_2e5ba283 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_79f66e3b]);

    public static readonly Pine.Core.PineValue List_4be7c09c =
        Pine.Core.PineValue.List(
            [List_6303b687, List_409f5309, List_e31d68fc]);

    public static readonly Pine.Core.PineValue List_7db4e258 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_4be7c09c]);

    public static readonly Pine.Core.PineValue List_78119532 =
        Pine.Core.PineValue.List(
            [List_1ee8f4a1, List_7aeb8322, List_34c68982]);

    public static readonly Pine.Core.PineValue List_b6b57e1c =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_78119532]);

    public static readonly Pine.Core.PineValue List_0bd1ef52 =
        Pine.Core.PineValue.List(
            [List_57c5f356, List_f63e619c, List_05fa8a74]);

    public static readonly Pine.Core.PineValue List_57320139 =
        Pine.Core.PineValue.List(
            [List_4ea01748, List_7b784b48, List_37fa91bb]);

    public static readonly Pine.Core.PineValue List_2be065ba =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0bd1ef52]);

    public static readonly Pine.Core.PineValue List_Single_List_2be065ba =
        Pine.Core.PineValue.List(
            [List_2be065ba]);

    public static readonly Pine.Core.PineValue List_a931cfeb =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_57320139]);

    public static readonly Pine.Core.PineValue List_34ea89b9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_2be065ba]);

    public static readonly Pine.Core.PineValue List_0488fa69 =
        Pine.Core.PineValue.List(
            [List_653f3279, List_2e5ba283, List_10ee6dd0]);

    public static readonly Pine.Core.PineValue List_9d389c12 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0488fa69]);

    public static readonly Pine.Core.PineValue List_7b67c5d9 =
        Pine.Core.PineValue.List(
            [List_7ad8a429, List_4b2d910f, List_f8151073]);

    public static readonly Pine.Core.PineValue List_6e8be30e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_7b67c5d9]);

    public static readonly Pine.Core.PineValue List_60b2c501 =
        Pine.Core.PineValue.List(
            [List_e64f48d5, List_b6b57e1c, List_287a2adc]);

    public static readonly Pine.Core.PineValue List_89b6373b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_60b2c501]);

    public static readonly Pine.Core.PineValue List_e9493e7c =
        Pine.Core.PineValue.List(
            [List_dff21a29, List_76b77fd1, List_4fbca2be]);

    public static readonly Pine.Core.PineValue List_68638ab5 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_e9493e7c]);

    public static readonly Pine.Core.PineValue List_47c00cf6 =
        Pine.Core.PineValue.List(
            [List_c0210a02, List_6538d979, List_a931cfeb]);

    public static readonly Pine.Core.PineValue List_9a7c1e1b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_47c00cf6]);

    public static readonly Pine.Core.PineValue List_6036a4a6 =
        Pine.Core.PineValue.List(
            [List_def87e98, List_27311de8, List_6e8be30e]);

    public static readonly Pine.Core.PineValue List_fe575105 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6036a4a6]);

    public static readonly Pine.Core.PineValue List_24a215a4 =
        Pine.Core.PineValue.List(
            [List_34ea89b9, List_9d4bb5f3]);

    public static readonly Pine.Core.PineValue List_99de08c7 =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_24a215a4]);

    public static readonly Pine.Core.PineValue List_d58ee894 =
        Pine.Core.PineValue.List(
            [List_9a1e26cb, Blob_Int_2, List_Single_List_f8cc3fb0, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_29bf1180 =
        Pine.Core.PineValue.List(
            [Blob_Str_Function, List_d58ee894]);

    public static readonly Pine.Core.PineValue List_55560b74 =
        Pine.Core.PineValue.List(
            [List_3cab333c, List_9d389c12, List_b5221b1b]);

    public static readonly Pine.Core.PineValue List_4a91ee04 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_55560b74]);

    public static readonly Pine.Core.PineValue List_83e59488 =
        Pine.Core.PineValue.List(
            [List_f51b8ded, List_89b6373b, List_b9327097]);

    public static readonly Pine.Core.PineValue List_0b1139c9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_83e59488]);

    public static readonly Pine.Core.PineValue List_651f2fce =
        Pine.Core.PineValue.List(
            [List_0ff05915, List_0b1139c9, List_9a9bd68c]);

    public static readonly Pine.Core.PineValue List_963b6d7e =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_651f2fce]);

    public static readonly Pine.Core.PineValue List_Single_List_963b6d7e =
        Pine.Core.PineValue.List(
            [List_963b6d7e]);

    public static readonly Pine.Core.PineValue List_efc27773 =
        Pine.Core.PineValue.List(
            [Blob_Str_Literal, List_Single_List_963b6d7e]);

    public static readonly Pine.Core.PineValue List_f836f5a8 =
        Pine.Core.PineValue.List(
            [List_e349ba15, List_3f936680, List_99de08c7]);

    public static readonly Pine.Core.PineValue List_c445d03a =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_f836f5a8]);

    public static readonly Pine.Core.PineValue List_830feeea =
        Pine.Core.PineValue.List(
            [List_82da83de, List_68638ab5, List_cc6c3cee]);

    public static readonly Pine.Core.PineValue List_085c5bfe =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_830feeea]);

    public static readonly Pine.Core.PineValue List_c5287cd6 =
        Pine.Core.PineValue.List(
            [List_0c25448d, List_8fe6550a, List_476a6575]);

    public static readonly Pine.Core.PineValue List_ff4cc313 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c5287cd6]);

    public static readonly Pine.Core.PineValue List_e4b1b52e =
        Pine.Core.PineValue.List(
            [List_279fcf62, List_085c5bfe, List_45564a6a]);

    public static readonly Pine.Core.PineValue List_097a0bb9 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_e4b1b52e]);

    public static readonly Pine.Core.PineValue List_38eb9622 =
        Pine.Core.PineValue.List(
            [List_df6df33c, List_4a91ee04, List_128a91eb]);

    public static readonly Pine.Core.PineValue List_1aac970b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_38eb9622]);

    public static readonly Pine.Core.PineValue List_9aabfa24 =
        Pine.Core.PineValue.List(
            [List_654bdd12, List_e31d68fc, List_7db4e258]);

    public static readonly Pine.Core.PineValue List_c82dc7db =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_9aabfa24]);

    public static readonly Pine.Core.PineValue List_4ba0bc28 =
        Pine.Core.PineValue.List(
            [List_ee9cff15, List_c445d03a, List_aa527ebf]);

    public static readonly Pine.Core.PineValue List_ea679199 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_4ba0bc28]);

    public static readonly Pine.Core.PineValue List_50cfb691 =
        Pine.Core.PineValue.List(
            [List_efc27773, List_5420d5e4]);

    public static readonly Pine.Core.PineValue List_0da2f7ed =
        Pine.Core.PineValue.List(
            [Blob_Str_ParseAndEval, List_50cfb691]);

    public static readonly Pine.Core.PineValue List_c6cddf68 =
        Pine.Core.PineValue.List(
            [List_d1a85706, List_b43468c9, List_ff4cc313]);

    public static readonly Pine.Core.PineValue List_25f7ab7a =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_c6cddf68]);

    public static readonly Pine.Core.PineValue List_3168cba2 =
        Pine.Core.PineValue.List(
            [List_3c873ec4, List_abb59323, List_ef7a3e89, List_f674d6c1, List_dd880f82]);

    public static readonly Pine.Core.PineValue List_ca6b23cc =
        Pine.Core.PineValue.List(
            [List_0425a888, Blob_Int_2, List_3168cba2, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_bfd246c7 =
        Pine.Core.PineValue.List(
            [Blob_Str_Function, List_ca6b23cc]);

    public static readonly Pine.Core.PineValue List_73d16cac =
        Pine.Core.PineValue.List(
            [List_35e000d3, List_09676807, List_1cd8ddd4]);

    public static readonly Pine.Core.PineValue List_e6d15ff4 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_73d16cac]);

    public static readonly Pine.Core.PineValue List_0c71d702 =
        Pine.Core.PineValue.List(
            [List_7893301e, List_26f30e27, List_c82dc7db]);

    public static readonly Pine.Core.PineValue List_14c4f77b =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_0c71d702]);

    public static readonly Pine.Core.PineValue List_6d0a411c =
        Pine.Core.PineValue.List(
            [List_c0210a02, List_7efafede, List_14c4f77b]);

    public static readonly Pine.Core.PineValue List_66f1a974 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6d0a411c]);

    public static readonly Pine.Core.PineValue List_78b0d8ce =
        Pine.Core.PineValue.List(
            [List_754ca20c, List_66f1a974, List_27311de8]);

    public static readonly Pine.Core.PineValue List_ac3e6060 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_78b0d8ce]);

    public static readonly Pine.Core.PineValue List_c3e10b01 =
        Pine.Core.PineValue.List(
            [List_c78b4c00, List_6aadd8cd, List_097a0bb9, List_bc4eb4fa]);

    public static readonly Pine.Core.PineValue List_d9fe2dbf =
        Pine.Core.PineValue.List(
            [List_097a0bb9, List_c78b4c00, List_6aadd8cd, List_bc4eb4fa]);

    public static readonly Pine.Core.PineValue List_e6c83b6d =
        Pine.Core.PineValue.List(
            [List_6c4757ae, Blob_Int_2, List_c3e10b01, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_a60c0379 =
        Pine.Core.PineValue.List(
            [Blob_Str_Function, List_e6c83b6d]);

    public static readonly Pine.Core.PineValue List_512b4e55 =
        Pine.Core.PineValue.List(
            [List_f890355b, Blob_Int_2, List_d9fe2dbf, Pine.Core.PineValue.EmptyList]);

    public static readonly Pine.Core.PineValue List_2d243751 =
        Pine.Core.PineValue.List(
            [Blob_Str_Function, List_512b4e55]);

    public static readonly Pine.Core.PineValue List_913da3bc =
        Pine.Core.PineValue.List(
            [List_10dfa68f, List_25f7ab7a, List_4571d9be]);

    public static readonly Pine.Core.PineValue List_6e72099f =
        Pine.Core.PineValue.List(
            [List_80b7cb18, List_25f7ab7a, List_18d4eb22]);

    public static readonly Pine.Core.PineValue List_c051d150 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_913da3bc]);

    public static readonly Pine.Core.PineValue List_59345918 =
        Pine.Core.PineValue.List(
            [Blob_Str_Conditional, List_6e72099f]);
}
