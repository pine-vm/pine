namespace PrecompiledPineToDotNet;

public static class Dispatcher
{
    public static System.Collections.Generic.IReadOnlyDictionary<Pine.Core.PineValue, System.Func<Pine.Core.PineValue, Pine.Core.PineValue>> dispatcherDictionary =
        BuildDispatcherDictionary();

    public static System.Collections.Generic.IReadOnlyDictionary<Pine.Core.PineValue, System.Func<Pine.Core.PineValue, Pine.Core.PineValue>> BuildDispatcherDictionary()
    {
        var dict =
            new System.Collections.Generic.Dictionary<Pine.Core.PineValue, System.Func<Pine.Core.PineValue, Pine.Core.PineValue>>();

        dict[CommonReusedValues.List_abb59323] =
            Dispatch_abb59323;

        dict[CommonReusedValues.List_7dd973c9] =
            Dispatch_7dd973c9;

        dict[CommonReusedValues.List_ea679199] =
            Dispatch_ea679199;

        dict[CommonReusedValues.List_dd880f82] =
            Dispatch_dd880f82;

        dict[CommonReusedValues.List_097a0bb9] =
            Dispatch_097a0bb9;

        dict[CommonReusedValues.List_53226cad] =
            Dispatch_53226cad;

        dict[CommonReusedValues.List_1aac970b] =
            Dispatch_1aac970b;

        dict[CommonReusedValues.List_e6d15ff4] =
            Dispatch_e6d15ff4;

        dict[CommonReusedValues.List_6aadd8cd] =
            Dispatch_6aadd8cd;

        dict[CommonReusedValues.List_88e1499a] =
            Dispatch_88e1499a;

        dict[CommonReusedValues.List_cfeded0e] =
            Dispatch_cfeded0e;

        dict[CommonReusedValues.List_fe575105] =
            Dispatch_fe575105;

        dict[CommonReusedValues.List_5d5a0297] =
            Dispatch_5d5a0297;

        dict[CommonReusedValues.List_4437f6a9] =
            Dispatch_4437f6a9;

        dict[CommonReusedValues.List_36238402] =
            Dispatch_36238402;

        dict[CommonReusedValues.List_3f5c9f68] =
            Dispatch_3f5c9f68;

        dict[CommonReusedValues.List_9a1e26cb] =
            Dispatch_9a1e26cb;

        dict[CommonReusedValues.List_59345918] =
            Dispatch_59345918;

        dict[CommonReusedValues.List_610ee3fc] =
            Dispatch_610ee3fc;

        dict[CommonReusedValues.List_bc4eb4fa] =
            Dispatch_bc4eb4fa;

        dict[CommonReusedValues.List_0da2f7ed] =
            Dispatch_0da2f7ed;

        dict[CommonReusedValues.List_9a7c1e1b] =
            Dispatch_9a7c1e1b;

        dict[CommonReusedValues.List_12af8dcc] =
            Dispatch_12af8dcc;

        dict[CommonReusedValues.List_a5c995b4] =
            Dispatch_a5c995b4;

        dict[CommonReusedValues.List_632693ae] =
            Dispatch_632693ae;

        dict[CommonReusedValues.List_c051d150] =
            Dispatch_c051d150;

        dict[CommonReusedValues.List_39fa68f8] =
            Dispatch_39fa68f8;

        dict[CommonReusedValues.List_d97a2014] =
            Dispatch_d97a2014;

        dict[CommonReusedValues.List_ef7a3e89] =
            Dispatch_ef7a3e89;

        dict[CommonReusedValues.List_f674d6c1] =
            Dispatch_f674d6c1;

        dict[CommonReusedValues.List_f164dec2] =
            Dispatch_f164dec2;

        dict[CommonReusedValues.List_449d95bc] =
            Dispatch_449d95bc;

        dict[CommonReusedValues.List_985c9717] =
            Dispatch_985c9717;

        dict[CommonReusedValues.List_c78b4c00] =
            Dispatch_c78b4c00;

        dict[CommonReusedValues.List_3c873ec4] =
            Dispatch_3c873ec4;

        dict[CommonReusedValues.List_ac3e6060] =
            Dispatch_ac3e6060;

        dict[CommonReusedValues.List_627f403e] =
            Dispatch_627f403e;

        dict[CommonReusedValues.List_523cfc6b] =
            Dispatch_523cfc6b;

        dict[CommonReusedValues.List_462b85bd] =
            Dispatch_462b85bd;

        dict[CommonReusedValues.List_f890355b] =
            Dispatch_f890355b;

        dict[CommonReusedValues.List_0f6e756a] =
            Dispatch_0f6e756a;

        dict[CommonReusedValues.List_f8cc3fb0] =
            Dispatch_f8cc3fb0;

        return dict;
    }


    public static Pine.Core.PineValue? Dispatch_abb59323(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_abb59323)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Dict.keys(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_7dd973c9(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c051d150)
        {
            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            var arg_1_4 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 4]);

            var arg_1_5 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 5]);

            var arg_1_6 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 6]);

            return Global_Anonymous.zzz_anon_7dd973c9_1b8db7d8(arg_1_1, arg_1_2, arg_1_3, arg_1_4, arg_1_5, arg_1_6);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_ea679199(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_a60c0379)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_e6d15ff4)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_ea679199))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_ea679199_b65beb0f(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_dd880f82(Pine.Core.PineValue environment)
    {
        if (((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3c873ec4) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_abb59323)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ef7a3e89)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f674d6c1)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_dd880f82))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_dd880f82_13e5e91e(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_097a0bb9(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c78b4c00) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_6aadd8cd)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_097a0bb9)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.compare(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_53226cad(Pine.Core.PineValue environment)
    {
        if (((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_1aac970b)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_0da2f7ed))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.toInt(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_1aac970b(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0da2f7ed)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_1aac970b_200123d4(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_e6d15ff4(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            var arg_1_3 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 3]);

            var arg_1_4 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 4]);

            return Global_Anonymous.zzz_anon_e6d15ff4_dda26649(arg_1_0, arg_1_1, arg_1_2, arg_1_3, arg_1_4);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_6aadd8cd(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_6aadd8cd)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Basics.compareStrings(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_88e1499a(Pine.Core.PineValue environment)
    {
        if (((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_449d95bc) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_627f403e))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trim(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_cfeded0e(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return String.padLeft(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_fe575105(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_e6d15ff4)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_59345918)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_fe575105))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_fe575105_eb1f9043(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_5d5a0297(Pine.Core.PineValue environment)
    {
        if (((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3f5c9f68) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_9a1e26cb)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_f8cc3fb0))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.modBy(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_4437f6a9(Pine.Core.PineValue environment)
    {
        if (((((((((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ac3e6060)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_2d243751)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bfd246c7)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_7dd973c9)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_c051d150)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_e6d15ff4)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_59345918)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_fe575105)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_f164dec2)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Dict.remove(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_36238402(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_627f403e) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trimRight(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_3f5c9f68(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_9a1e26cb) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_f8cc3fb0))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.remainderBy(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_9a1e26cb(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f8cc3fb0)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.idiv(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_59345918(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_59345918_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_610ee3fc(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_462b85bd) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_610ee3fc))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_610ee3fc_622604de(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_bc4eb4fa(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_c78b4c00) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_6aadd8cd)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_097a0bb9)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.compareList(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_0da2f7ed(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0da2f7ed)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_0da2f7ed_200123d4(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_9a7c1e1b(Pine.Core.PineValue environment)
    {
        if (((((((((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_2d243751)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_7dd973c9)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_c051d150)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_e6d15ff4)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_59345918)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_fe575105)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f164dec2)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_ac3e6060)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_9a7c1e1b_386942a1(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_12af8dcc(Pine.Core.PineValue environment)
    {
        if (((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_632693ae) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_29bf1180)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_12af8dcc_650df00b(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_a5c995b4(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_449d95bc) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_d97a2014))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.trimLeft(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_632693ae(Pine.Core.PineValue environment)
    {
        if (((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_29bf1180) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_39fa68f8)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_632693ae))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_632693ae_2f148225(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_c051d150(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_c051d150_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_39fa68f8(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_39fa68f8)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_39fa68f8_2402eeb0(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_d97a2014(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_d97a2014_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_ef7a3e89(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_ef7a3e89)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Dict.toList(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_f674d6c1(Pine.Core.PineValue environment)
    {
        if (((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_3c873ec4) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_abb59323)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_ef7a3e89)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_f674d6c1)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_dd880f82))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.eq(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_f164dec2(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f164dec2)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_f164dec2_b6de04bb(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_449d95bc(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_d97a2014) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_449d95bc))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_449d95bc_da6f86d5(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_985c9717(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_ea679199)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_a60c0379)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_e6d15ff4))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Dict.insert(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_c78b4c00(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_c78b4c00_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_3c873ec4(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_3c873ec4_dda26649(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_ac3e6060(Pine.Core.PineValue environment)
    {
        if (((((((((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_dc8c7872) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_2d243751)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_bfd246c7)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_7dd973c9)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_c051d150)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 5]) == CommonReusedValues.List_e6d15ff4)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 6]) == CommonReusedValues.List_59345918)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 7]) == CommonReusedValues.List_fe575105)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 8]) == CommonReusedValues.List_f164dec2)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 9]) == CommonReusedValues.List_ac3e6060)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 10]) == CommonReusedValues.List_9a7c1e1b))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_ac3e6060_386942a1(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_627f403e(Pine.Core.PineValue environment)
    {
        if ((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_d97a2014) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_627f403e))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Global_Anonymous.zzz_anon_627f403e_dca18c16(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_523cfc6b(Pine.Core.PineValue environment)
    {
        if (((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_0f6e756a) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_12af8dcc)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_632693ae)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_29bf1180)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 4]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return String.fromInt(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_462b85bd(Pine.Core.PineValue environment)
    {
        if (true)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return List.cons(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_f890355b(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_097a0bb9) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_c78b4c00)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_6aadd8cd)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_bc4eb4fa))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            return Basics.lt(arg_1_0, arg_1_1);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_0f6e756a(Pine.Core.PineValue environment)
    {
        if ((((Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_12af8dcc) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 1]) == CommonReusedValues.List_632693ae)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 2]) == CommonReusedValues.List_29bf1180)) && (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 3]) == CommonReusedValues.List_39fa68f8))
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            return Global_Anonymous.zzz_anon_0f6e756a_a4f70149(arg_1_0);
        }

        return null;
    }


    public static Pine.Core.PineValue? Dispatch_f8cc3fb0(Pine.Core.PineValue environment)
    {
        if (Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            environment,
            [0, 0]) == CommonReusedValues.List_f8cc3fb0)
        {
            var arg_1_0 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 0]);

            var arg_1_1 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 1]);

            var arg_1_2 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    environment,
                    [1, 2]);

            return Global_Anonymous.zzz_anon_f8cc3fb0_cbcb2ff6(arg_1_0, arg_1_1, arg_1_2);
        }

        return null;
    }
}
