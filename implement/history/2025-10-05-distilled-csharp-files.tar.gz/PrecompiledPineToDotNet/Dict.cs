namespace PrecompiledPineToDotNet;

public static class Dict
{
    public static Pine.Core.PineValue insert(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1,
        Pine.Core.PineValue param_1_2)
    {
        Pine.Core.PineValue local_000 =
            Global_Anonymous.zzz_anon_ea679199_b65beb0f(param_1_0, param_1_1, param_1_2);

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0])))
        {
            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.List_7222f8d4,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [2]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])
                            ])
                    ]);
        }

        return local_000;
    }


    public static Pine.Core.PineValue keys(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return Pine.Core.PineValue.EmptyList;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Pine.Core.KernelFunction.concat(
                    Pine.Core.PineValue.List(
                        [
                            Dict.keys(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3])),
                            Pine.Core.PineValue.List(
                                [
                                    Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                        local_001,
                                        [1])
                                ]),
                            Dict.keys(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4]))
                        ]));
        }

        throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine.Core.PineValue remove(
        Pine.Core.PineValue param_1_0,
        Pine.Core.PineValue param_1_1)
    {
        Pine.Core.PineValue local_000 =
            Global_Anonymous.zzz_anon_ac3e6060_386942a1(param_1_0, param_1_1);

        Pine.Core.PineValue local_001 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                local_000,
                [1]);

        if ((CommonReusedValues.Blob_Str_Red == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_001,
            [0, 0])) && (CommonReusedValues.Blob_Str_RBNode_elm_builtin == Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
            local_000,
            [0])))
        {
            return
                Pine.Core.PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_RBNode_elm_builtin,
                        Pine.Core.PineValue.List(
                            [
                                CommonReusedValues.List_7222f8d4,
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [1]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [2]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3]),
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4])
                            ])
                    ]);
        }

        return local_000;
    }


    public static Pine.Core.PineValue toList(Pine.Core.PineValue param_1_0)
    {
        Pine.Core.PineValue local_000 =
            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_RBEmpty_elm_builtin == local_000)
        {
            return Pine.Core.PineValue.EmptyList;
        }

        if (CommonReusedValues.Blob_Str_RBNode_elm_builtin == local_000)
        {
            Pine.Core.PineValue local_001 =
                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1]);

            return
                Pine.Core.KernelFunction.concat(
                    Pine.Core.PineValue.List(
                        [
                            Dict.toList(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [3])),
                            Pine.Core.PineValue.List(
                                [
                                    Pine.Core.PineValue.List(
                                        [
                                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1]),
                                            Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [2])
                                        ])
                                ]),
                            Dict.toList(
                                Pine.Core.PineValueExtension.ValueFromPathOrEmptyList(
                                    local_001,
                                    [4]))
                        ]));
        }

        throw new Pine.Core.CodeAnalysis.ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }
}
