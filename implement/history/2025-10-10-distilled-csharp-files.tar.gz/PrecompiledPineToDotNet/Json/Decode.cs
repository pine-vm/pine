using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet.Json;

public static class Decode
{
    public static Pine_PineValue parseJsonStringToValue(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [1, 0]);

        Pine_PineValue local_001 =
            Global_Anonymous.zzz_anon_a418ab23_4792582f(local_000, CommonReusedValues.Blob_Int_0);

        Pine_PineValue local_002 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_001,
                [0]);

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]);

        if (CommonReusedValues.Blob_Str_Ok == local_003)
        {
            Pine_PineValue local_004 =
                Json.Decode.skipWhitespace(
                    local_000,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [1]));

            if (local_004 == Pine_KernelFunction.length(local_000))
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        local_002,
                                        [1, 0])
                                ])
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunction.concat(
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_5d0b564e,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                String.fromInt(
                                                                    Pine_KernelFunctionFused.BlobPrependByte(
                                                                        byteToPrepend: 4,
                                                                        suffix:
                                                                        Pine_KernelFunctionSpecialized.bit_shift_right(
                                                                            2,
                                                                            Pine_KernelFunctionSpecialized.skip(1, local_004)))),
                                                                [1, 0]),
                                                            CommonReusedValues.Blob_043f59dd,
                                                            Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_004, argument: local_000),
                                                            CommonReusedValues.Blob_Char_quote
                                                        ]))
                                            ])
                                    ])
                            ])
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Err == local_003)
        {
            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunction.concat(
                                                    Pine_PineValue.List(
                                                        [
                                                            CommonReusedValues.Blob_19b35fb2,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                String.fromInt(
                                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                        local_001,
                                                                        [1])),
                                                                [1, 0]),
                                                            CommonReusedValues.Blob_4eade2d9,
                                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                                local_002,
                                                                [1, 0, 1, 0])
                                                        ]))
                                            ])
                                    ])
                            ])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue skipWhitespace(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_PineValue local_param_1_0 =
            param_1_0;

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            Pine_PineValue local_000 =
                Pine_KernelFunctionFused.SkipAndTake(takeCount: 4, skipCountValue: local_param_1_1, argument: local_param_1_0);

            if (local_000 == CommonReusedValues.Blob_Char_space)
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_tab)
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_newline)
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            if (local_000 == CommonReusedValues.Blob_Char_carriagereturn)
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(4, local_param_1_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            return local_param_1_1;
        }
    }
}
