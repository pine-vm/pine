using Pine_ParseExpressionException = global::Pine.Core.CodeAnalysis.ParseExpressionException;
using Pine_ImmutableConcatBuilder = global::Pine.Core.DotNet.Builtins.ImmutableConcatBuilder;
using Pine_ImmutableSliceBuilder = global::Pine.Core.DotNet.Builtins.ImmutableSliceBuilder;
using Pine_MutatingConcatBuilder = global::Pine.Core.DotNet.Builtins.MutatingConcatBuilder;
using Pine_KernelFunctionFused = global::Pine.Core.Internal.KernelFunctionFused;
using Pine_KernelFunctionSpecialized = global::Pine.Core.Internal.KernelFunctionSpecialized;
using Pine_KernelFunction = global::Pine.Core.KernelFunction;
using Pine_PineValue = global::Pine.Core.PineValue;
using Pine_PineValueExtension = global::Pine.Core.PineValueExtension;
using Pine_PineKernelValues = global::Pine.Core.PineVM.PineKernelValues;
using Pine_ExpressionEncoding = global::Pine.Core.PopularEncodings.ExpressionEncoding;
using Pine_IntegerEncoding = global::Pine.Core.PopularEncodings.IntegerEncoding;
using Pine_StringEncoding = global::Pine.Core.PopularEncodings.StringEncoding;

namespace PrecompiledPineToDotNet;

public static class Pine
{
    public static Pine_PineValue bigIntFromBlobValue(Pine_PineValue param_1_0)
    {
        if (param_1_0 == Pine_PineValue.EmptyList)
        {
            return CommonReusedValues.List_c884fc84;
        }

        if (!(Pine_KernelFunctionSpecialized.length_as_int(param_1_0) == 0))
        {
            Pine_PineValue local_000 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [0]);

            if (local_000 == CommonReusedValues.Blob_Int_4)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Global_Anonymous.zzz_anon_f9abafe1_f31f3b62(
                                        Pine_KernelFunctionSpecialized.skip(1, param_1_0))
                                ])
                        ]);
            }

            if (local_000 == CommonReusedValues.Blob_Int_2)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Ok,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunction.negate(
                                        Global_Anonymous.zzz_anon_f9abafe1_f31f3b62(
                                            Pine_KernelFunctionSpecialized.skip(1, param_1_0)))
                                ])
                        ]);
            }

            return
                Pine_PineValue.List(
                    [
                        CommonReusedValues.Blob_Str_Err,
                        Pine_PineValue.List(
                            [
                                Pine_PineValue.List(
                                    [
                                        CommonReusedValues.Blob_Str_String,
                                        Pine_PineValue.List(
                                            [
                                                Pine_KernelFunctionSpecialized.concat(
                                                    CommonReusedValues.Blob_0972a741,
                                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                        String.fromInt(local_000),
                                                        [1, 0]))
                                            ])
                                    ])
                            ])
                    ]);
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue bigIntFromValue(Pine_PineValue param_1_0)
    {
        if (CommonReusedValues.Blob_Str_BlobValue == Pine_PineValueExtension.ValueFromPathOrEmptyList(
            param_1_0,
            [0]))
        {
            return
                Pine.bigIntFromBlobValue(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        return CommonReusedValues.List_9a337336;
    }


    public static Pine_PineValue blobBytesFromChar(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionFused.CanonicalIntegerFromUnsigned(signIsPositive: true, unsignedValue: param_1_0);

        Pine_PineValue local_001 =
            Pine_IntegerEncoding.EncodeSignedInteger(
                Pine_KernelFunctionSpecialized.length_as_int(local_000));

        Pine_PineValue local_002 =
            Pine_KernelFunction.ValueFromBool(
                Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(2, local_001));

        return
            Pine_PineValue.List(
                [
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        Basics.idiv(local_000, CommonReusedValues.Blob_Int_16777216)),
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        local_002 == Pine_PineKernelValues.TrueValue
                        ?
                        (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(4, local_001)
                        ?
                        Pine_KernelFunctionFused.SkipLast(skipCount: 2, value: local_000)
                        :
                        CommonReusedValues.Blob_Int_0)
                        :
                        Pine_PineValue.EmptyList),
                    Basics.modBy(
                        CommonReusedValues.Blob_Int_256,
                        local_002 == Pine_PineKernelValues.TrueValue
                        ?
                        (Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(3, local_001)
                        ?
                        Pine_KernelFunctionFused.SkipLast(skipCount: 1, value: local_000)
                        :
                        CommonReusedValues.Blob_Int_0)
                        :
                        Pine_PineValue.EmptyList),
                    Basics.modBy(CommonReusedValues.Blob_Int_256, local_000)
                ]);
    }


    public static Pine_PineValue blobValueFromBigInt(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_KernelFunctionSpecialized.int_is_sorted_asc_as_boolean(0, param_1_0)
            ?
            param_1_0
            :
            Pine_KernelFunctionSpecialized.int_mul(-1, param_1_0);

        Pine_PineValue local_002 =
            BigInt.lt(local_000, CommonReusedValues.Blob_Int_256) == Pine_PineKernelValues.TrueValue
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    Global_Anonymous.zzz_anon_7a86a9ad_91692913(local_000)),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    Global_Anonymous.zzz_anon_7a86a9ad_91692913(local_000)),
                [0])
            ?
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_PineValue.List(
                                [
                                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                        Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                                            Global_Anonymous.zzz_anon_7a86a9ad_91692913(local_000)),
                                        [1, 0])
                                ])
                        ])
                ])
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                [0])
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dc80c2ca_a342fb06(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                        [1, 0, 0])),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dc80c2ca_a342fb06(
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                        [1, 0, 0])),
                [0])
            ?
            (CommonReusedValues.Blob_Str_Nothing == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    Global_Anonymous.zzz_anon_7a86a9ad_91692913(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                            [1, 0, 1]))),
                [0])
            ?
            CommonReusedValues.List_13731c89
            :
            (CommonReusedValues.Blob_Str_Just == Pine_PineValueExtension.ValueFromPathOrEmptyList(
                Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                    Global_Anonymous.zzz_anon_7a86a9ad_91692913(
                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                            [1, 0, 1]))),
                [0])
            ?
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_Just,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunctionFused.ListAppendItem(
                                prefix:
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    Global_Anonymous.zzz_anon_dc80c2ca_a342fb06(
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                                            [1, 0, 0])),
                                    [1, 0]),
                                itemToAppend:
                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                    Global_Anonymous.zzz_anon_dbf42a10_90befd56(
                                        Global_Anonymous.zzz_anon_7a86a9ad_91692913(
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                BigInt.divmod(local_000, CommonReusedValues.Blob_Int_256),
                                                [1, 0, 1]))),
                                    [1, 0]))
                        ])
                ])
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")))
            :
            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions")));

        Pine_PineValue local_003 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                local_002,
                [0]);

        if (CommonReusedValues.Blob_Str_Nothing == local_003)
        {
            return
                Pine_PineValue.List(
                    [
                        Pine_IntegerEncoding.EncodeSignedInteger(
                            Basics.eq(local_000, param_1_0) == Pine_PineKernelValues.TrueValue
                            ?
                            4
                            :
                            2)
                    ]);
        }

        if (CommonReusedValues.Blob_Str_Just == local_003)
        {
            return
                Pine_KernelFunctionFused.ListPrependItem(
                    itemToPrepend:
                    Pine_IntegerEncoding.EncodeSignedInteger(
                        Basics.eq(local_000, param_1_0) == Pine_PineKernelValues.TrueValue
                        ?
                        4
                        :
                        2),
                    suffix:
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_002,
                        [1, 0]));
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue computeValueFromString(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_BlobValue,
                    Pine_PineValue.List(
                        [
                            Pine_KernelFunction.concat(
                                Global_Anonymous.zzz_anon_8792c675_b6a881f2(
                                    Pine_PineValue.EmptyList,
                                    Global_Anonymous.zzz_anon_bef7232d_3c2bb8d5(
                                        CommonReusedValues.Blob_Int_0,
                                        Pine_PineValue.EmptyList,
                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                            param_1_0,
                                            [1, 0]))))
                        ])
                ]);
    }


    public static Pine_PineValue intFromUnsignedBlobValue(
        Pine_PineValue param_1_0,
        Pine_PineValue param_1_1)
    {
        Pine_ImmutableSliceBuilder local_param_1_0 =
            Pine_ImmutableSliceBuilder.Create(param_1_0);

        Pine_PineValue local_param_1_1 =
            param_1_1;

        while (true)
        {
            if (local_param_1_0.IsEmptyList())
            {
                return local_param_1_1;
            }

            if (!(local_param_1_0.GetLength() == 0))
            {
                {
                    Pine_PineValue local_param_1_1_temp =
                        Pine_KernelFunctionSpecialized.int_add(
                            Pine_KernelFunctionSpecialized.int_mul(256, local_param_1_1),
                            local_param_1_0.GetHead());

                    local_param_1_0 =
                        local_param_1_0.Skip(CommonReusedValues.Blob_Int_1);

                    local_param_1_1 =
                        local_param_1_1_temp;
                }

                continue;
            }

            throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
        }
    }


    public static Pine_PineValue intFromValue(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_9a337336;
        }

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]);

            Pine_PineValue local_002 =
                Pine_KernelFunctionSpecialized.skip(1, local_001);

            if (!(Pine_KernelFunctionSpecialized.length_as_int(local_002) == 0))
            {
                Pine_PineValue local_003 =
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        local_001,
                        [0]);

                if (local_003 == CommonReusedValues.Blob_Int_4)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine.intFromUnsignedBlobValue(
                                            Pine_KernelFunctionSpecialized.skip(1, local_002),
                                            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                local_001,
                                                [1]))
                                    ])
                            ]);
                }

                if (local_003 == CommonReusedValues.Blob_Int_2)
                {
                    return
                        Pine_PineValue.List(
                            [
                                CommonReusedValues.Blob_Str_Ok,
                                Pine_PineValue.List(
                                    [
                                        Pine_KernelFunction.negate(
                                            Pine.intFromUnsignedBlobValue(
                                                Pine_KernelFunctionSpecialized.skip(1, local_002),
                                                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                    local_001,
                                                    [1])))
                                    ])
                            ]);
                }

                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_Err,
                            Pine_PineValue.List(
                                [
                                    Pine_PineValue.List(
                                        [
                                            CommonReusedValues.Blob_Str_String,
                                            Pine_PineValue.List(
                                                [
                                                    Pine_KernelFunctionSpecialized.concat(
                                                        CommonReusedValues.Blob_0972a741,
                                                        Pine_PineValueExtension.ValueFromPathOrEmptyList(
                                                            String.fromInt(local_003),
                                                            [1, 0]))
                                                ])
                                        ])
                                ])
                        ]);
            }

            return CommonReusedValues.List_947ee852;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue kernelFunction_negate(Pine_PineValue param_1_0)
    {
        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            Pine_PineValue local_001 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    param_1_0,
                    [1, 0]);

            Pine_PineValue local_002 =
                Pine_PineValueExtension.ValueFromPathOrEmptyList(
                    local_001,
                    [0]);

            if (local_002 == CommonReusedValues.Blob_Int_4)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionFused.ListPrependItem(
                                        itemToPrepend:
                                        Pine_IntegerEncoding.EncodeSignedInteger(2),
                                        suffix:
                                        Pine_KernelFunctionSpecialized.skip(1, local_001))
                                ])
                        ]);
            }

            if (local_002 == CommonReusedValues.Blob_Int_2)
            {
                return
                    Pine_PineValue.List(
                        [
                            CommonReusedValues.Blob_Str_BlobValue,
                            Pine_PineValue.List(
                                [
                                    Pine_KernelFunctionFused.ListPrependItem(
                                        itemToPrepend:
                                        Pine_IntegerEncoding.EncodeSignedInteger(4),
                                        suffix:
                                        Pine_KernelFunctionSpecialized.skip(1, local_001))
                                ])
                        ]);
            }

            return CommonReusedValues.List_1f3f2fca;
        }

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_1f3f2fca;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue stringFromValue(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.List_0a078809)
        {
            return CommonReusedValues.List_7aba86e6;
        }

        if (param_1_0 == CommonReusedValues.List_aa8cd902)
        {
            return CommonReusedValues.List_487b9fe1;
        }

        if (param_1_0 == CommonReusedValues.List_fa615f0b)
        {
            return CommonReusedValues.List_28bd95f6;
        }

        if (param_1_0 == CommonReusedValues.List_4bcbcd70)
        {
            return CommonReusedValues.List_97dbe947;
        }

        if (param_1_0 == CommonReusedValues.List_b8120726)
        {
            return CommonReusedValues.List_bf69db3f;
        }

        if (param_1_0 == CommonReusedValues.List_f4325494)
        {
            return CommonReusedValues.List_8fb47f0c;
        }

        if (param_1_0 == CommonReusedValues.List_38faf44f)
        {
            return CommonReusedValues.List_53f100a3;
        }

        if (param_1_0 == CommonReusedValues.List_8a17d2aa)
        {
            return CommonReusedValues.List_fd351edd;
        }

        Pine_PineValue local_000 =
            Pine_PineValueExtension.ValueFromPathOrEmptyList(
                param_1_0,
                [0]);

        if (CommonReusedValues.Blob_Str_BlobValue == local_000)
        {
            return
                Global_Anonymous.zzz_anon_fcb519b2_37c5864a(
                    Pine_PineValue.EmptyList,
                    Pine_PineValueExtension.ValueFromPathOrEmptyList(
                        param_1_0,
                        [1, 0]));
        }

        if (CommonReusedValues.Blob_Str_ListValue == local_000)
        {
            return CommonReusedValues.List_01a75b86;
        }

        throw new Pine_ParseExpressionException("TODO: Include details from encoded and env subexpressions");
    }


    public static Pine_PineValue valueFromBigInt(Pine_PineValue param_1_0)
    {
        return
            Pine_PineValue.List(
                [
                    CommonReusedValues.Blob_Str_BlobValue,
                    Pine_PineValue.List(
                        [
                            Pine.blobValueFromBigInt(param_1_0)
                        ])
                ]);
    }


    public static Pine_PineValue valueFromBool(Pine_PineValue param_1_0)
    {
        if (param_1_0 == Pine_PineKernelValues.TrueValue)
        {
            return CommonReusedValues.List_fb348cf5;
        }

        return CommonReusedValues.List_c47bf601;
    }


    public static Pine_PineValue valueFromInt(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.Blob_Int_1)
        {
            return CommonReusedValues.List_08f1f9f0;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_2)
        {
            return CommonReusedValues.List_f0bf2d16;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_3)
        {
            return CommonReusedValues.List_23f668f0;
        }

        if (param_1_0 == CommonReusedValues.Blob_Int_4)
        {
            return CommonReusedValues.List_99c2ba68;
        }

        return Global_Anonymous.zzz_anon_ed3d09ec_0c02dd8c(param_1_0);
    }


    public static Pine_PineValue valueFromString(Pine_PineValue param_1_0)
    {
        if (param_1_0 == CommonReusedValues.List_f727f528)
        {
            return CommonReusedValues.List_a4a16092;
        }

        if (param_1_0 == CommonReusedValues.List_485f41ca)
        {
            return CommonReusedValues.List_8939bdec;
        }

        if (param_1_0 == CommonReusedValues.List_8ce25fef)
        {
            return CommonReusedValues.List_d4356e44;
        }

        if (param_1_0 == CommonReusedValues.List_bfbd2f47)
        {
            return CommonReusedValues.List_a7996803;
        }

        if (param_1_0 == CommonReusedValues.List_ed1ec9fc)
        {
            return CommonReusedValues.List_4bcbcd70;
        }

        if (param_1_0 == CommonReusedValues.List_84a73c03)
        {
            return CommonReusedValues.List_0a078809;
        }

        if (param_1_0 == CommonReusedValues.List_b18026e6)
        {
            return CommonReusedValues.List_aa8cd902;
        }

        if (param_1_0 == CommonReusedValues.List_ae363231)
        {
            return CommonReusedValues.List_fa615f0b;
        }

        if (param_1_0 == CommonReusedValues.List_fe57e752)
        {
            return CommonReusedValues.List_b8120726;
        }

        if (param_1_0 == CommonReusedValues.List_4b121161)
        {
            return CommonReusedValues.List_f4325494;
        }

        if (param_1_0 == CommonReusedValues.List_996f6e98)
        {
            return CommonReusedValues.List_38faf44f;
        }

        if (param_1_0 == CommonReusedValues.List_48e13149)
        {
            return CommonReusedValues.List_8a17d2aa;
        }

        return Pine.computeValueFromString(param_1_0);
    }
}
